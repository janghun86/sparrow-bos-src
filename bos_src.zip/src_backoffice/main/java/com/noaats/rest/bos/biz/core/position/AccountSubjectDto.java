package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountSubjectDto extends BaseDto {
    private Integer totalCount;
    private Integer totalPage;
    private Integer currentPage;
    private Integer pageSize;
    private boolean pagingEnable;
    private String istCd;
    private String asjTblCd;
    private String asjCd;
    private String drCdsTc;
    private String asjNm;
    private String asjAbvNm;
    private String asjTc;
    private String stmAtsTc;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return AccountSubject.class;
    }
}
