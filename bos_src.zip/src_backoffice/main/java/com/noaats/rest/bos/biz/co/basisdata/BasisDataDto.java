package com.noaats.rest.bos.biz.co.basisdata;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.di.BasisDataBasicDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BasisDataDto extends BasisDataBasicDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return BasisData.class;
    }
}
