package com.noaats.rest.bos.biz.account.reconciliation;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class FinancialAffairsAccountReconciliationOut {
    private List<FinancialAffairsAccountReconciliation> financialAffairsAccountReconciliationList;
}
