package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaxRateBasicDto extends BaseDto {
    private String taxTc;
    private String aplySttDt;
    private String aplyEndDt;
    private Double txr;
    private String rmk;

    @JsonIgnore
    public Class getBusinessClass() {
        return TaxRateBasic.class;
    }
}
