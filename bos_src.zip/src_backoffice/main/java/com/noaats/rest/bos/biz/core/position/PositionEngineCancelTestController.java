package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/engine-cancel-test")
public class PositionEngineCancelTestController extends BaseController {

    private final IPositionEngineCancelTestService<PositionEngineCancelTest> positionEngineCancelTestService;

    @GetMapping
    public ResponseEntity<PositionEngineCancelTestOut> inquiry(@RequestBody BaseRequest<PositionEngineCancelTestIn> request) throws CustomException {
        PositionEngineCancelTestIn in = request.getData();
        PositionEngineCancelTestOut out = new PositionEngineCancelTestOut();

        PositionEngineCancelTest positionEngineCancelTest = convert(in.getPositionEngineCancelTest());

        List<PositionEngineCancelTest> positionEngineCancelTestList = positionEngineCancelTestService.selectPtMngBseSfsAndPtTrSfsAndPtEvtSfs(positionEngineCancelTest);
        out.setPositionEngineCancelTest(positionEngineCancelTestList);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<PositionEngineCancelTestOut> service(@RequestBody BaseRequest<PositionEngineCancelTestIn> request) throws CustomException {
        PositionEngineCancelTestIn in = request.getData();
        PositionEngineCancelTestOut out = new PositionEngineCancelTestOut();

        List<PositionEngineCancelTest> positionEngineCancelTestList = convertList(in.getPositionEngineCancelTestList());

        positionEngineCancelTestService.cancelPosition(positionEngineCancelTestList);
        return ResponseEntity.ok(out);
    }
}
