package com.noaats.rest.bos.biz.co.positiontotalizationgroupassistance;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.co.PositionTotalizationGroupAssistanceBusinessGradeSpecificsDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationGroupAssistanceBusinessGradeDto extends PositionTotalizationGroupAssistanceBusinessGradeSpecificsDto {
    private String bizGrEnrUsnm;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionTotalizationGroupAssistanceBusinessGrade.class;
    }
}
