package com.noaats.rest.bos.biz.abc.trade;

import com.noaats.rest.bos.biz.abc.tr.*;
import com.noaats.rest.bos.biz.tr.PluralHeadingMappingSpecifics;
import com.noaats.rest.bos.biz.tr.TaskBasic;
import com.noaats.rest.bos.biz.tr.TaskProcessHeadingSpecifics;
import com.noaats.rest.bos.biz.tr.TaskProcessPluralHeadingSpecifics;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class TaskProcessOut {
    private TaskBasic taskBasic;
    private List<TaskServiceInfo> taskServiceInfoList;
    private List<HeadingGroupInfo> headingGroupInfoList;
    private List<HeadingInfo> headingInfoList;
    private List<PluralHeadingMappingSpecifics> pluralHeadingMappingSpecificsList;
    private List<TaskHistory> taskHistoryList;
    private List<TaskProcessHeadingSpecifics> taskProcessHeadingSpecificsList;
    private List<TaskProcessPluralHeadingSpecifics> taskProcessPluralHeadingSpecificsList;
    private TaskServiceInfo taskServiceInfo;
    private List<DynamicDataStructure> dynamicDataStructureList;
}
