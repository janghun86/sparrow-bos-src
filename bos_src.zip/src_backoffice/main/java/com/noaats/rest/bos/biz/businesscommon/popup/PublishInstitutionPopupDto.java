package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.co.CounterpartyBasicDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class PublishInstitutionPopupDto extends CounterpartyBasicDto {
    private String lstChgUsid;
    private String fstEnrUsid;
    private String lstChgTrid;
    private String fstEnrTrid;
    private String lstChgIp;
    private String fstEnrIp;
    private String delYn;
    private String istCd;
    private String cptyRolTc;
    private Integer vrs;
    private Long cptyNo;
    private String rmk;
    private Integer type;

    @JsonIgnore
    public Class getBusinessClass() {
        return PublishInstitutionPopup.class;
    }
}
