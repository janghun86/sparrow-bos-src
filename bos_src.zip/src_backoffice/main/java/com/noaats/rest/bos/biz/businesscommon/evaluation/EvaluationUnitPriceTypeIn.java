package com.noaats.rest.bos.biz.businesscommon.evaluation;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.EvaluationUnitPriceClassificationCodeSpecificsDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EvaluationUnitPriceTypeIn extends BaseMessage {
    private EvaluationUnitPriceClassificationCodeSpecificsDto evaluationUnitPriceClassificationCodeSpecifics = new EvaluationUnitPriceClassificationCodeSpecificsDto();
}
