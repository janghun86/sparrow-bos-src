package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.TradeTotalizationColumnCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeTotalizationColumnSearchPopupDto extends TradeTotalizationColumnCatalogueDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return TradeTotalizationColumnSearchPopup.class;
    }
}
