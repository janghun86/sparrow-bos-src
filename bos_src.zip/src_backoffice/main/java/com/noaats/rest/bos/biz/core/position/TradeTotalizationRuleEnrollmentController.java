/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/trade-totalization-rule")
public class TradeTotalizationRuleEnrollmentController extends BaseController {

    private final ITradeTotalizationRuleEnrollmentService<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentService;

    @GetMapping("/type-catalogue")
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> inquiryTradeTypeCatalogue(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();
        // convert
        TradeTotalizationRuleEnrollment tradeTotalizationRuleEnrollment = convert(in.getTradeTotalizationRuleEnrollment().get(0));

        List<TradeTotalizationRuleEnrollment> inquiryTradeTypeCatalogue = tradeTotalizationRuleEnrollmentService.inquiryTradeTypeCatalogue(tradeTotalizationRuleEnrollment);
        out.setTradeTypeCatalogueList(inquiryTradeTypeCatalogue);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/type-mapping")
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> inquiryTradeTypeMappingSpecifics(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();
        // convert
        TradeTotalizationRuleEnrollment tradeTotalizationRuleEnrollment = convert(in.getTradeTotalizationRuleEnrollment().get(0));

        List<TradeTotalizationRuleEnrollment> inquiryTradeTypeCatalogue = tradeTotalizationRuleEnrollmentService.inquiryTradeTypeCatalogue(tradeTotalizationRuleEnrollment);
        out.setTradeTypeCatalogueList(inquiryTradeTypeCatalogue);
        List<TradeTotalizationRuleEnrollment> inquiryTradeTypeMappingSpecifics = tradeTotalizationRuleEnrollmentService.inquiryTradeTypeMappingSpecifics(tradeTotalizationRuleEnrollment);
        out.setTradeTypeMappingSpecificsList(inquiryTradeTypeMappingSpecifics);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/column-catalogue")
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> inquiryColumnCatalogue(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();
        // convert
        TradeTotalizationRuleEnrollment tradeTotalizationRuleEnrollment = convert(in.getTradeTotalizationRuleEnrollment().get(0));

        List<TradeTotalizationRuleEnrollment> inquiryColumnCatalogue = tradeTotalizationRuleEnrollmentService.inquiryColumnCatalogue(tradeTotalizationRuleEnrollment);
        out.setColumnCatalogueList(inquiryColumnCatalogue);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/column-mapping")
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> inquiryColumnMappingSpecifics(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();
        // convert
        TradeTotalizationRuleEnrollment tradeTotalizationRuleEnrollment = convert(in.getTradeTotalizationRuleEnrollment().get(0));

        List<TradeTotalizationRuleEnrollment> inquiryTradeTypeCatalogue = tradeTotalizationRuleEnrollmentService.inquiryTradeTypeCatalogue(tradeTotalizationRuleEnrollment);
        out.setTradeTypeCatalogueList(inquiryTradeTypeCatalogue);
        List<TradeTotalizationRuleEnrollment> inquiryColumnMappingSpecifics = tradeTotalizationRuleEnrollmentService.inquiryColumnMappingSpecifics(tradeTotalizationRuleEnrollment);
        out.setColumnMappingSpecificsList(inquiryColumnMappingSpecifics);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/accounts-symbol")
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> inquiryAccountsSymbolMappingSpecifics(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();
        // convert
        TradeTotalizationRuleEnrollment tradeTotalizationRuleEnrollment = convert(in.getTradeTotalizationRuleEnrollment().get(0));

        List<TradeTotalizationRuleEnrollment> inquiryAccountsSymbolMappingSpecifics = tradeTotalizationRuleEnrollmentService.inquiryAccountsSymbolMappingSpecifics(tradeTotalizationRuleEnrollment);
        out.setAccountsSymbolMappingSpecificsList(inquiryAccountsSymbolMappingSpecifics);
        return ResponseEntity.ok(out);
    }

    @PostMapping("/type-catalogue")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> saveTradeTypeCatalogue(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryTradeTypeCatalogue = tradeTotalizationRuleEnrollmentService.saveTradeTypeCatalogue(tradeTotalizationRuleEnrollmentList);
        out.setTradeTypeCatalogueList(inquiryTradeTypeCatalogue);
        return ResponseEntity.ok(out);
    }

    @PostMapping("/type-mapping")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> saveTradeTypeMappingSpecifics(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryTradeTypeMappingSpecifics = tradeTotalizationRuleEnrollmentService.saveTradeTypeMappingSpecifics(tradeTotalizationRuleEnrollmentList);
        out.setTradeTypeMappingSpecificsList(inquiryTradeTypeMappingSpecifics);
        return ResponseEntity.ok(out);
    }

    @PostMapping("/column-catalogue")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> saveColumnCatalogue(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryColumnCatalogue = tradeTotalizationRuleEnrollmentService.saveColumnCatalogue(tradeTotalizationRuleEnrollmentList);
        out.setColumnCatalogueList(inquiryColumnCatalogue);
        return ResponseEntity.ok(out);
    }

    @PostMapping("/column-mapping")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> saveColumnMappingSpecifics(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryColumnMappingSpecifics = tradeTotalizationRuleEnrollmentService.saveColumnMappingSpecifics(tradeTotalizationRuleEnrollmentList);
        out.setColumnMappingSpecificsList(inquiryColumnMappingSpecifics);
        return ResponseEntity.ok(out);
    }

    @PostMapping("/accounts-symbol")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> saveAccountsSymbolMappingSpecifics(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryAccountsSymbolMappingSpecifics = tradeTotalizationRuleEnrollmentService.saveAccountsSymbolMappingSpecifics(tradeTotalizationRuleEnrollmentList);
        out.setAccountsSymbolMappingSpecificsList(inquiryAccountsSymbolMappingSpecifics);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping("/type-catalogue")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> deleteTradeTypeCatalogue(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryTradeTypeCatalogue = tradeTotalizationRuleEnrollmentService.deleteTradeTypeCatalogue(tradeTotalizationRuleEnrollmentList);
        out.setTradeTypeCatalogueList(inquiryTradeTypeCatalogue);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping("/type-mapping")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> deleteTradeTypeMappingSpecifics(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryTradeTypeMappingSpecifics = tradeTotalizationRuleEnrollmentService.deleteTradeTypeMappingSpecifics(tradeTotalizationRuleEnrollmentList);
        out.setTradeTypeMappingSpecificsList(inquiryTradeTypeMappingSpecifics);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping("/column-catalogue")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> deleteColumnCatalogue(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryColumnCatalogue = tradeTotalizationRuleEnrollmentService.deleteColumnCatalogue(tradeTotalizationRuleEnrollmentList);
        out.setColumnCatalogueList(inquiryColumnCatalogue);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping("/column-mapping")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> deleteColumnMappingSpecifics(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryColumnMappingSpecifics = tradeTotalizationRuleEnrollmentService.deleteColumnMappingSpecifics(tradeTotalizationRuleEnrollmentList);
        out.setColumnMappingSpecificsList(inquiryColumnMappingSpecifics);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping("/accounts-symbol")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationRuleEnrollmentOut> deleteAccountsSymbolMappingSpecifics(@RequestBody BaseRequest<TradeTotalizationRuleEnrollmentIn> request) throws CustomException {
        TradeTotalizationRuleEnrollmentIn in = request.getData();
        TradeTotalizationRuleEnrollmentOut out = new TradeTotalizationRuleEnrollmentOut();

        List<TradeTotalizationRuleEnrollment> tradeTotalizationRuleEnrollmentList = convertList(in.getTradeTotalizationRuleEnrollment());

        List<TradeTotalizationRuleEnrollment> inquiryAccountsSymbolMappingSpecifics = tradeTotalizationRuleEnrollmentService.deleteAccountsSymbolMappingSpecifics(tradeTotalizationRuleEnrollmentList);
        out.setAccountsSymbolMappingSpecificsList(inquiryAccountsSymbolMappingSpecifics);
        return ResponseEntity.ok(out);
    }
}
