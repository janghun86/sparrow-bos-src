package com.noaats.rest.bos.biz.abc.tr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DynamicDataStructureDto extends BaseDto {
    private String colId;
    private String value;
    private String datTp;
    private String hdnTc;
    private String dsId;
    private String rowNum;

    @JsonIgnore
    public Class getBusinessClass() {
        return DynamicDataStructure.class;
    }
}
