package com.noaats.rest.bos.biz.co.marketdata;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LendingAverageSpecificsDto extends BaseDto {
    private String rfrIrtNm;
    private String rmk;
    private Double rfrIrt;
    private String rfrIrtCd;
    private String istCd;
    private String hddDt;
    private String hddCd;
    private String hddNm;
    private String bsdTc;
    private String lvl;
    private String bzDt;
    private String bseDt;
    private String isHdd;

    @JsonIgnore
    public Class getBusinessClass() {
        return LendingAverageSpecifics.class;
    }
}
