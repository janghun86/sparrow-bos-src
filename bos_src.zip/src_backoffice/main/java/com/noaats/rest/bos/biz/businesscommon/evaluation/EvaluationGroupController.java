/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.businesscommon.evaluation;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.EvaluationGroupCatalogue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/evaluation")
public class EvaluationGroupController extends BaseController {

    private final IEvaluationGroupService<EvaluationGroupCatalogue> evaluationGroupService;

    @GetMapping
    public ResponseEntity<EvaluationGroupOut> inquiry(@RequestBody BaseRequest<EvaluationGroupIn> request) throws CustomException {
        EvaluationGroupIn in = request.getData();
        EvaluationGroupOut out = new EvaluationGroupOut();
        // convert
        EvaluationGroupCatalogue evaluationGroupCatalogue = convert(in.getEvaluationGroupCatalogue());

        out.setEvaluationGroupCatalogueList(evaluationGroupService.inquiry(evaluationGroupCatalogue));
        return ResponseEntity.ok(out);
    }
}
