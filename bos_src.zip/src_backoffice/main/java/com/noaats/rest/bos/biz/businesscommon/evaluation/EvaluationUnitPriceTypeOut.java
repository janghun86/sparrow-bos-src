package com.noaats.rest.bos.biz.businesscommon.evaluation;

import com.noaats.rest.bos.biz.cr.EvaluationUnitPriceClassificationCodeSpecifics;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class EvaluationUnitPriceTypeOut {
    private List<EvaluationUnitPriceClassificationCodeSpecifics> evaluationUnitPriceClassificationCodeSpecificsList;
}
