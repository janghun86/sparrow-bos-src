package com.noaats.rest.bos.biz.core.position;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class InsideOfTheHallDerivativesDay1ExactCalculationOut {
    private List<InsideOfTheHallDerivativesDay1ExactCalculation> insideOfTheHallDerivativesDay1ExactCalculationList;
    private List<InsideOfTheHallDerivativesDay1Evaluation> insideOfTheHallDerivativesDay1EvaluationList;
    private List<InsideOfTheHallDerivativesDay1ExactCalculation> acEvlTpList;
    private List<InsideOfTheHallDerivativesDay1ExactCalculation> evlAreaList;
}
