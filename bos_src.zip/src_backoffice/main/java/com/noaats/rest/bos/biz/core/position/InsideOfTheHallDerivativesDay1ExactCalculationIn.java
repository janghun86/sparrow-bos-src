package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class InsideOfTheHallDerivativesDay1ExactCalculationIn extends BaseMessage {
    private InsideOfTheHallDerivativesDay1ExactCalculationDto insideOfTheHallDerivativesDay1ExactCalculation = new InsideOfTheHallDerivativesDay1ExactCalculationDto();
    private List<InsideOfTheHallDerivativesDay1ExactCalculationDto> insideOfTheHallDerivativesDay1ExactCalculationList = new ArrayList<>();
    private InsideOfTheHallDerivativesDay1EvaluationDto insideOfTheHallDerivativesDay1Evaluation = new InsideOfTheHallDerivativesDay1EvaluationDto();
    private List<InsideOfTheHallDerivativesDay1EvaluationDto> insideOfTheHallDerivativesDay1EvaluationList = new ArrayList<>();
}
