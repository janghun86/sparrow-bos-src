package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.lib.frk.service.ICustomService;
import com.noaats.rest.bos.biz.cr.position.PositionManagementBase;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/management-base")
public class PositionManagementBaseController extends BaseController {

    private final IPositionEngineTestService<PositionEngineTest> positionEngineTestService;

    @GetMapping
    public ResponseEntity<PositionManagementBaseOut> inquiry(@RequestBody BaseRequest<PositionManagementBaseIn> request) throws CustomException {
        PositionManagementBaseIn in = request.getData();
        PositionManagementBaseOut out = new PositionManagementBaseOut();

        PositionManagementBase positionManagementBase = convert(in.getPositionManagementBase());

        List<PositionManagementBase> positionManagementBaseList = positionEngineTestService.findPositionManagementBase(positionManagementBase);
        out.setPositionManagementBaseList(positionManagementBaseList);
        return ResponseEntity.ok(out);
    }
}
