package com.noaats.rest.bos.biz.businesscommon.department;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizationSearchPopupDto extends BaseDto {
    private String isLeaf;
    private Integer lvl;
    private String dpmCd;
    private String hrkDpmCd;
    private String dpmNm;
    private Integer sotSqn;
    private String sttDt;
    private String endDt;
    private String chkYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return OrganizationSearchPopup.class;
    }
}
