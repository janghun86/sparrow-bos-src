package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EvaluationAreaMappingSpecificsDto extends BaseDto {
    private String acMngGrpId;
    private String evlAreaId;
    private String evlGrpId;
    private String prdTpId;
    private String bkgCttYn;
    private String ptClsUntId;
    private String evlCurCd;

    @JsonIgnore
    public Class getBusinessClass() {
        return EvaluationAreaMappingSpecifics.class;
    }
}
