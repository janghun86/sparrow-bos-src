package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.fw.UserBasicDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserPopupDto extends UserBasicDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return UserPopup.class;
    }
}
