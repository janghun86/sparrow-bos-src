package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DependencyPositionProcessTypeTransferMappingDto extends BaseDto {
    private String dpdMpnTpId;
    private String dpdMpnTpNm;
    private String pnbDlvyDpdTpId;
    private String pnbDlvyPtPcsTpId;
    private String pnbStoDpdTpId;
    private String pnbStoPtPcsTpId;
    private String nnbDlvyDpdTpId;
    private String nnbDlvyPtPcsTpId;
    private String nnbStoDpdTpId;
    private String nnbStoPtPcsTpId;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return DependencyPositionProcessTypeTransferMapping.class;
    }
}
