package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AmountProcessTypeCatalogueDto extends BaseDto {
    private String amtPcsTpId;
    private String amtPcsTpNm;
    private String amtTp1Tc;
    private String ptInd1Tc;
    private String amtTp2Tc;
    private String ptInd2Tc;
    private String amtTp3Tc;
    private String ptInd3Tc;

    @JsonIgnore
    public Class getBusinessClass() {
        return AmountProcessTypeCatalogue.class;
    }
}
