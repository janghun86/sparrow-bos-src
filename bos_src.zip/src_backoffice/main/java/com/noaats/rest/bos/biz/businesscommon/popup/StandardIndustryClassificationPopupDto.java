package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.fw.commoncode.CommonCodeDetailDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandardIndustryClassificationPopupDto extends CommonCodeDetailDto {
    private String subKey;
    private Integer lvl;
    private Integer seq;
    private String delYn;
    private String alnDt;
    private String sttDt;
    private String hrkCoCva;
    private Integer sotSqn;
    private String coCvaNm;
    private String lanCd;
    private String coCva;
    private String coCdId;
    private boolean pagingEnable;
    private String istCd;
    private Integer pageSize;
    private Integer currentPage;
    private Integer totalPage;
    private Integer totalCount;

    @JsonIgnore
    public Class getBusinessClass() {
        return StandardIndustryClassificationPopup.class;
    }
}
