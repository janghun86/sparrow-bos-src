package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.lib.frk.util.StringUtils;
import com.noaats.rest.bos.biz.cr.trade.soltrade.ISOLTradeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/trade-engine-test")
public class TradeEngineTestController extends BaseController {

    private final ITradeEngineTestService<TradeEngineTest> tradeEngineTestService;

    private final ISOLTradeService<TradeEngineTest> solTradeService;

    /**
     * <pre>
     * description : 거래등록
     * </pre>
     *
     * @throws Exception
     * @date : 2019. 4. 5.
     * @author : User
     */
    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeEngineTestOut> registration(@RequestBody BaseRequest<TradeEngineTestIn> request) throws CustomException {
        TradeEngineTestIn in = request.getData();
        TradeEngineTestOut out = new TradeEngineTestOut();
        // convert
        TradeEngineTest tradeEngineTest = convert(in.getTradeEngineTest());
        List<TradeEventType> tradeEventTypeList = convertList(in.getTradeEventTypeList());

        tradeEngineTest.setTradeEventTypeList(tradeEventTypeList);


        // 거래통화코드
        if (StringUtils.isEmpty(tradeEngineTest.getTrCurCd())) {

            if (!StringUtils.isEmpty(tradeEngineTest.getRecvCttCurCd())) {

                tradeEngineTest.setTrCurCd(tradeEngineTest.getRecvCttCurCd());
            } else {

                tradeEngineTest.setTrCurCd(tradeEngineTest.getParCurCd());
            }
        }

        tradeEngineTest.setSolTradeBeanName("tradeEngineTestService");

        solTradeService.tradingWithSave(tradeEngineTest);

        out.getTradeEngineTest().setTrno(tradeEngineTest.getTradeBasic().getTrno());
        return ResponseEntity.ok(out);
    }

    /**
     * <pre>
     * description : 거래취소
     * </pre>
     *
     * @throws Exception
     * @date : 2019. 4. 5.
     * @author : User
     */
    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeEngineTestOut> delete(@RequestBody BaseRequest<TradeEngineTestIn> request) throws CustomException {
        TradeEngineTestIn in = request.getData();
        TradeEngineTestOut out = new TradeEngineTestOut();
        // convert
        TradeEngineTest tradeEngineTest = convert(in.getTradeEngineTest());

        solTradeService.cancelTrading(tradeEngineTest);
        return ResponseEntity.ok(out);
    }

    /**
     * <pre>
     * description : 채권단가 산출
     * </pre>
     *
     * @throws Exception
     * @date : 2019. 4. 5.
     * @author : User
     */
    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeEngineTestOut> modify(@RequestBody BaseRequest<TradeEngineTestIn> request) throws CustomException {
        TradeEngineTestIn in = request.getData();
        TradeEngineTestOut out = new TradeEngineTestOut();
        // convert
        TradeEngineTest tradeEngineTest = convert(in.getTradeEngineTest());

        tradeEngineTestService.calculateRateOfReturn(tradeEngineTest);
        out.setTradeEngineTest(tradeEngineTest);
        return ResponseEntity.ok(out);
    }

    /**
     * <pre>
     * description : 거래 조회
     * </pre>
     *
     * @throws Exception
     * @date : 2020. 7. 6.
     * @author : jh86@noaats.com
     */
    @GetMapping
    public ResponseEntity<TradeEngineTestOut> inquiry(@RequestBody BaseRequest<TradeEngineTestIn> request) throws CustomException {
        TradeEngineTestIn in = request.getData();
        TradeEngineTestOut out = new TradeEngineTestOut();
        // convert
        TradeEngineTest tradeEngineTest = convert(in.getTradeEngineTest());

        tradeEngineTestService.inquiry(tradeEngineTest);
        out.setTradeBasic(tradeEngineTest.getTradeBasic());
        out.setTradeEventList(tradeEngineTest.getTradeEventList());
        return ResponseEntity.ok(out);
    }
}
