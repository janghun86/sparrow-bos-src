package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommonTableMappingSpecificsDto extends BaseDto {
    private String prdTpId;
    private String prdNoCrnTbId;
    private String trnoCrnTbId;

    @JsonIgnore
    public Class getBusinessClass() {
        return CommonTableMappingSpecifics.class;
    }
}
