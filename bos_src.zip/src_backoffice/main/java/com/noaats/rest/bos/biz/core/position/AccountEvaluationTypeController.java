package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.AccountEvaluationTypeCatalogue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/account-evaluation-type")
public class AccountEvaluationTypeController extends BaseController {

    private final IAccountEvaluationTypeService<AccountEvaluationTypeCatalogue> accountEvaluationTypeService;

    @GetMapping
    public ResponseEntity<AccountEvaluationTypeOut> findUseAll(@RequestBody BaseRequest<AccountEvaluationTypeIn> request) throws CustomException {
        AccountEvaluationTypeIn in = request.getData();
        AccountEvaluationTypeOut out = new AccountEvaluationTypeOut();
        // convert
        AccountEvaluationTypeCatalogue accountEvaluationTypeCatalogue = convert(in.getAccountEvaluationType());

        List<AccountEvaluationTypeCatalogue> accountEvaluationTypeList = accountEvaluationTypeService.findUseAll(accountEvaluationTypeCatalogue);
        out.setAccountEvaluationTypeList(accountEvaluationTypeList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/popup")
    public ResponseEntity<AccountEvaluationTypeOut> findByAcEvlTpIdOrAcEvlTpNm(@RequestBody BaseRequest<AccountEvaluationTypeIn> request) throws CustomException {
        AccountEvaluationTypeIn in = request.getData();
        AccountEvaluationTypeOut out = new AccountEvaluationTypeOut();
        // convert
        AccountEvaluationTypeCatalogue accountEvaluationTypeCatalogue = convert(in.getAccountEvaluationType());

        List<AccountEvaluationTypeCatalogue> accountEvaluationTypeList = accountEvaluationTypeService.findByAcEvlTpIdOrAcEvlTpNm(accountEvaluationTypeCatalogue);
        out.setAccountEvaluationTypeList(accountEvaluationTypeList);
        return ResponseEntity.ok(out);
    }
}
