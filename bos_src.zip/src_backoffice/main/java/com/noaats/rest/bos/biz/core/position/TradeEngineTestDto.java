package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.trade.TradeDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeEngineTestDto extends TradeDto {
    private String fndCd;
    private String stnItmCd;
    private String bseDt;
    private String xrtDt;
    private Double trQty;
    private Double trUpr;
    private Double trAmt;
    private String parCurCd;
    private Double parAmt;
    private Double dlnRor;
    private String dfrCttCurCd;
    private Double dfrCttAmt;
    private String recvCttCurCd;
    private Double recvCttAmt;

    @JsonIgnore
    public Class getBusinessClass() {
        return TradeEngineTest.class;
    }
}
