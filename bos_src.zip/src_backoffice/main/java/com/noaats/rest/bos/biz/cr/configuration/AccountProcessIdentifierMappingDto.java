package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.AccountProcessIdentifierMappingSpecificsDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountProcessIdentifierMappingDto extends AccountProcessIdentifierMappingSpecificsDto {
    private String prdNo;
    private String tbId;
    private Long pubIstCptyNo;
    private String prdClsId;

    @JsonIgnore
    public Class getBusinessClass() {
        return AccountProcessIdentifierMapping.class;
    }
}
