package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.position.PositionManagementBaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionManagementBaseInformationDto extends PositionManagementBaseDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionManagementBaseInformation.class;
    }
}
