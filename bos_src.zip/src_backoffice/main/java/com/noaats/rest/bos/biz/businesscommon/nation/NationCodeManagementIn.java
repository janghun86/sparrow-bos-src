package com.noaats.rest.bos.biz.businesscommon.nation;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.co.NationCodeCatalogueDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class NationCodeManagementIn extends BaseMessage {
    private NationCodeCatalogueDto nationCodeCatalogue = new NationCodeCatalogueDto();
    private List<NationCodeCatalogueDto> nationCodeCatalogueList = new ArrayList<>();
}
