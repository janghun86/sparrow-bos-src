package com.noaats.rest.bos.biz.cr.evaluation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.position.positionbalance.PositionBalanceDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HedgeAccountEvaluationDto extends PositionBalanceDto {
    private String bseDt;
    private String acMngGrpId;
    private String evlAreaId;
    private String evlTpId;
    private String pofId;
    private String prdNo;
    private String ptTrno;
    private String ptTlzGrpId;
    private String hdgTpTc;
    private String evlCurCd;
    private Double jbefAbkAmt;
    private Double jbefCpadVca;
    private Double pvAmt;
    private Double evlPnlAmt;
    private Double fcCvsPnlAmt;
    private Double inefEvlPnlAmt;
    private Double effEvlPnlAmt;
    private String evlCtgTc;
    private String errMsg;
    private String rsuDt;
    private String ptEvlPcdrId;
    private String ptEvlPcdrNm;
    private String ptEvlTc;
    private String ptChgEffTc;
    private String evlStg1Tc;
    private String evlPcs1Id;
    private String evlStg2Tc;
    private String evlPcs2Id;
    private String evlStg3Tc;
    private String evlPcs3Id;
    private String evlStg4Tc;
    private String evlPcs4Id;
    private String evlStg5Tc;
    private String evlPcs5Id;
    private String astDbtPtTc;
    private Long ptMngBseNo;
    private String aplySttDt;
    private String aplyEndDt;
    private String hdgPlnNo;

    @JsonIgnore
    public Class getBusinessClass() {
        return HedgeAccountEvaluation.class;
    }
}
