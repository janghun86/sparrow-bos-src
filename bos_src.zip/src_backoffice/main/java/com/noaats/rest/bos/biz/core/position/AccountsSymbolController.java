package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.AccountsSymbolCatalogue;
import com.noaats.rest.bos.biz.cr.IAccountsSymbolCatalogueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/account-symbol")
public class AccountsSymbolController extends BaseController {

    private final IAccountsSymbolCatalogueService accountsSymbolCatalogueService;

    @GetMapping
    public ResponseEntity<AccountsSymbolOut> findUseAll(@RequestBody BaseRequest<AccountsSymbolIn> request) throws CustomException {
        AccountsSymbolIn in = request.getData();
        AccountsSymbolOut out = new AccountsSymbolOut();
        // convert
        AccountsSymbolCatalogue accountsSymbolCatalogue = convert(in.getAccountsSymbolCatalogue());

        List<AccountsSymbolCatalogue> accountsSymbolCatalogueList = accountsSymbolCatalogueService.findUseAll(accountsSymbolCatalogue);
        out.setAccountsSymbolCatalogueList(accountsSymbolCatalogueList);
        return ResponseEntity.ok(out);
    }
}
