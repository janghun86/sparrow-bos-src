package com.noaats.rest.bos.biz.businesscommon.department;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class ManagementDepartmentYnDto extends BaseDto {
    private String hdqCd;
    private String istCd;
    private String dpmCd;
    private String dpmRolTc;
    private String rmk;
    private String delYn;
    private String fstEnrUsid;
    private String fstEnrTrid;
    private String fstEnrIp;
    private String lstChgUsid;
    private String lstChgTrid;
    private String lstChgIp;

    @JsonIgnore
    public Class getBusinessClass() {
        return ManagementDepartmentYn.class;
    }
}
