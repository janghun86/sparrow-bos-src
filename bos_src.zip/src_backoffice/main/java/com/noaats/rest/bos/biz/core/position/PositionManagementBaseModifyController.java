package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/management-base-modify")
public class PositionManagementBaseModifyController extends BaseController {

    private final IPositionManagementBaseModifyService<PositionManagementBaseModify> positionManagementBaseModifyService;

    @GetMapping
    public ResponseEntity<PositionManagementBaseModifyOut> list(@RequestBody BaseRequest<PositionManagementBaseModifyIn> request) throws CustomException {
        PositionManagementBaseModifyIn in = request.getData();
        PositionManagementBaseModifyOut out = new PositionManagementBaseModifyOut();
        // convert
        PositionManagementBaseModify positionManagementBaseModify = convert(in.getPositionManagementBaseModify());

        List<PositionManagementBaseModify> positionManagementBaseModifyList = positionManagementBaseModifyService.list(positionManagementBaseModify);
        out.setPositionManagementBaseModifyList(positionManagementBaseModifyList);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<PositionManagementBaseModifyOut> save(@RequestBody BaseRequest<PositionManagementBaseModifyIn> request) throws CustomException {
        PositionManagementBaseModifyIn in = request.getData();
        PositionManagementBaseModifyOut out = new PositionManagementBaseModifyOut();
        // convert
        List<PositionManagementBaseModify> positionManagementBaseModifyList = convertList(in.getPositionManagementBaseModifyList());

        for (PositionManagementBaseModify principalAndInterestProcess : positionManagementBaseModifyList) {
            positionManagementBaseModifyService.save(principalAndInterestProcess);
        }
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<PositionManagementBaseModifyOut> delete(@RequestBody BaseRequest<PositionManagementBaseModifyIn> request) throws CustomException {
        PositionManagementBaseModifyIn in = request.getData();
        PositionManagementBaseModifyOut out = new PositionManagementBaseModifyOut();
        // convert
        List<PositionManagementBaseModify> positionManagementBaseModifyList = convertList(in.getPositionManagementBaseModifyList());

        for (PositionManagementBaseModify principalAndInterestProcess : positionManagementBaseModifyList) {
            positionManagementBaseModifyService.delete(principalAndInterestProcess);
        }
        return ResponseEntity.ok(out);
    }
}
