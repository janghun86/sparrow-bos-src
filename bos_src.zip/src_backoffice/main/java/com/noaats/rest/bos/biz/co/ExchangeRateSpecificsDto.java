package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExchangeRateSpecificsDto extends BaseDto {
    private String bseDt;
    private String curCd;
    private Double bseAplyXcr;
    private Double kftcBltnBseRt;
    private Long xcrBltnUntNbr;
    private Double mktAvrUsdCvsRt;

    @JsonIgnore
    public Class getBusinessClass() {
        return ExchangeRateSpecifics.class;
    }
}
