package com.noaats.rest.bos.biz.core.position;

import com.noaats.rest.bos.biz.cr.AmortizeDefinitionCatalogue;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AmortizeDefinitionOut {
    private List<AmortizeDefinitionCatalogue> amortizeDefinitionCatalogueList;
}
