package com.noaats.rest.bos.biz.businesscommon.currency;

import com.noaats.rest.bos.biz.co.CurrencyBasic;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CurrencyCodeManagementOut {
    private List<CurrencyBasic> currencyBasicList;
}
