package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.AccountSubjectCatalogue;
import com.noaats.rest.bos.biz.cr.IAccountSubjectCatalogueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/account-subject")
public class AccountSubjectController extends BaseController {

    private final IAccountSubjectCatalogueService accountSubjectCatalogueService;

    private final IAccountSubjectService accountSubjectService;

    @GetMapping
    public ResponseEntity<AccountSubjectOut> findUseAll(@RequestBody BaseRequest<AccountSubjectIn> request) throws CustomException {
        AccountSubjectIn in = request.getData();
        AccountSubjectOut out = new AccountSubjectOut();
        // convert
        AccountSubjectCatalogue accountSubjectCatalogue = convert(in.getAccountSubjectCatalogue());

        List<AccountSubjectCatalogue> accountSubjectCatalogueList = accountSubjectCatalogueService.findUseAll(accountSubjectCatalogue);
        out.setAccountSubjectCatalogueList(accountSubjectCatalogueList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/popup")
    public ResponseEntity<AccountSubjectOut> list(@RequestBody BaseRequest<AccountSubjectIn> request) throws CustomException {
        AccountSubjectIn in = request.getData();
        AccountSubjectOut out = new AccountSubjectOut();
        // convert
        AccountSubject accountSubject = convert(in.getAccountSubject());

        List<AccountSubject> accountSubjectList = accountSubjectService.list(accountSubject);
        out.setAccountSubjectList(accountSubjectList);
        return ResponseEntity.ok(out);
    }
}
