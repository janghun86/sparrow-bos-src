/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.  
 */

package com.noaats.rest.bos.biz.businesscommon.amount;

import com.noaats.lib.frk.mci.MCIMessage;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 *
 * description : 
 *
 * com.noaats.rest.bos.biz.controller.businesscommon.amount
 *    AmountMappingInformationManagementIn.java
 * 
 * </pre>
 * @date : 2021. 1. 19. 오후 5:09:32
 * @version : 
 * @author : gktmddk96@noaats.com
 * 
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2021. 1. 19.	gktmddk96@noaats.com		최초생성
 *
 * </pre>
 */

@Slf4j
public class AmountMappingInformationManagementVo extends MCIMessage {

	private static final long serialVersionUID = -8849332934445943305L;
	
	private AmountMappingInformationManagement amountMappingInformationManagement = new AmountMappingInformationManagement();
	private List<AmountMappingInformationManagement> amountMappingInformationManagementList = new ArrayList<>();

	public AmountMappingInformationManagement getAmountMappingInformationManagement() {
		return amountMappingInformationManagement;
	}

	public void setAmountMappingInformationManagement(
			AmountMappingInformationManagement amountMappingInformationManagement) {
		this.amountMappingInformationManagement = amountMappingInformationManagement;
	}

	public List<AmountMappingInformationManagement> getAmountMappingInformationManagementList() {
		return amountMappingInformationManagementList;
	}

	public void setAmountMappingInformationManagementList(
			List<AmountMappingInformationManagement> amountMappingInformationManagementList) {
		this.amountMappingInformationManagementList = amountMappingInformationManagementList;
	}
}
