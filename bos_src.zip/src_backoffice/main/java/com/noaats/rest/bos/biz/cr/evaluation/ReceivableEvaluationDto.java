package com.noaats.rest.bos.biz.cr.evaluation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReceivableEvaluationDto extends BaseDto {
    private String rcbArcvPtTrno;
    private String rcbPtPcsTpId;
    private Long rcbArcvEvtSno;
    private String ptCflPtTrno;
    private String intCalTc;
    private String intPaoTc;
    private String rsuDt;
    private String evlGrpId;
    private String evlGrpIds;
    private String wonFcTc;
    private String pcsStsTc;
    private String prdGrpTc;
    private String lnkTrPtTrno;
    private boolean calEndDtIcb;
    private String jrnStsTc;
    private Double aitVca;
    private Double aitAmt;
    private Double rcbIntCvsPnlAmt;
    private Double rcbIntVca;
    private Double rcbIntAmt;
    private Double avrXcr;
    private Double calBseAmt;
    private Double aplyIrt;
    private String ddsCalMthTc;
    private Integer calBseDds;
    private Integer calDds;
    private String fddIclTc;
    private String calTrmEndDt;
    private String calTrmSttDt;
    private String rsuYn;
    private String ptPcsTpId;
    private Long evtSno;
    private String ptTrno;
    private String bseDt;
    private String evlPcs5Id;
    private String evlStg5Tc;
    private String evlPcs4Id;
    private String evlStg4Tc;
    private String evlPcs3Id;
    private String evlStg3Tc;
    private String evlPcs2Id;
    private String evlStg2Tc;
    private String evlPcs1Id;
    private String evlStg1Tc;
    private String ptEvlPcdrNm;
    private String evlCurCd;
    private String ptCurCd;
    private Long dpsIstCptyNo;
    private String astDbtPtTc;
    private String pofId;
    private Long trno;
    private String fstPtBseDt;
    private Long ptUnqNo;
    private String ptTlzId;
    private String ptTlzGrpId;
    private String prdNo;
    private String prdTpId;
    private String prdClsId;
    private String acMngGrpId;
    private String evlTpId;
    private String acEvlTpId;
    private String evlAreaId;
    private String acPcsIdfrId;
    private String ptEvlPcdrId;
    private String ptLdgTc;
    private String delYn;
    private String istCd;
    private Long ptMngBseNo;
    private String aplySttDt;
    private String aplyEndDt;
    private String prdNm;
    private Double urpItkOtcpAmt;
    private String ptCflPtBseDt;
    private Double ytm;

    @JsonIgnore
    public Class getBusinessClass() {
        return ReceivableEvaluation.class;
    }
}
