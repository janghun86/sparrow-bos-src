package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/risk-aversion")
public class RiskAversionAccountingEvaluationController extends BaseController {

    private final IRiskAversionAccountingEvaluationService<RiskAversionAccountingEvaluation> riskAversionAccountingEvaluationService;

    @GetMapping
    public ResponseEntity<RiskAversionAccountingEvaluationOut> inquiry(@RequestBody BaseRequest<RiskAversionAccountingEvaluationIn> request) throws CustomException {
        RiskAversionAccountingEvaluationIn in = request.getData();
        RiskAversionAccountingEvaluationOut out = new RiskAversionAccountingEvaluationOut();

        RiskAversionAccountingEvaluation riskAversionAccountingEvaluation = convert(in.getRiskAversionAccountingEvaluation());

        out.setRiskAversionAccountingEvaluationList(riskAversionAccountingEvaluationService.inquiry(riskAversionAccountingEvaluation));
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<RiskAversionAccountingEvaluationOut> save(@RequestBody BaseRequest<RiskAversionAccountingEvaluationIn> request) throws CustomException {
        RiskAversionAccountingEvaluationIn in = request.getData();
        RiskAversionAccountingEvaluationOut out = new RiskAversionAccountingEvaluationOut();

        List<RiskAversionAccountingEvaluation> riskAversionAccountingEvaluationList = convertList(in.getRiskAversionAccountingEvaluationList());

        out.setRiskAversionAccountingEvaluationList(riskAversionAccountingEvaluationService.save(riskAversionAccountingEvaluationList));
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<RiskAversionAccountingEvaluationOut> cancel(@RequestBody BaseRequest<RiskAversionAccountingEvaluationIn> request) throws CustomException {
        RiskAversionAccountingEvaluationIn in = request.getData();
        RiskAversionAccountingEvaluationOut out = new RiskAversionAccountingEvaluationOut();

        List<RiskAversionAccountingEvaluation> riskAversionAccountingEvaluationList = convertList(in.getRiskAversionAccountingEvaluationList());

        out.setRiskAversionAccountingEvaluationList(riskAversionAccountingEvaluationService.cancel(riskAversionAccountingEvaluationList));
        return ResponseEntity.ok(out);
    }
}
