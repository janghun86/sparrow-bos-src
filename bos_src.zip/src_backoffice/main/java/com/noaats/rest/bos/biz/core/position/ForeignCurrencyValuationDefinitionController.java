package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.ForeignCurrencyValuationDefinitionCatalogue;
import com.noaats.rest.bos.biz.cr.IForeignCurrencyValuationDefinitionCatalogueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/foreign-currency")
public class ForeignCurrencyValuationDefinitionController extends BaseController {

    private final IForeignCurrencyValuationDefinitionCatalogueService foreignCurrencyValuationDefinitionCatalogueService;

    @GetMapping
    public ResponseEntity<ForeignCurrencyValuationDefinitionOut> findUseAll(@RequestBody BaseRequest<ForeignCurrencyValuationDefinitionIn> request) throws CustomException {
        ForeignCurrencyValuationDefinitionIn in = request.getData();
        ForeignCurrencyValuationDefinitionOut out = new ForeignCurrencyValuationDefinitionOut();

        ForeignCurrencyValuationDefinitionCatalogue foreignCurrencyValuationDefinitionCatalogue = convert(in.getForeignCurrencyValuationDefinitionCatalogue());

        List<ForeignCurrencyValuationDefinitionCatalogue> foreignCurrencyValuationDefinitionCatalogueList = foreignCurrencyValuationDefinitionCatalogueService.findUseAll(foreignCurrencyValuationDefinitionCatalogue);
        out.setForeignCurrencyValuationDefinitionCatalogueList(foreignCurrencyValuationDefinitionCatalogueList);
        return ResponseEntity.ok(out);
    }
}
