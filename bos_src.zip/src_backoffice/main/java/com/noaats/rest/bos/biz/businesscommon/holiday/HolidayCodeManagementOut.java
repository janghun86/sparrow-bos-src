package com.noaats.rest.bos.biz.businesscommon.holiday;

import com.noaats.rest.bos.biz.co.HolidayCodeCatalogue;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class HolidayCodeManagementOut {
    private HolidayCodeCatalogue holidayCodeCatalogue;
    private List<HolidayDate> holidayDateInformationList;
}
