package com.noaats.rest.bos.biz.account.reconciliation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FinancialAffairsAccountReconciliationDto extends BaseDto {
    private String asjCd;
    private String asjNm;
    private String asjTblCd;
    private String prdTpId;
    private String prdNoCrnTbId;
    private String bseDt;
    private String evlAreaId;
    private String acMngGrpId;
    private String acPcsIdfrId;
    private String istCd;
    private String pnlTlzTc;
    private String pnlClsCd;
    private String pofId;
    private String ptTlzGrpId;
    private String prdNo;
    private String ptTlzId;
    private Double pca;
    private Double vca;
    private String ptCurCd;
    private String evlCurCd;
    private String delYn;
    private String fstEnrUsid;
    private String fstEnrTrid;
    private String fstEnrIp;
    private String lstChgUsid;
    private String lstChgTrid;
    private String lstChgIp;
    private String sttDt;
    private String endDt;
    private String drCdsTc;
    private Double acVca;
    private String atsSymCd;
    private String prdNm;
    private String bizId;

    @JsonIgnore
    public Class getBusinessClass() {
        return FinancialAffairsAccountReconciliation.class;
    }
}
