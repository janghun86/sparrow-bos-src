package com.noaats.rest.bos.biz.businesscommon.department;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/department/management")
public class ManagementDepartmentYnController extends BaseController {

    private final IManagementDepartmentYnService<ManagementDepartmentYn> managementDepartmentYnService;

    @GetMapping
    public ResponseEntity<ManagementDepartmentYnOut> service(@RequestBody BaseRequest<ManagementDepartmentYnIn> request) throws CustomException {
        ManagementDepartmentYnIn in = request.getData();
        ManagementDepartmentYnOut out = new ManagementDepartmentYnOut();
        // convert
        ManagementDepartmentYn managementDepartmentYn = convert(in.getManagementDepartmentYn());

        out.setManagementDepartmentYnList(managementDepartmentYnService.inquiry(managementDepartmentYn));
        return ResponseEntity.ok(out);
    }
}
