package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeTotalizationRuleEnrollmentDto extends BaseDto {
    private String istCd;
    private String trTlzTrTpId;
    private Integer vrs;
    private String trTlzTrTpNm;
    private String delYn;
    private Long sno;
    private String ptPcsTpId;
    private String trTlzColId;
    private String trTlzColNm;
    private String amtIndTc;
    private String atsSymCd;
    private String ptPcsTpNm;
    private String atsSymCdNm;
    private String chkYn;
    private Integer inqSqn;

    @JsonIgnore
    public Class getBusinessClass() {
        return TradeTotalizationRuleEnrollment.class;
    }
}
