package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.evaluation.HedgeAccountEvaluationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RiskAversionAccountingEvaluationDto extends HedgeAccountEvaluationDto {
    private String chkYn;
    private String pcsStsDtt;
    private String errStgTc;
    private String prdNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return RiskAversionAccountingEvaluation.class;
    }
}
