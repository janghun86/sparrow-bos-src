package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.co.NationCodeCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NationalCodePopupDto extends NationCodeCatalogueDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return NationalCodePopup.class;
    }
}
