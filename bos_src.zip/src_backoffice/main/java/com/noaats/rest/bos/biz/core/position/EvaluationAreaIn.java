package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.configuration.EvaluationAreaDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EvaluationAreaIn extends BaseMessage {
    private EvaluationAreaDto evaluationArea = new EvaluationAreaDto();
}
