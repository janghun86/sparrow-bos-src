package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.AccountSubjectCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountSubjectIn extends BaseMessage {
    private AccountSubjectDto accountSubject = new AccountSubjectDto();
    private AccountSubjectCatalogueDto accountSubjectCatalogue = new AccountSubjectCatalogueDto();
}
