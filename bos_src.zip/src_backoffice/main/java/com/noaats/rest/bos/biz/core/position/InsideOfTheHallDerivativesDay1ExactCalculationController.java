package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/inside-of-the-hall")
public class InsideOfTheHallDerivativesDay1ExactCalculationController extends BaseController {

    private final IInsideOfTheHallDerivativesDay1ExactCalculationService<InsideOfTheHallDerivativesDay1ExactCalculation, InsideOfTheHallDerivativesDay1Evaluation> insideOfTheHallDerivativesDay1ExactCalculationService;

    @PostMapping("/day-1-xcl")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<InsideOfTheHallDerivativesDay1ExactCalculationOut> saveDay1Xcl(@RequestBody BaseRequest<InsideOfTheHallDerivativesDay1ExactCalculationIn> request) throws CustomException {
        InsideOfTheHallDerivativesDay1ExactCalculationIn in = request.getData();
        InsideOfTheHallDerivativesDay1ExactCalculationOut out = new InsideOfTheHallDerivativesDay1ExactCalculationOut();

        List<InsideOfTheHallDerivativesDay1Evaluation> insideOfTheHallDerivativesDay1EvaluationList = convertList(in.getInsideOfTheHallDerivativesDay1EvaluationList());

        // 일일정산
        List<InsideOfTheHallDerivativesDay1Evaluation> resultList = insideOfTheHallDerivativesDay1ExactCalculationService.saveDay1Xcl(insideOfTheHallDerivativesDay1EvaluationList);
        out.setInsideOfTheHallDerivativesDay1EvaluationList(resultList);
        out.setInsideOfTheHallDerivativesDay1ExactCalculationList(new ArrayList<>());
        return ResponseEntity.ok(out);
    }

    @PostMapping("/soa-pcs")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<InsideOfTheHallDerivativesDay1ExactCalculationOut> saveSoaPcs(@RequestBody BaseRequest<InsideOfTheHallDerivativesDay1ExactCalculationIn> request) throws CustomException {
        InsideOfTheHallDerivativesDay1ExactCalculationIn in = request.getData();
        InsideOfTheHallDerivativesDay1ExactCalculationOut out = new InsideOfTheHallDerivativesDay1ExactCalculationOut();

        List<InsideOfTheHallDerivativesDay1ExactCalculation> insideOfTheHallDerivativesDay1ExactCalculationList = convertList(in.getInsideOfTheHallDerivativesDay1ExactCalculationList());

        // 결산처리
        List<InsideOfTheHallDerivativesDay1ExactCalculation> resultList = insideOfTheHallDerivativesDay1ExactCalculationService.saveSoaPcs(insideOfTheHallDerivativesDay1ExactCalculationList);
        out.setInsideOfTheHallDerivativesDay1EvaluationList(new ArrayList<>());
        out.setInsideOfTheHallDerivativesDay1ExactCalculationList(resultList);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping("/day-1-xcl")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<InsideOfTheHallDerivativesDay1ExactCalculationOut> cancelDay1Xcl(@RequestBody BaseRequest<InsideOfTheHallDerivativesDay1ExactCalculationIn> request) throws CustomException {
        InsideOfTheHallDerivativesDay1ExactCalculationIn in = request.getData();
        InsideOfTheHallDerivativesDay1ExactCalculationOut out = new InsideOfTheHallDerivativesDay1ExactCalculationOut();

        List<InsideOfTheHallDerivativesDay1Evaluation> insideOfTheHallDerivativesDay1EvaluationList = convertList(in.getInsideOfTheHallDerivativesDay1EvaluationList());

        // 일일정산
        List<InsideOfTheHallDerivativesDay1Evaluation> resultList = insideOfTheHallDerivativesDay1ExactCalculationService.cancelDay1Xcl(insideOfTheHallDerivativesDay1EvaluationList);
        out.setInsideOfTheHallDerivativesDay1EvaluationList(resultList);
        out.setInsideOfTheHallDerivativesDay1ExactCalculationList(new ArrayList<>());
        return ResponseEntity.ok(out);
    }

    @DeleteMapping("/soa-pcs")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<InsideOfTheHallDerivativesDay1ExactCalculationOut> cancelSoaPcs(@RequestBody BaseRequest<InsideOfTheHallDerivativesDay1ExactCalculationIn> request) throws CustomException {
        InsideOfTheHallDerivativesDay1ExactCalculationIn in = request.getData();
        InsideOfTheHallDerivativesDay1ExactCalculationOut out = new InsideOfTheHallDerivativesDay1ExactCalculationOut();

        List<InsideOfTheHallDerivativesDay1ExactCalculation> insideOfTheHallDerivativesDay1ExactCalculationList = convertList(in.getInsideOfTheHallDerivativesDay1ExactCalculationList());

        // 결산처리
        List<InsideOfTheHallDerivativesDay1ExactCalculation> resultList = insideOfTheHallDerivativesDay1ExactCalculationService.cancelSoaPcs(insideOfTheHallDerivativesDay1ExactCalculationList);
        out.setInsideOfTheHallDerivativesDay1EvaluationList(new ArrayList<>());
        out.setInsideOfTheHallDerivativesDay1ExactCalculationList(resultList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/day-1-xcl")
    public ResponseEntity<InsideOfTheHallDerivativesDay1ExactCalculationOut> inquiryDay1Xcl(@RequestBody BaseRequest<InsideOfTheHallDerivativesDay1ExactCalculationIn> request) throws CustomException {
        InsideOfTheHallDerivativesDay1ExactCalculationIn in = request.getData();
        InsideOfTheHallDerivativesDay1ExactCalculationOut out = new InsideOfTheHallDerivativesDay1ExactCalculationOut();

        InsideOfTheHallDerivativesDay1Evaluation insideOfTheHallDerivativesDay1Evaluation = convert(in.getInsideOfTheHallDerivativesDay1Evaluation());

        // 일일정산
        List<InsideOfTheHallDerivativesDay1Evaluation> resultList = insideOfTheHallDerivativesDay1ExactCalculationService.inquiryDay1Xcl(insideOfTheHallDerivativesDay1Evaluation);
        out.setInsideOfTheHallDerivativesDay1EvaluationList(resultList);
        out.setInsideOfTheHallDerivativesDay1ExactCalculationList(new ArrayList<>());
        return ResponseEntity.ok(out);
    }

    @GetMapping("/soa-pcs")
    public ResponseEntity<InsideOfTheHallDerivativesDay1ExactCalculationOut> inquirySoaPcs(@RequestBody BaseRequest<InsideOfTheHallDerivativesDay1ExactCalculationIn> request) throws CustomException {
        InsideOfTheHallDerivativesDay1ExactCalculationIn in = request.getData();
        InsideOfTheHallDerivativesDay1ExactCalculationOut out = new InsideOfTheHallDerivativesDay1ExactCalculationOut();

        InsideOfTheHallDerivativesDay1ExactCalculation insideOfTheHallDerivativesDay1ExactCalculation = convert(in.getInsideOfTheHallDerivativesDay1ExactCalculation());

        // 결산처리
        List<InsideOfTheHallDerivativesDay1ExactCalculation> resultList = insideOfTheHallDerivativesDay1ExactCalculationService.inquirySoaPcs(insideOfTheHallDerivativesDay1ExactCalculation);
        out.setInsideOfTheHallDerivativesDay1EvaluationList(new ArrayList<>());
        out.setInsideOfTheHallDerivativesDay1ExactCalculationList(resultList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/co-cd")
    public ResponseEntity<InsideOfTheHallDerivativesDay1ExactCalculationOut> inquiryCoCd(@RequestBody BaseRequest<InsideOfTheHallDerivativesDay1ExactCalculationIn> request) throws CustomException {
        InsideOfTheHallDerivativesDay1ExactCalculationIn in = request.getData();
        InsideOfTheHallDerivativesDay1ExactCalculationOut out = new InsideOfTheHallDerivativesDay1ExactCalculationOut();

        InsideOfTheHallDerivativesDay1ExactCalculation insideOfTheHallDerivativesDay1ExactCalculation = convert(in.getInsideOfTheHallDerivativesDay1ExactCalculation());

        // 공통코드 조회
        InsideOfTheHallDerivativesDay1ExactCalculation result = insideOfTheHallDerivativesDay1ExactCalculationService.inquiryCoCd(insideOfTheHallDerivativesDay1ExactCalculation);
        out.setEvlAreaList(result.getEvlAreaList());
        out.setAcEvlTpList(result.getAcEvlTpList());
        return ResponseEntity.ok(out);
    }
}
