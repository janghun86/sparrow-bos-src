package com.noaats.rest.bos.biz.account.journalize;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AssetsSlipGenerationOut {
    private AssetsSlipGeneration assetsSlipGeneration;
    private List<AssetsSlipGeneration> assetsSlipGenerationByMerge;
    private AssetsSlipGeneration assetsSlipGenerationForPaging;
    private List<AssetsSlipGeneration> assetsSlipGenerationList;
}
