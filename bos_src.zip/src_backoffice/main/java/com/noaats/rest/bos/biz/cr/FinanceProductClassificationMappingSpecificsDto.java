package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FinanceProductClassificationMappingSpecificsDto extends BaseDto {
    private String prdTpId;
    private String qtaFnoTc;
    private String bizModlTc;
    private String sppiTesTc;
    private String evlTpId;
    private String fvociApmYn;
    private Integer sqn;
    @JsonIgnore
    public Class getBusinessClass() {
        return FinanceProductClassificationMappingSpecifics.class;
    }
}
