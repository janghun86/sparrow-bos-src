package com.noaats.rest.bos.biz.core.position;

import com.noaats.rest.bos.biz.cr.PositionClassificationUnitCatalogue;
import com.noaats.rest.bos.biz.cr.configuration.*;
import com.noaats.rest.bos.biz.cr.position.business.InstitutionCode;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ConfigurationManagementOut {
    private List<TableSchemaInfo> tableSchemaInfoList;
    private ConfigurationManagement configurationManagement;
    private List<AccountManagementGroup> accountManagementGroupList;
    private List<AccountProcessIdentifier> accountProcessIdentifierList;
    private List<AccountProcessIdentifierMapping> accountProcessIdentifierMappingList;
    private List<AmountProcessType> amountProcessTypeList;
    private List<ConditionGroup> conditionGroupList;
    private List<DependencyPositionProcessTypeOutflowOrInflowMapping> dependencyPositionProcessTypeOutflowOrInflowMappingList;
    private List<DependencyPositionProcessTypeRealizationMapping> dependencyPositionProcessTypeRealizationMappingList;
    private List<DependencyPositionProcessTypeTransferMapping> dependencyPositionProcessTypeTransferMappingList;
    private List<EvaluationArea> evaluationAreaList;
    private List<EvaluationAreaMapping> evaluationAreaMappingList;
    private List<EvaluationGroupMapping> evaluationGroupMappingList;
    private List<EvaluationType> evaluationTypeList;
    private List<EvaluationTypeMapping> evaluationTypeMappingList;
    private List<EventCategory> eventCategoryList;
    private List<EventPositionProcessTypeMapping> eventPositionProcessTypeMappingList;
    private List<EventType> eventTypeList;
    private List<FunctionTradeProcessTypeMapping> functionTradeProcessTypeMappingList;
    private List<InstitutionCode> institutionCodeList;
    private List<Portfolio> portfolioList;
    private List<ProductCategory> productCategoryList;
    private List<ProductEvaluationAreaMapping> productEvaluationAreaMappingList;
    private List<ProductEvaluationGroupMapping> productEvaluationGroupMappingList;
    private List<ProductType> productTypeList;
    private List<PositionClassificationUnitCatalogue> positionClassificationUnitCatalogueList;
    private List<PositionEvaluationProcedure> positionEvaluationProcedureList;
    private List<PositionEvaluationProcedureMapping> positionEvaluationProcedureMappingList;
    private List<PositionHeadingConfigurationElementMapping> positionHeadingConfigurationElementMappingList;
    private List<PositionHeading> positionHeadingList;
    private List<PositionProcessType> positionProcessTypeList;
    private List<PositionProcessTypeMapping> positionProcessTypeMappingList;
    private List<PositionTotalizationGroup> positionTotalizationGroupList;
    private List<PositionUniqueNumberMapping> positionUniqueNumberMappingList;
    private List<TradeCategory> tradeCategoryList;
    private List<TradeEventTypeMapping> tradeEventTypeMappingList;
    private List<TradeProcessType> tradeProcessTypeList;
    private List<TradeType> tradeTypeList;
}
