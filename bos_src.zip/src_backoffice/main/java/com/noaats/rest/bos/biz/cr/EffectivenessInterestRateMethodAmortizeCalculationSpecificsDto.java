package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EffectivenessInterestRateMethodAmortizeCalculationSpecificsDto extends BaseDto {
    private String ptTrno;
    private Long sno;
    private String evlAreaId;
    private String bseDt;
    private String ptPcsTpId;
    private String ptPcsTpNm;
    private String curCd;
    private Double amt;
    private String sttDt;
    private String endDt;
    private Integer aplyDds;
    private Double pvAmt;

    @JsonIgnore
    public Class getBusinessClass() {
        return EffectivenessInterestRateMethodAmortizeCalculationSpecifics.class;
    }
}
