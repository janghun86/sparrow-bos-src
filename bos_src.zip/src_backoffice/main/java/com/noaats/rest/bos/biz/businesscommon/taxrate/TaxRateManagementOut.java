package com.noaats.rest.bos.biz.businesscommon.taxrate;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class TaxRateManagementOut {
    private List<TaxRate> taxRateList;
}
