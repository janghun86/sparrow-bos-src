package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductEvaluationGroupMappingDto extends BaseDto {
    private String evlGrpId;
    private String acMngGrpId;
    private String prdTpId;
    private String trTpId;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return ProductEvaluationGroupMapping.class;
    }
}
