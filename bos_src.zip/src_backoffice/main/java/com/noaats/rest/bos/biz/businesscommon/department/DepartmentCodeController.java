package com.noaats.rest.bos.biz.businesscommon.department;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.fw.OrganizationDepartmentCatalogue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/department")
public class DepartmentCodeController extends BaseController {
    private final IDepartmentCodeService<OrganizationDepartmentCatalogue> departmentCodeService;

    @GetMapping
    public ResponseEntity<DepartmentCodeOut> inquiry(@RequestBody BaseRequest<DepartmentCodeIn> request) throws CustomException {
        DepartmentCodeIn in = request.getData();
        DepartmentCodeOut out = new DepartmentCodeOut();
        OrganizationDepartmentCatalogue organizationDepartmentCatalogue = convert(in.getOrganizationDepartmentCatalogue());

        out.setOrganizationDepartmentCatalogueList(departmentCodeService.inquiry(organizationDepartmentCatalogue));
        return ResponseEntity.ok(out);
    }
}
