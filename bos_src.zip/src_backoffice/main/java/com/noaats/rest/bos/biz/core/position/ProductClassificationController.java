package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.IProductClassificationCatalogueService;
import com.noaats.rest.bos.biz.cr.ProductClassificationCatalogue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/product-classification")
public class ProductClassificationController extends BaseController {

    private final IProductClassificationCatalogueService productClassificationCatalogueService;

    @GetMapping
    public ResponseEntity<ProductClassificationOut> findUseAll(@RequestBody BaseRequest<ProductClassificationIn> request) throws CustomException {
        ProductClassificationIn in = request.getData();
        ProductClassificationOut out = new ProductClassificationOut();

        ProductClassificationCatalogue productClassificationCatalogue = convert(in.getProductClassificationCatalogue());

        List<ProductClassificationCatalogue> productClassificationCatalogueList = productClassificationCatalogueService.findUseAll(productClassificationCatalogue);
        out.setProductClassificationCatalogueList(productClassificationCatalogueList);
        return ResponseEntity.ok(out);
    }
}
