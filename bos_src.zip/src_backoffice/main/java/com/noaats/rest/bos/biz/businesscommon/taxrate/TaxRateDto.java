package com.noaats.rest.bos.biz.businesscommon.taxrate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.co.TaxRateBasicDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaxRateDto extends TaxRateBasicDto {
    private String nowDt;
    private String nowAplyTaxYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return TaxRate.class;
    }
}
