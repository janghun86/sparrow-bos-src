package com.noaats.rest.bos.biz.businesscommon.cashflow;

import com.noaats.lib.frk.mci.BaseMessage;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class CashFlowRegenerationIn extends BaseMessage {
    private CashFlowRegenerationDto cashFlowRegeneration = new CashFlowRegenerationDto();
    private FlexibleInterestRateDto flexibleInterestRate = new FlexibleInterestRateDto();
    private List<CashFlowRegenerationDto> cashFlowRegenerationList = new ArrayList<>();
    private List<FlexibleInterestRateDto> flexibleInterestRateList = new ArrayList<>();
}
