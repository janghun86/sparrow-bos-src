package com.noaats.rest.bos.biz.cr.evaluation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.EffectivenessInterestRateMethodAmortizeSpecificsDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EffectivenessInterestRateMethodAmortizeDto extends EffectivenessInterestRateMethodAmortizeSpecificsDto {
    private String acMngGrpId;
    private String evlAreaId;
    private String evlTpId;
    private String pofId;
    private String prdNo;
    private String ptTlzGrpId;
    private String ptTlzId;
    private Long dpsIstCptyNo;
    private String bseDt;

    @JsonIgnore
    public Class getBusinessClass() {
        return EffectivenessInterestRateMethodAmortize.class;
    }
}
