package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountProcessIdentifierMappingSpecificsDto extends BaseDto {
    private String acMngGrpId;
    private String acEvlTpId;
    private String prdTpId;
    private String scrsClsTc;
    private String bdClsTc;
    private String trTpId;
    private String curTc;
    private String grtTc;
    private String aflTc;
    private String bkgCttYn;
    private String acPcsIdfrId;
    private String evlAreaId;

    @JsonIgnore
    public Class getBusinessClass() {
        return AccountProcessIdentifierMappingSpecifics.class;
    }
}
