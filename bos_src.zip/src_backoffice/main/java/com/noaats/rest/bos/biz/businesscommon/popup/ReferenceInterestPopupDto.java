package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class ReferenceInterestPopupDto extends BaseDto {
    private String istCd;
    private String rfrIrtCd;
    private String rfrIrtNm;
    private String curCd;
    private String irtTrm;
    private String trmUntTc;
    private String irtKdTc;
    private String crn1IrtCd;
    private String crn2IrtCd;
    private String crn3IrtCd;
    private String crn4IrtCd;
    private Integer avrDds;
    private String delYn;
    private String fstEnrUsid;
    private String fstEnrTrid;
    private String fstEnrIp;
    private String lstChgUsid;
    private String lstChgTrid;
    private String lstChgIp;

    @JsonIgnore
    public Class getBusinessClass() {
        return ReferenceInterestPopup.class;
    }
}
