package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionInformationIn extends BaseMessage {
    private PositionInformationDto positionInformation = new PositionInformationDto();
}
