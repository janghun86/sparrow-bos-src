package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.configuration.PositionTotalizationGroupDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationGroupIn extends BaseMessage {
    private PositionTotalizationGroupDto positionTotalizationGroup = new PositionTotalizationGroupDto();
}
