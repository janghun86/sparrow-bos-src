package com.noaats.rest.bos.biz.businesscommon.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizationUserSearchPopupDto extends BaseDto {
    private String usid;
    private String usrNm;
    private String usrEnlNm;
    private String eno;
    private String hdoTc;
    private String usrStsTc;
    private String usrBltTc;
    private String usrCpnCd;
    private String pscCd;
    private String pscNm;
    private String dtyCd;
    private String dtyNm;
    private String temCd;
    private String sftTpn;
    private String emlAdr;
    private String pwd;
    private String pwdStsTc;
    private Integer pwdErrCnt;
    private String isLeaf;
    private Integer lvl;
    private String dpmCd;
    private String hrkDpmCd;
    private String dpmNm;
    private Integer sotSqn;
    private String sttDt;
    private String endDt;
    private String chkYn;
    private String temNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return OrganizationUserSearchPopup.class;
    }
}
