package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.tr.evaluation.InsideOfTheHallDerivativesSettlementOfAccountsProcessDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InsideOfTheHallDerivativesDay1ExactCalculationDto extends InsideOfTheHallDerivativesSettlementOfAccountsProcessDto {
    private String chkYn;
    private String pcsStsDtt;
    private String errStgTc;
    private String coCva;
    private String coCvaNm;
    private String day1XclTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return InsideOfTheHallDerivativesDay1ExactCalculation.class;
    }
}
