package com.noaats.rest.bos.biz.core.position;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ReceivableEvaluationProcessOut {
    private ReceivableEvaluationProcess receivableEvaluationProcess;
    private List<ReceivableEvaluationProcess> receivableEvaluationProcessList;
}
