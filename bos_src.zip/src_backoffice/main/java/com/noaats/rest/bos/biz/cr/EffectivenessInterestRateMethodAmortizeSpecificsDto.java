package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EffectivenessInterestRateMethodAmortizeSpecificsDto extends BaseDto {
    private String ptTrno;
    private String evlAreaId;
    private String bseDt;
    private String jbefAmrDt;
    private Double eir;
    private String curCd;
    private Double jbefAmafAcqAmt;
    private Double jbefRcbIntAmt;
    private Double pvAmt;
    private Double rcbIntAmt;
    private Double amrAmt;

    @JsonIgnore
    public Class getBusinessClass() {
        return EffectivenessInterestRateMethodAmortizeSpecifics.class;
    }
}
