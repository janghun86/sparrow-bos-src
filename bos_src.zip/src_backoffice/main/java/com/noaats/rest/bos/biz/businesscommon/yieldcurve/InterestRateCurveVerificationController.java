package com.noaats.rest.bos.biz.businesscommon.yieldcurve;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/yieldcurve/verification")
public class InterestRateCurveVerificationController extends BaseController {

    private final IInterestRateCurveVerificationService<InterestRateCurveVerification> interestRateCurveVerificationService;

    @GetMapping
    public ResponseEntity<InterestRateCurveVerificationOut> inquiry(@RequestBody BaseRequest<InterestRateCurveVerificationIn> request) throws CustomException {
        InterestRateCurveVerificationIn in = request.getData();
        InterestRateCurveVerificationOut out = new InterestRateCurveVerificationOut();
        // convert
        InterestRateCurveVerification interestRateCurveVerification = convert(in.getInterestRateCurveVerification());

        List<InterestRateCurveVerification> resultList = interestRateCurveVerificationService.inquiry(interestRateCurveVerification);
        out.setInterestRateCurveVerificationList(resultList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/calculate")
    public ResponseEntity<InterestRateCurveVerificationOut> calculate(@RequestBody BaseRequest<InterestRateCurveVerificationIn> request) throws CustomException {
        InterestRateCurveVerificationIn in = request.getData();
        InterestRateCurveVerificationOut out = new InterestRateCurveVerificationOut();
        // convert
        InterestRateCurveVerification interestRateCurveVerification = convert(in.getInterestRateCurveVerification());
        InterestRateCurveVerification result = interestRateCurveVerificationService.calculate(interestRateCurveVerification);
        out.setInterestRateCurveVerificationList(result.getInterestRateCurveVerificationList());
        out.setInterestRateCurveCalculationList(result.getInterestRateCurveCalculationList());
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<InterestRateCurveVerificationOut> registration(@RequestBody BaseRequest<InterestRateCurveVerificationIn> request) throws CustomException {
        InterestRateCurveVerificationIn in = request.getData();
        InterestRateCurveVerificationOut out = new InterestRateCurveVerificationOut();
        // convert
        InterestRateCurveVerification interestRateCurveVerification = convert(in.getInterestRateCurveVerification());
        List<InterestRateCurveVerification> interestRateCurveVerificationList = convertList(in.getInterestRateCurveVerificationList());

        interestRateCurveVerification.setInterestRateCurveVerificationList(interestRateCurveVerificationList);
        interestRateCurveVerificationService.registration(interestRateCurveVerification);
        return ResponseEntity.ok(out);
    }
}
