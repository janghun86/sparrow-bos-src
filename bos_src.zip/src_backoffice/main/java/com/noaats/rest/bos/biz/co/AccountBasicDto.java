package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountBasicDto extends BaseDto {
    private String actTc;
    private Long cptyNo;
    private String ano;
    private Integer vrs;
    private String curCd;
    private String actNm;
    private Long actOpnIstNo;
    private String acMngGrpId;
    private String ptTlzGrpId;
    private String moAno;
    private String aplyEndDt;
    private String aplySttDt;
    private String pofId;
    private String bblMngYn;
    private String ptTlzUseYn;
    private Long lnkTrno;
    private String asjCd;
    private String prdTpId;
    private String ntnCd;
    private String bicCd;
    private String dpwNm;
    private String dpwNmCrmYn;
    private String tpn;

    @JsonIgnore
    public Class getBusinessClass() {
        return AccountBasic.class;
    }
}
