package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.ip.ProjectBasicDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProjectPopupDto extends ProjectBasicDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return ProjectPopup.class;
    }
}
