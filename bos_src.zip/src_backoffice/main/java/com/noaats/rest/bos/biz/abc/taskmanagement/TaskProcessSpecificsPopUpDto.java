package com.noaats.rest.bos.biz.abc.taskmanagement;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaskProcessSpecificsPopUpDto extends BaseDto {
    private String sttDt;
    private String endDt;
    private String tskSvcId;
    private long seqlNo;
    private String tskUnqId;
    private String lstChgUsrNm;
    private String fsgYn;
    private long sno;
    private String mmoCts;

    @JsonIgnore
    public Class getBusinessClass() {
        return TaskProcessSpecificsPopUp.class;
    }
}
