package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MarketEvaluationUnitPriceBasicDto extends BaseDto {
    private String bseDt;
    private String prdTpId;
    private String prdNo;
    private String evlUprTpId;
    private Integer vrs;
    private Double evlUpr;
    private String curCd;
    private String rmk;

    @JsonIgnore
    public Class getBusinessClass() {
        return MarketEvaluationUnitPriceBasic.class;
    }
}
