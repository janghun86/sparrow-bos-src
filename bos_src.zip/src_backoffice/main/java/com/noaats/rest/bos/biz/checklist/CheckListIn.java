package com.noaats.rest.bos.biz.checklist;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.co.checklist.CheckListCheckingResultValueSpecifics;
import com.noaats.rest.bos.biz.workstation.trade.workstation.ChoiceHeadingSpecificsDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class CheckListIn extends BaseMessage {
    private ChoiceHeadingSpecificsDto choiceHeadingSpecifics = new ChoiceHeadingSpecificsDto();
    private List<ChoiceHeadingSpecificsDto> choiceHeadingSpecificsList = new ArrayList<ChoiceHeadingSpecificsDto>();
    private CheckListCatalogueDto checkListCatalogue = new CheckListCatalogueDto();
    private List<CheckListClassifiedByProcedureCatalogueDto> checkListClassifiedByProcedureCatalogueList = new ArrayList<CheckListClassifiedByProcedureCatalogueDto>();
    private List<CheckListProcedureClassifiedByColumnCatalogueDto> checkListProcedureClassifiedByColumnCatalogueList = new ArrayList<CheckListProcedureClassifiedByColumnCatalogueDto>();
    private List<CheckListProcedureClassifiedByCheckingHeadingCatalogueDto> checkListProcedureClassifiedByCheckingHeadingCatalogueList = new ArrayList<CheckListProcedureClassifiedByCheckingHeadingCatalogueDto>();
    private CheckListCheckingResultCatalogueDto checkListCheckingResultCatalogue = new CheckListCheckingResultCatalogueDto();
    private List<CheckListCheckingResultValueSpecificsDto> checkListCheckingResultValueSpecificsList = new ArrayList<CheckListCheckingResultValueSpecificsDto>();
}
