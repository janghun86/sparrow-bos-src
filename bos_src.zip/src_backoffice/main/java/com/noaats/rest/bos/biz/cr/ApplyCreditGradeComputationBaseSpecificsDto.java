package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplyCreditGradeComputationBaseSpecificsDto extends BaseDto {
    private String aplyCrdGrUsgTc;
    private Integer vrs;
    private String crdGrTc;
    private String crdGrClsTc;
    private String aplyCrdGrCpuTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return ApplyCreditGradeComputationBaseSpecifics.class;
    }
}
