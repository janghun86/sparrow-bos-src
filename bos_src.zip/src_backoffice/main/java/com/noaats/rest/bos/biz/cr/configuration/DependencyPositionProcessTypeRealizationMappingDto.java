package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DependencyPositionProcessTypeRealizationMappingDto extends BaseDto {
    private String dpdMpnTpId;
    private String dpdMpnTpNm;
    private String nftDpdTpId;
    private String nftPtPcsTpId;
    private String plnOtfDpdTpId;
    private String plnOtfPtPcsTpId;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return DependencyPositionProcessTypeRealizationMapping.class;
    }
}
