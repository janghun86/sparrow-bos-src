package com.noaats.rest.bos.biz.checklist;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import com.noaats.rest.bos.biz.co.checklist.CheckListCatalogue;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckListCatalogueDto extends BaseDto {
    private String cklId;
    private Integer vrs;
    private String cklNm;
    @JsonIgnore
    public Class getBusinessClass() {
        return CheckListCatalogue.class;
    }
}
