package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.configuration.AccountManagementGroupDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountManagementGroupIn extends BaseMessage {
    private AccountManagementGroupDto accountManagementGroup = new AccountManagementGroupDto();
}
