package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeClassificationDto extends BaseDto {
    private String istCd;
    private String delYn;
    private String prdClsId;
    private String trClsId;
    private String trClsNm;
    private String prdTpId;

    @JsonIgnore
    public Class getBusinessClass() {
        return TradeClassification.class;
    }
}
