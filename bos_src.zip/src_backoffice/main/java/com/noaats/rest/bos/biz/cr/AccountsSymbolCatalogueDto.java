package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountsSymbolCatalogueDto extends BaseDto {
    private String asjTblCd;
    private String atsSymCd;
    private String atsSymCdNm;
    private String pnlClsCd;
    private String pnlClsNm;
    private String drCdsTc;
    private String ustAtsYn;
    private String cshCrnYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return AccountsSymbolCatalogue.class;
    }
}
