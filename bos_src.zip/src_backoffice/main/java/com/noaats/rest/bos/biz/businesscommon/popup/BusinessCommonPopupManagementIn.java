package com.noaats.rest.bos.biz.businesscommon.popup;

import com.noaats.lib.frk.mci.BaseMessage;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BusinessCommonPopupManagementIn extends BaseMessage {
    private CounterpartyPopupDto counterpartyPopup = new CounterpartyPopupDto();
    private CurrencyCodePopupDto currencyCodePopup = new CurrencyCodePopupDto();
    private NationalCodePopupDto nationalCodePopup = new NationalCodePopupDto();
    private UserPopupDto userPopup = new UserPopupDto();
    private AgreementPopupDto agreementPopup = new AgreementPopupDto();
    private ThisCompanyAccountPopupDto thisCompanyAccountPopup = new ThisCompanyAccountPopupDto();
    private DepositSitePopupDto depositSitePopup = new DepositSitePopupDto();
    private TrustAccountPopupDto trustAccountPopup = new TrustAccountPopupDto();
    private SettlementAccountPopupDto settlementAccountPopup = new SettlementAccountPopupDto();
    private DepartmentPopupDto departmentPopup = new DepartmentPopupDto();
    private HeadquarterPopupDto headquarterPopup = new HeadquarterPopupDto();
    private ProjectPopupDto projectPopup = new ProjectPopupDto();
    private BorrowerPopupDto borrowerPopup = new BorrowerPopupDto();
    private TranchePopupDto tranchePopup = new TranchePopupDto();
    private PublishInstitutionPopupDto publishInstitutionPopup = new PublishInstitutionPopupDto();
    private MarketTypesOfBusinessPopupDto marketTypesOfBusinessPopup = new MarketTypesOfBusinessPopupDto();
    private HolidayPopupDto holidayPopup = new HolidayPopupDto();
    private BusinessIdentificationPopupDto businessIdentificationPopup = new BusinessIdentificationPopupDto();
    private ReferenceInterestPopupDto referenceInterestPopup = new ReferenceInterestPopupDto();
    private ManagementTeamDto managementTeam = new ManagementTeamDto();
    private StandardIndustryClassificationPopupDto standardIndustryClassificationPopup = new StandardIndustryClassificationPopupDto();
    private TradeBankPopupDto tradeBankPopup = new TradeBankPopupDto();
    private TablePopupDto tablePopup = new TablePopupDto();
}
