package com.noaats.rest.bos.biz.businesscommon.account;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/account")
public class AccountEnrollmentManagementController extends BaseController {

    private final IAccountEnrollmentManagementService<AccountEnrollmentManagement> accountEnrollmentManagementService;

    @GetMapping
    public ResponseEntity<AccountEnrollmentManagementOut> inquiry(@RequestBody BaseRequest<AccountEnrollmentManagementIn> request) throws CustomException {
        AccountEnrollmentManagementIn in = request.getData();
        AccountEnrollmentManagementOut out = new AccountEnrollmentManagementOut();
        AccountEnrollmentManagement accountEnrollmentmanagement = new AccountEnrollmentManagement();
        // convert
        AccountEnrollment accountEnrollment = convert(in.getAccountEnrollment());

        accountEnrollmentmanagement.setAccountEnrollment(accountEnrollment);
        BeanUtils.copyProperties(accountEnrollmentManagementService.inquiry(accountEnrollmentmanagement), out);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<AccountEnrollmentManagementOut> registration(@RequestBody BaseRequest<AccountEnrollmentManagementIn> request) throws CustomException {
        AccountEnrollmentManagementIn in = request.getData();
        AccountEnrollmentManagementOut out = new AccountEnrollmentManagementOut();
        AccountEnrollmentManagement accountEnrollmentmanagement = new AccountEnrollmentManagement();
        // convert
        AccountEnrollment accountEnrollment = convert(in.getAccountEnrollment());

        accountEnrollmentmanagement.setAccountEnrollment(accountEnrollment);
        accountEnrollmentManagementService.registration(accountEnrollmentmanagement);
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<AccountEnrollmentManagementOut> modify(@RequestBody BaseRequest<AccountEnrollmentManagementIn> request) throws CustomException {
        AccountEnrollmentManagementIn in = request.getData();
        AccountEnrollmentManagementOut out = new AccountEnrollmentManagementOut();
        AccountEnrollmentManagement accountEnrollmentmanagement = new AccountEnrollmentManagement();
        // convert
        AccountEnrollment accountEnrollment = convert(in.getAccountEnrollment());

        accountEnrollmentmanagement.setAccountEnrollment(accountEnrollment);
        accountEnrollmentManagementService.modify(accountEnrollmentmanagement);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<AccountEnrollmentManagementOut> cancel(@RequestBody BaseRequest<AccountEnrollmentManagementIn> request) throws CustomException {
        AccountEnrollmentManagementIn in = request.getData();
        AccountEnrollmentManagementOut out = new AccountEnrollmentManagementOut();
        AccountEnrollmentManagement accountEnrollmentmanagement = new AccountEnrollmentManagement();
        // convert
        AccountEnrollment accountEnrollment = convert(in.getAccountEnrollment());

        accountEnrollmentmanagement.setAccountEnrollment(accountEnrollment);
        accountEnrollmentManagementService.cancel(accountEnrollmentmanagement);
        return ResponseEntity.ok(out);
    }
}
