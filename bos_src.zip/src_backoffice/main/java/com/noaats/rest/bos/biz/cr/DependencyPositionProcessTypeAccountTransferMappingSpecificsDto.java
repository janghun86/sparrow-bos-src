package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DependencyPositionProcessTypeAccountTransferMappingSpecificsDto extends BaseDto {
    private String ptEvlPcdrId;
    private String dpdMpnTpId;
    private String dpdMpnTpNm;
    private String pnbDlvyDpdTpId;
    private String pnbDlvyPtPcsTpId;
    private String pnbStoDpdTpId;
    private String pnbStoPtPcsTpId;
    private String nnbDlvyDpdTpId;
    private String nnbDlvyPtPcsTpId;
    private String nnbStoDpdTpId;
    private String nnbStoPtPcsTpId;

    @JsonIgnore
    public Class getBusinessClass() {
        return DependencyPositionProcessTypeAccountTransferMappingSpecifics.class;
    }
}
