package com.noaats.rest.bos.biz.core.position;

import com.noaats.rest.bos.biz.cr.configuration.AccountManagementGroup;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AccountManagementGroupOut {
    private List<AccountManagementGroup> accountManagementGroupList;
}
