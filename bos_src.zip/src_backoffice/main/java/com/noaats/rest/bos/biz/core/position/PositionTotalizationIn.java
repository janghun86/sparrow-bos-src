package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.position.PositionTotalizationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationIn extends BaseMessage {
    private PositionTotalizationDto positionTotalization = new PositionTotalizationDto();
}
