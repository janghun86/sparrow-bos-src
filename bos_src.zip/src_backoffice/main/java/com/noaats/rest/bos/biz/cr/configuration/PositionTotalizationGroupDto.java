package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationGroupDto extends BaseDto {
    private String ptTlzGrpId;
    private String acMngGrpId;
    private String ptTlzGrpNm;
    private String bkgCttYn;
    private String enrUsnm;
    private String apvUsnm;
    private String subCrgUsnm;
    private String mainCrgUsnm;
    private String dvmUsnm;
    private String dpmNm;
    private String hdqNm;
    private String aplyDt;
    private String hdqCd;
    private String dpmCd;
    private String apvUsid;
    private String dvmUsid;
    private String mainCrgUsid;
    private String enrUsid;
    private String subCrgUsid;
    private Integer vrs;
    private String bizPrgStsTc;
    private String prjTgtYn;
    private String prjId;
    private String bizGrpCd;
    private String bizCls1Tc;
    private String bizCls2Tc;
    private String bizCls3Tc;
    private String ivTp1Tc;
    private String ivTp2Tc;
    private String hbrdTc;
    private String ivAreTc;
    private String ivAtrTc;
    private String ivFml1Tc;
    private String ivFml2Tc;
    private String cflAtrTc;
    private Long rndCptyNo;
    private String rndCptyNm;
    private String moAno;
    private String vaNo;
    private String vaNm;
    private String hdgSgcTc;
    private String bizSttDt;
    private String bizXrtDt;
    private String fndSttDt;
    private String fndXrtDt;
    private String fndIvSttDt;
    private String fndIvXrtDt;
    private String ivFunTc;
    private String bfdBseIvCurCd;
    private Double bfdBseIvAmt;
    private Double bfdBseNwIvAmt;
    private Double bfdBseReIvAmt;
    private Double bfdBseIrrRor;
    private String bfdBseIrrRorCts;
    private String amsBseDt;
    private String amsEnrUsid;
    private String rlsBseDt;
    private String rlsEnrUsid;
    private String ivTrmtDt;
    private String ivTrmtUsid;
    private String bizTrmtTc;
    private String bizTrmtDt;
    private String bizTrmtUsid;
    private String piAnlTrmtDt;
    private String piAnlTrmtUsid;
    private String splMngBizTc;
    private String ivFun1BseYy;
    private Double ivFun1Amt;
    private String ivFun2BseYy;
    private Double ivFun2Amt;
    private String evlTpId;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionTotalizationGroup.class;
    }
}
