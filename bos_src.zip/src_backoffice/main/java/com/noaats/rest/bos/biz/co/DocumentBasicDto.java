package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentBasicDto extends BaseDto {
    private String docMngNo;
    private String fstDocKpnNm;
    private Integer vrs;
    private String docKpnNm;
    private String docNm;
    private String docFlNm;
    private Long docFlSize;
    private String hrkPthNm;
    private String flPthNm;
    private String enrDt;
    private String infIcEnrDocYn;
    private String cclYn;
    private String cclRsnCts;

    @JsonIgnore
    public Class getBusinessClass() {
        return DocumentBasic.class;
    }
}
