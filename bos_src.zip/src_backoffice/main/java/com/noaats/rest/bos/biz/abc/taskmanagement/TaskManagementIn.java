package com.noaats.rest.bos.biz.abc.taskmanagement;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.tr.ServiceFunctionBasicDto;
import com.noaats.rest.bos.biz.tr.TaskBasicDto;
import com.noaats.rest.bos.biz.tr.TaskServiceMappingSpecificsDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class TaskManagementIn extends BaseMessage {
    private TaskManagementDto taskManagement = new TaskManagementDto();
    private TaskBasicDto taskBasic = new TaskBasicDto();
    private List<TaskServiceMappingSpecificsDto> serviceMappingList = new ArrayList<>();
    private ServiceFunctionBasicDto serviceFunctionBasic = new ServiceFunctionBasicDto();
}
