package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.position.positionbalance.PositionBalanceDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionManagementBaseModifyDto extends PositionBalanceDto {
    private String prdNm;
    private String jrnStsTc;
    private String ptAplyDt;
    private String dpsIstCptyNm;
    private String acPcsIdfrNm;
    private String chgAcPcsIdfrNm;
    private String chgEvlTpNm;
    private String chgPtTlzGrpNm;
    private String chgDpsIstCptyNm;
    private Long dpsIstCptyNo;
    private String acPcsIdfrId;
    private Double untNbr;
    private String chgAcPcsIdfrId;
    private Long chgDpsIstCptyNo;
    private String chgPtTlzGrpId;
    private String chgPtTlzId;
    private String chgEvlTpId;
    private String bseDt;
    private String delYn;
    private String istCd;
    private String ptTrno;
    private Double chgParAmt;
    private Double chgUntNbr;
    private String ptChgTc;
    private String evlAreaId;
    private String prdNo;
    private String ptTlzId;
    private String ptCurCd;
    private Double parAmt;
    private String evlTpId;
    private String ptTlzGrpId;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionManagementBaseModify.class;
    }
}
