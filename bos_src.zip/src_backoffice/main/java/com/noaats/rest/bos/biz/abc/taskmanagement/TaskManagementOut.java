package com.noaats.rest.bos.biz.abc.taskmanagement;

import com.noaats.rest.bos.biz.tr.TaskBasic;
import com.noaats.rest.bos.biz.tr.TaskKeyWordMappingSpecifics;
import com.noaats.rest.bos.biz.tr.TaskServiceMappingSpecifics;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class TaskManagementOut {
    private List<TaskTree> taskTree;
    private TaskManagement taskManagement;
    private TaskBasic taskBasic;
    private List<TaskServiceMappingSpecifics> serviceMappingList;
    private List<ServiceFunctionManagement> serviceList;
    private List<TaskKeyWordMappingSpecifics> keyWordList;
}
