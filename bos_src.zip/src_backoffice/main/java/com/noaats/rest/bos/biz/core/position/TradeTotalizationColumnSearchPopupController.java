package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/trade-totalization-column")
public class TradeTotalizationColumnSearchPopupController extends BaseController {

    private final ITradeTotalizationColumnSearchPopupService<TradeTotalizationColumnSearchPopup> tradeTotalizationColumnSearchPopupService;

    @GetMapping
    public ResponseEntity<TradeTotalizationColumnSearchPopupOut> inquiry(@RequestBody BaseRequest<TradeTotalizationColumnSearchPopupIn> request) throws CustomException {
        TradeTotalizationColumnSearchPopupIn in = request.getData();
        TradeTotalizationColumnSearchPopupOut out = new TradeTotalizationColumnSearchPopupOut();
        // convert
        TradeTotalizationColumnSearchPopup tradeTotalizationColumnSearchPopup = convert(in.getTradeTotalizationColumnSearchPopup());

        List<TradeTotalizationColumnSearchPopup> resultList = tradeTotalizationColumnSearchPopupService.inquiry(tradeTotalizationColumnSearchPopup);
        out.setTradeTotalizationColumnSearchPopup(resultList);
        return ResponseEntity.ok(out);
    }
}
