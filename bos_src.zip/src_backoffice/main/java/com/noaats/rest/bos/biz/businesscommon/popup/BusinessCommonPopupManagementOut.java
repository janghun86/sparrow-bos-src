package com.noaats.rest.bos.biz.businesscommon.popup;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class BusinessCommonPopupManagementOut {
    private List<CounterpartyPopup> counterpartyPopupList;
    private List<CurrencyCodePopup> currencyCodePopupList;
    private List<NationalCodePopup> nationalCodePopupList;
    private List<UserPopup> userPopupList;
    private List<AgreementPopup> agreementPopupList;
    private List<ThisCompanyAccountPopup> thisCompanyAccountPopupList;
    private List<DepositSitePopup> depositSitePopupList;
    private List<TrustAccountPopup> trustAccountPopupList;
    private List<SettlementAccountPopup> settlementAccountPopupList;
    private List<DepartmentPopup> departmentPopupList;
    private List<HeadquarterPopup> headquarterPopupList;
    private List<ProjectPopup> projectPopupList;
    private List<BorrowerPopup> borrowerPopupList;
    private List<TranchePopup> tranchePopupList;
    private List<PublishInstitutionPopup> publishInstitutionPopupList;
    private List<MarketTypesOfBusinessPopup> marketTypesOfBusinessPopupList;
    private List<HolidayPopup> holidayPopupList;
    private List<BusinessIdentificationPopup> businessIdentificationPopupList;
    private List<ReferenceInterestPopup> referenceInterestPopupList;
    private List<ManagementTeam> managementTeamList;
    private List<StandardIndustryClassificationPopup> standardIndustryClassificationPopupList;
    private List<TradeBankPopup> tradeBankPopupList;
    private List<TablePopup> tablePopupList;
}
