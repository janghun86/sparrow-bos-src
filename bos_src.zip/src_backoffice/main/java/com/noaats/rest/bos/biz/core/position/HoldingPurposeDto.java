package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HoldingPurposeDto extends BaseDto {
    private String evlTpNm;
    private String evlTpId;
    private String istCd;
    private String delYn;
    private String fstEnrIp;
    private String lstChgIp;
    private String fstEnrTrid;
    private String lstChgTrid;
    private String fstEnrUsid;
    private String lstChgUsid;
    private String evlGrpId;
    private String evlGrpIdList;

    @JsonIgnore
    public Class getBusinessClass() {
        return HoldingPurpose.class;
    }
}
