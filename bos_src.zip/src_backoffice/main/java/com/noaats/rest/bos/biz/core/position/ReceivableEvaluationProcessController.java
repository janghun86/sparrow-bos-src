/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <pre>
 *
 * description : 미수평가처리
 *
 * com.noaats.sol.controller.core.position
 *    ReceivableEvaluationProcessController.java
 *
 * </pre>
 *
 * @author : jh86@noaats.com
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2020. 7. 14.	jh86@noaats.com		최초생성
 *
 * </pre>
 * @version :
 * @date : 2020. 7. 14. 오전 11:31:44
 */

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/receivable-evaluation")
public class ReceivableEvaluationProcessController extends BaseController {

    private final IReceivableEvaluationProcessService<ReceivableEvaluationProcess> receivableEvaluationProcessService;

    /**
     * <pre>
     * description : 평가처리
     * </pre>
     *
     * @throws Exception
     * @date : 2020. 7. 14.
     * @author : jh86@noaats.com
     */
    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<ReceivableEvaluationProcessOut> registration(@RequestBody BaseRequest<ReceivableEvaluationProcessIn> request) throws CustomException {
        ReceivableEvaluationProcessIn in = request.getData();
        ReceivableEvaluationProcessOut out = new ReceivableEvaluationProcessOut();
        // convert
        List<ReceivableEvaluationProcess> receivableEvaluationProcessList = convertList(in.getReceivableEvaluationProcessList());

        List<ReceivableEvaluationProcess> resultList = receivableEvaluationProcessService.registration(receivableEvaluationProcessList);
        out.setReceivableEvaluationProcessList(resultList);
        return ResponseEntity.ok(out);
    }

    /**
     * <pre>
     * description : 평가처리대상 조회
     * </pre>
     *
     * @throws Exception
     * @date : 2020. 7. 14.
     * @author : jh86@noaats.com
     */
    @GetMapping
    public ResponseEntity<ReceivableEvaluationProcessOut> inquiry(@RequestBody BaseRequest<ReceivableEvaluationProcessIn> request) throws CustomException {
        ReceivableEvaluationProcessIn in = request.getData();
        ReceivableEvaluationProcessOut out = new ReceivableEvaluationProcessOut();
        // convert
        ReceivableEvaluationProcess receivableEvaluationProcess = convert(in.getReceivableEvaluationProcess());

        List<ReceivableEvaluationProcess> resultList = receivableEvaluationProcessService.inquiry(receivableEvaluationProcess);
        out.setReceivableEvaluationProcessList(resultList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/simulation")
    public ResponseEntity<ReceivableEvaluationProcessOut> simulation(@RequestBody BaseRequest<ReceivableEvaluationProcessIn> request) throws CustomException {
        ReceivableEvaluationProcessIn in = request.getData();
        ReceivableEvaluationProcessOut out = new ReceivableEvaluationProcessOut();
        // convert
        ReceivableEvaluationProcess receivableEvaluationProcess = convert(in.getReceivableEvaluationProcess());

        List<ReceivableEvaluationProcess> resultList = receivableEvaluationProcessService.simulation((ReceivableEvaluationProcess) receivableEvaluationProcess);
        out.setReceivableEvaluationProcessList(resultList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/calculation")
    public ResponseEntity<ReceivableEvaluationProcessOut> reCalculation(@RequestBody BaseRequest<ReceivableEvaluationProcessIn> request) throws CustomException {
        ReceivableEvaluationProcessIn in = request.getData();
        ReceivableEvaluationProcessOut out = new ReceivableEvaluationProcessOut();
        // convert
        ReceivableEvaluationProcess receivableEvaluationProcess = convert(in.getReceivableEvaluationProcess());

        ReceivableEvaluationProcess resultList = receivableEvaluationProcessService.reCalculation(receivableEvaluationProcess);
        out.setReceivableEvaluationProcess(resultList);
        return ResponseEntity.ok(out);
    }

    /**
     * <pre>
     * description : 미수처리 취소
     * </pre>
     *
     * @throws Exception
     * @date : 2020. 7. 22.
     * @author : jh86@noaats.com
     */
    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<ReceivableEvaluationProcessOut> delete(@RequestBody BaseRequest<ReceivableEvaluationProcessIn> request) throws CustomException {
        ReceivableEvaluationProcessIn in = request.getData();
        ReceivableEvaluationProcessOut out = new ReceivableEvaluationProcessOut();
        // convert
        List<ReceivableEvaluationProcess> receivableEvaluationProcessList = convertList(in.getReceivableEvaluationProcessList());

        receivableEvaluationProcessService.cancel(receivableEvaluationProcessList);
        out.setReceivableEvaluationProcessList(receivableEvaluationProcessList);
        return ResponseEntity.ok(out);
    }
}
