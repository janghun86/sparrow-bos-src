package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EventCategoryDto extends BaseDto {
    private String evtGrpTc;
    private String evtClsNm;
    private String evtClsId;
    private String flwClsUseYn;
    private String cndClsUseYn;
    private String calClsId;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return EventCategory.class;
    }
}
