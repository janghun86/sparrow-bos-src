package com.noaats.rest.bos.biz.businesscommon.amount;

import com.noaats.lib.frk.mci.BaseMessage;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class AmountMappingInformationManagementIn extends BaseMessage {
    private AmountMappingInformationManagementDto amountMappingInformationManagement = new AmountMappingInformationManagementDto();
    private List<AmountMappingInformationManagementDto> amountMappingInformationManagementList = new ArrayList<>();
}
