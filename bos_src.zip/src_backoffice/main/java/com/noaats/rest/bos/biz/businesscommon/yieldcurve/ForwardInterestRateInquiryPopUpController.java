package com.noaats.rest.bos.biz.businesscommon.yieldcurve;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/yieldcurve/forward")
public class ForwardInterestRateInquiryPopUpController extends BaseController {

    private final IForwardInterestRateInquiryPopUpService<ForwardInterestRateInquiryPopUp> forwardInterestRateInquiryPopUpService;

    @GetMapping
    public ResponseEntity<ForwardInterestRateInquiryPopUpOut> service(@RequestBody BaseRequest<ForwardInterestRateInquiryPopUpIn> request) throws CustomException {
        ForwardInterestRateInquiryPopUpIn in = request.getData();
        ForwardInterestRateInquiryPopUpOut out = new ForwardInterestRateInquiryPopUpOut();
        // convert
        ForwardInterestRateInquiryPopUp forwardInterestRateInquiryPopUp = convert(in.getForwardInterestRateInquiryPopUp());

        List<ForwardInterestRateInquiryPopUp> result = forwardInterestRateInquiryPopUpService.inquiry(forwardInterestRateInquiryPopUp);
        out.setForwardInterestRateInquiryPopUp(result);
        return ResponseEntity.ok(out);
    }
}
