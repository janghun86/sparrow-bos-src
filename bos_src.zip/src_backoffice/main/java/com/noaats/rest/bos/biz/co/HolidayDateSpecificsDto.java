package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HolidayDateSpecificsDto extends BaseDto {
    private String hddCd;
    private String hddDt;
    private String hddNm;
    private String bsdTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return HolidayDateSpecifics.class;
    }
}
