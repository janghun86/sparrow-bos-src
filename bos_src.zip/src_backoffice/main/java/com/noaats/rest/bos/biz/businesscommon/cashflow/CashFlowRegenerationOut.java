package com.noaats.rest.bos.biz.businesscommon.cashflow;

import com.noaats.rest.bos.biz.cr.cashflow.CashFlow;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CashFlowRegenerationOut {
    private List<CashFlowRegeneration> cashFlowRegenerationList;
    private List<FlexibleInterestRate> flexibleInterestRateList;
    private List<CashFlow> cashFlowList;
    private FlexibleInterestRate flexibleInterestRate;
}
