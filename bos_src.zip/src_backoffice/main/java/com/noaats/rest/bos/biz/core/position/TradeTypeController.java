package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.configuration.ITradeTypeService;
import com.noaats.rest.bos.biz.cr.configuration.TradeType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <pre>
 *
 * description : 거래유형 정보 조회
 *
 * com.noaats.sol.controller.position
 *    TradeTypeController.java
 *
 * </pre>
 *
 * @author : 정창욱
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2018. 12. 28.	정창욱		최초생성
 *
 * </pre>
 * @version :
 * @date : 2018. 12. 28. 오후 5:50:07
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/trade-type")
public class TradeTypeController extends BaseController {

    private final ITradeTypeService tradeTypeService;

    @GetMapping
    public ResponseEntity<TradeTypeOut> inquiry(@RequestBody BaseRequest<TradeTypeIn> request) throws CustomException {
        TradeTypeIn in = request.getData();
        TradeTypeOut out = new TradeTypeOut();

        TradeType tradeType = convert(in.getTradeType());

        List<TradeType> modelReturn = tradeTypeService.getTradeType(tradeType);
        out.setTradeTypeList(modelReturn);
        return ResponseEntity.ok(out);
    }
}
