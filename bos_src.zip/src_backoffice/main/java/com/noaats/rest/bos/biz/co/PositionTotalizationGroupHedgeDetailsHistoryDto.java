package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationGroupHedgeDetailsHistoryDto extends BaseDto {
    private String ptTlzGrpId;
    private String enrBseDt;
    private Integer vrs;
    private String mgmtDpmTc;
    private String cgprId;
    private String bizCls1Tc;
    private String bizCls2Tc;
    private String bizCls3Tc;
    private String ivCurCd;
    private Double ivAplcBbl;
    private Double ivBbl;
    private String ivNtnCd;
    private String iv1CurCd;
    private Double pra1Rt;
    private Integer hdg1TrmMms;
    private Double buy1Xcr;
    private Double sll1Xcr;
    private String iv2CurCd;
    private Double pra2Rt;
    private Integer hdg2TrmMms;
    private Double buy2Xcr;
    private Double sll2Xcr;
    private String iv3CurCd;
    private Double pra3Rt;
    private Integer hdg3TrmMms;
    private Double buy3Xcr;
    private Double sll3Xcr;
    private String hdgSgcTc;
    private Double praHdgRt;
    private Double ernHdgRt;
    private String hdgCttCcsMthTc;
    private String amlSpmtAgrYn;
    private String patHdgRsnCts;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionTotalizationGroupHedgeDetailsHistory.class;
    }
}
