package com.noaats.rest.bos.biz.businesscommon.department;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HeadquarterDepartmentDto extends BaseDto {
    private String dpmCd;
    private String dpmNm;
    private String temCd;
    private String temNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return HeadquarterDepartment.class;
    }
}
