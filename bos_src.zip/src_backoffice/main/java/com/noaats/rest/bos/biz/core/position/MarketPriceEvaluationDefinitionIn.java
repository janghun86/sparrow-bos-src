package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.MarketPriceEvaluationDefinitionCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MarketPriceEvaluationDefinitionIn extends BaseMessage {
    private MarketPriceEvaluationDefinitionCatalogueDto marketPriceEvaluationDefinitionCatalogue = new MarketPriceEvaluationDefinitionCatalogueDto();
}
