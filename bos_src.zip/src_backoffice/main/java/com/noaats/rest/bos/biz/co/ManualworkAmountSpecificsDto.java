package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class ManualworkAmountSpecificsDto extends BaseDto {
    private String bizId;
    private String trDt;
    private String pofAmtTc;
    private Long sno;
    private Integer vrs;
    private Double trAmt;
    private String apvStsTc;
    private String apvUsid;
    private LocalDateTime apvDtm;
    private String rmk;

    @JsonIgnore
    public Class getBusinessClass() {
        return ManualworkAmountSpecifics.class;
    }
}
