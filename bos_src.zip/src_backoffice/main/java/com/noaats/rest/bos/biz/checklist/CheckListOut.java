package com.noaats.rest.bos.biz.checklist;

import com.noaats.rest.bos.biz.co.checklist.*;
import com.noaats.rest.bos.biz.tr.ChoiceHeadingSpecifics;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class CheckListOut {
    private List<ChoiceHeadingSpecifics> choiceHeadingSpecificsList = new ArrayList<ChoiceHeadingSpecifics>();
    private CheckListCatalogue checkListCatalogue = new CheckListCatalogue();
    private List<CheckListCatalogue> checkListCatalogueList = new ArrayList<CheckListCatalogue>();
    private List<CheckListClassifiedByProcedureCatalogue> checkListClassifiedByProcedureCatalogueList = new ArrayList<CheckListClassifiedByProcedureCatalogue>();
    private List<CheckListProcedureClassifiedByColumnCatalogue> checkListProcedureClassifiedByColumnCatalogueList = new ArrayList<CheckListProcedureClassifiedByColumnCatalogue>();
    private List<CheckListProcedureClassifiedByCheckingHeadingCatalogue> checkListProcedureClassifiedByCheckingHeadingCatalogueList = new ArrayList<CheckListProcedureClassifiedByCheckingHeadingCatalogue>();
    private CheckListCheckingResultCatalogue checkListCheckingResultCatalogue;
    private List<CheckListCheckingResultRuleSpecifics> checkListCheckingResultRuleSpecificsList = new ArrayList<CheckListCheckingResultRuleSpecifics>();
    private List<CheckListCheckingResultValueSpecifics> checkListCheckingResultValueSpecificsList = new ArrayList<CheckListCheckingResultValueSpecifics>();
    private List<CheckListCheckingResultCatalogue> checkListCheckingResultCatalogueList = new ArrayList<CheckListCheckingResultCatalogue>();
}
