package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.position.PositionEventDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionEngineCancelTestDto extends PositionEventDto {
    private String trPcsTpId;
    private String ptPcsTpNm;
    private String sttBseDt;
    private String endBseDt;
    private String prdNo;
    private String prdNm;
    private String ptTlzId;
    private String trPcsTpNm;
    private String prdClsId;
    private String chkYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionEngineCancelTest.class;
    }
}
