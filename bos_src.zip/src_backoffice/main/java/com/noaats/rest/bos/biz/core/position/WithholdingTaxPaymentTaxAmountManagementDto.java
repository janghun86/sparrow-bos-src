package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WithholdingTaxPaymentTaxAmountManagementDto extends BaseDto {

    private String sttStmDt;        // 결제일자(시작)

    private String endStmDt;        // 결제일자(종료)

    private String enrSts;          // 등록상태

    private String evlAreaId;       // 평가영역ID

    private String prdClsId;        // 상품분류ID

    private String ptTlzId;         // 포지션집계ID

    private String prdNm;           // 상품명

    private Double parAmt;          // 액면금액

    private String stnCd;           // 표준코드

    private String bdIntDttCd;      // 채권이자구분코드

    private String calTrmSttDt;     // 계산기간시작일자

    private String calTrmEndDt;     // 계산기간종료일자

    private Integer calDds;          // 보유기간 (계산일수)

    private Double aplyIrt;         // 적용금리

    private String ptTrno;          // 포지션거래번호

    private String curCd;           // 통화코드

    private Double hldTrmIntAmt;    // 보유기간이자금액

    private String lctpNtnCd;       // 소재지국가코드 (내국인 / 외국인 구분)

    private String brn;             // 사업자등록번호

    private String mtlNm;           // 상호명

    //private Double ntyUntAmt;       // 권종단위금액
    
    private Double txr;             // 세율
    
    private Double wtxPymtAmt;      // 법인세

    private String stmDt;           // 결제일자

    private String hldIntPtPcsTpId; // 포지션유형ID (보유이자금액에서 반제금액 제외하기 위해 사용)

    private String pesTpTc;

    private String trPcsTpId;

    private String ptPcsTpId;

    private String prdNo;

    private String prdTpId;



    @JsonIgnore
    public Class getBusinessClass() {
        return WithholdingTaxPaymentTaxAmountManagement.class;
    }
}
