package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AmountMappingSpecificsDto extends BaseDto {
    private String pofTlzFntTc;
    private String ptPcsTpId;
    private String pofAmtTc;
    private String netPtPcsTpId;
    private String rmk;

    @JsonIgnore
    public Class getBusinessClass() {
        return AmountMappingSpecifics.class;
    }
}
