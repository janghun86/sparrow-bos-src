package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecuritiesLeaseTradeSpecificsDto extends BaseDto {
    private String lseMngNo;
    private String ptTlzId;
    private String lseTrTpId;
    private String cttCcsDt;
    private Integer vrs;
    private String prdNo;
    private Double ccsQty;
    private Double ccsAmt;
    private Double ccsAbkAmt;
    private String ptTrno;

    @JsonIgnore
    public Class getBusinessClass() {
        return SecuritiesLeaseTradeSpecifics.class;
    }
}
