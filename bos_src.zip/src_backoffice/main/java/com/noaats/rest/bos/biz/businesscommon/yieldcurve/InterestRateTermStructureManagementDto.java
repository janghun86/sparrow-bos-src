package com.noaats.rest.bos.biz.businesscommon.yieldcurve;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InterestRateTermStructureManagementDto extends BaseDto {

    private String chkYn;

    private String irtCurvId;

    private String irtCurvDt;

    private Integer seqlNo;

    private String trmUntTc;

    private Integer irtTrm;

    private String irtBseDt;

    private Double spotIrt;

    private Double frwdIrt;


    @JsonIgnore
    public Class getBusinessClass() {
        return InterestRateTermStructureManagement.class;
    }
}
