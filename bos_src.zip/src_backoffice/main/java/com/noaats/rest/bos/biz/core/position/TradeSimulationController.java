package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.position.PositionEvent;
import com.noaats.rest.bos.biz.cr.position.PositionManagementBase;
import com.noaats.rest.bos.biz.cr.position.PositionTrade;
import com.noaats.rest.bos.biz.cr.trade.soltrade.ISOLTradeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/trade-simulation")
public class TradeSimulationController extends BaseController {

    private final ISOLTradeService<TradeSimulation> solTradeService;

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeSimulationOut> registration(@RequestBody BaseRequest<TradeSimulationIn> request) throws CustomException {
        TradeSimulationIn in = request.getData();
        TradeSimulationOut out = new TradeSimulationOut();

        TradeSimulation tradeSimulation = convert(in.getTradeSimulation());
        
        tradeSimulation.setSolTradeBeanName("tradeSimulationService");

        solTradeService.tradingWithSave(tradeSimulation);

        out.setTradeBasic(tradeSimulation.getTradeBasic());
        out.setTradeObjectChangeHistory(tradeSimulation.getTradeObjectChangeHistory());
        out.setTradeEventList(tradeSimulation.getTradeEventList());

        out.setPositionManagementBaseList(tradeSimulation.getPosition().getPositionManagementBaseList());

        out.setPositionEventList(new ArrayList<PositionEvent>());
        out.setPositionTradeList(new ArrayList<PositionTrade>());

        int size = tradeSimulation.getPosition().getPositionManagementBaseList().size();

        for (int index = 0; index < size; index++) {

            PositionManagementBase positionManagementBase = tradeSimulation.getPosition().getPositionManagementBaseList().get(index);

            for (int eventIndex = 0; eventIndex < positionManagementBase.getPositionEventList().size(); eventIndex++) {
                out.getPositionEventList().add(positionManagementBase.getPositionEventList().get(eventIndex));
            }

            for (int tradeIndex = 0; tradeIndex < positionManagementBase.getPositionTradeList().size(); tradeIndex++) {
                out.getPositionTradeList().add(positionManagementBase.getPositionTradeList().get(tradeIndex));
            }
        }
        return ResponseEntity.ok(out);
    }
}
