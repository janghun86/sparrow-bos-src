package com.noaats.rest.bos.biz.abc.tr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaskServiceInfoDto extends BaseDto {
    private String tskId;
    private String tskSvcId;
    private String tskSvcNm;
    private String tskSvcTc;
    private String tbId;
    private String svcId;
    private String fncId;
    private Long seqlNo;
    private Integer logSno;
    private String tskUnqId;
    private String fsgYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return TaskServiceInfo.class;
    }
}
