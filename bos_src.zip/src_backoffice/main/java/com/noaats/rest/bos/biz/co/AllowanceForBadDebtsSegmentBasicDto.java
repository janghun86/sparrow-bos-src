package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllowanceForBadDebtsSegmentBasicDto extends BaseDto {
    private String segId;
    private String segClsTc;
    private Integer vrs;
    private String segNm;
    private String dtlCts;
    private String basDatId;
    private byte[] qry;

    @JsonIgnore
    public Class getBusinessClass() {
        return AllowanceForBadDebtsSegmentBasic.class;
    }
}
