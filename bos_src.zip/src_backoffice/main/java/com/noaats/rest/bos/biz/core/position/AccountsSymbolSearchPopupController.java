package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/account-symbol-popup")
public class AccountsSymbolSearchPopupController extends BaseController {

    private final IAccountsSymbolSearchPopupService<AccountsSymbolSearchPopup> accountsSymbolSearchPopupService;

    @GetMapping
    public ResponseEntity<AccountsSymbolSearchPopupOut> inquiry(@RequestBody BaseRequest<AccountsSymbolSearchPopupIn> request) throws CustomException {
        AccountsSymbolSearchPopupIn in = request.getData();
        AccountsSymbolSearchPopupOut out = new AccountsSymbolSearchPopupOut();
        // convert
        AccountsSymbolSearchPopup accountsSymbolSearchPopup = convert(in.getAccountsSymbolSearchPopup());

        List<AccountsSymbolSearchPopup> accountsSymbolSearchPopupList = accountsSymbolSearchPopupService.inquiry(accountsSymbolSearchPopup);
        out.setAccountsSymbolSearchPopup(accountsSymbolSearchPopupList);
        return ResponseEntity.ok(out);
    }
}
