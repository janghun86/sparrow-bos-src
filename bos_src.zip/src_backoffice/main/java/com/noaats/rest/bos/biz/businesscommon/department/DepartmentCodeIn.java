package com.noaats.rest.bos.biz.businesscommon.department;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.fw.OrganizationDepartmentCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DepartmentCodeIn extends BaseMessage {
    private OrganizationDepartmentCatalogueDto organizationDepartmentCatalogue = new OrganizationDepartmentCatalogueDto();
}
