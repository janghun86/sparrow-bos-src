package com.noaats.rest.bos.biz.abc.tr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HeadingGroupInfoDto extends BaseDto {
    private String tskSvcId;
    private long seqlNo;
    private String hdnGrpId;
    private String hdnGrpNm;
    private String endYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return HeadingGroupInfo.class;
    }
}
