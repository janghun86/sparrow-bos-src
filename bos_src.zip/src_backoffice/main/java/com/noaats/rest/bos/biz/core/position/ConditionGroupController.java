package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.ConditionGroupCatalogue;
import com.noaats.rest.bos.biz.cr.IConditionGroupCatalogueService;
import com.noaats.rest.bos.biz.cr.configuration.ConditionGroup;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/condition-group")
public class ConditionGroupController extends BaseController {

    private final IConditionGroupCatalogueService conditionGroupCatalogueService;

    @GetMapping
    public ResponseEntity<ConditionGroupOut> findUseAll(@RequestBody BaseRequest<ConditionGroupIn> request) throws CustomException {
        ConditionGroupIn in = request.getData();
        ConditionGroupOut out = new ConditionGroupOut();

        ConditionGroupCatalogue conditionGroupCatalogue = convert(in.getConditionGroupCatalogue());

        List<ConditionGroupCatalogue> conditionGroupCatalogueList = conditionGroupCatalogueService.findUseAll(conditionGroupCatalogue);
        out.setConditionGroupCatalogueList(conditionGroupCatalogueList);
        return ResponseEntity.ok(out);
    }
}
