package com.noaats.rest.bos.biz.businesscommon.department;

import com.noaats.rest.bos.biz.fw.OrganizationDepartmentCatalogue;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class DepartmentCodeOut {
    private List<OrganizationDepartmentCatalogue> organizationDepartmentCatalogueList;
}
