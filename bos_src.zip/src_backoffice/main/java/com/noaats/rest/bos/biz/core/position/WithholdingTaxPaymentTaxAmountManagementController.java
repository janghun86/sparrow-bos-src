/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <pre>
 *
 * description : 원천징수납부명세 조회 Controller
 *
 * com.noaats.sol.controller.core.position
 *    WithholdingTaxPaymentTaxAmountManagementController.java
 *
 * </pre>
 *
 * @author : hj.lee@noaats.com
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2024. 8. 14.	hj.lee@noaats.com		최초생성
 *
 * </pre>
 * @version :
 * @date : 2024. 8. 14. 오후 1:45:14
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/withholding-tax-management")
public class WithholdingTaxPaymentTaxAmountManagementController extends BaseController {

    private final IWithholdingTaxPaymentTaxAmountManagementService<WithholdingTaxPaymentTaxAmountManagement> withholdingTaxPaymentTaxAmountManagementService;


    @GetMapping("/pes-tp-tc")
    public ResponseEntity<WithholdingTaxPaymentTaxAmountManagementOut> inquiryPesTpTc(@RequestBody BaseRequest<WithholdingTaxPaymentTaxAmountManagementIn> request) throws CustomException {
        WithholdingTaxPaymentTaxAmountManagementIn in = request.getData();
        WithholdingTaxPaymentTaxAmountManagementOut out = new WithholdingTaxPaymentTaxAmountManagementOut();

        WithholdingTaxPaymentTaxAmountManagement withholdingTaxPaymentTaxAmountManagement = convert(in.getWithholdingTaxPaymentTaxAmountManagementDto());

        out.setWithholdingTaxPaymentTaxAmountManagementList(withholdingTaxPaymentTaxAmountManagementService.inquiryPaperType(withholdingTaxPaymentTaxAmountManagement));
        return ResponseEntity.ok(out);
    }


    @GetMapping
    public ResponseEntity<WithholdingTaxPaymentTaxAmountManagementOut> inquiry(@RequestBody BaseRequest<WithholdingTaxPaymentTaxAmountManagementIn> request) throws CustomException {
        WithholdingTaxPaymentTaxAmountManagementIn in = request.getData();
        WithholdingTaxPaymentTaxAmountManagementOut out = new WithholdingTaxPaymentTaxAmountManagementOut();

        WithholdingTaxPaymentTaxAmountManagement withholdingTaxPaymentTaxAmountManagement = convert(in.getWithholdingTaxPaymentTaxAmountManagementDto());

        //BeanUtils.copyProperties(withholdingTaxPaymentTaxAmountManagementService.inquiry(withholdingTaxPaymentTaxAmountManagement), out);

        out.setWithholdingTaxPaymentTaxAmountManagementList(withholdingTaxPaymentTaxAmountManagementService.inquiry(withholdingTaxPaymentTaxAmountManagement));
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<WithholdingTaxPaymentTaxAmountManagementOut> registration(@RequestBody BaseRequest<WithholdingTaxPaymentTaxAmountManagementIn> request) throws CustomException {
        WithholdingTaxPaymentTaxAmountManagementIn in = request.getData();
        WithholdingTaxPaymentTaxAmountManagementOut out = new WithholdingTaxPaymentTaxAmountManagementOut();

        List<WithholdingTaxPaymentTaxAmountManagement> withholdingTaxPaymentTaxAmountManagementList = convertList(in.getWithholdingTaxPaymentTaxAmountManagementDtoList());
        withholdingTaxPaymentTaxAmountManagementService.save(withholdingTaxPaymentTaxAmountManagementList);

        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<WithholdingTaxPaymentTaxAmountManagementOut> cancel(@RequestBody BaseRequest<WithholdingTaxPaymentTaxAmountManagementIn> request) throws CustomException {
        WithholdingTaxPaymentTaxAmountManagementIn in = request.getData();
        WithholdingTaxPaymentTaxAmountManagementOut out = new WithholdingTaxPaymentTaxAmountManagementOut();

        List<WithholdingTaxPaymentTaxAmountManagement> withholdingTaxPaymentTaxAmountManagementList = convertList(in.getWithholdingTaxPaymentTaxAmountManagementDtoList());
        withholdingTaxPaymentTaxAmountManagementService.delete(withholdingTaxPaymentTaxAmountManagementList);

        return ResponseEntity.ok(out);
    }

}
