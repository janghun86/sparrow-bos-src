package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountsSymbolAccountSubjectMappingSpecificsDto extends BaseDto {
    private String asjTblCd;
    private String atsSymCd;
    private String evlAreaId;
    private String acPcsIdfrId;
    private String asjCd;

    @JsonIgnore
    public Class getBusinessClass() {
        return AccountsSymbolAccountSubjectMappingSpecifics.class;
    }
}
