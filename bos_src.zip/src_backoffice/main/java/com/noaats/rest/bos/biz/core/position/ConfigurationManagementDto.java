package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConfigurationManagementDto extends BaseDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return ConfigurationManagement.class;
    }
}
