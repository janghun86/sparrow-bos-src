package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class TrustAccountPopupDto extends BaseDto {
    private String pofNm;
    private String ptTlzGrpNm;
    private String cptyNm;
    private String actOpnIstNm;
    private String aplyBseDt;
    private String trBnkTc;
    private String istCd;
    private String actTc;
    private Long cptyNo;
    private String ano;
    private String curCd;
    private String actNm;
    private Long actOpnIstNo;
    private String acMngGrpId;
    private String ptTlzGrpId;
    private String moAno;
    private String aplyEndDt;
    private String aplySttDt;
    private String bblMngYn;
    private String asjCd;
    private String pofId;
    private String ptTlzUseYn;
    private Long lnkTrno;
    private String delYn;
    private String fstEnrUsid;
    private String fstEnrTrid;
    private String fstEnrIp;
    private String lstChgUsid;
    private String lstChgTrid;
    private String lstChgIp;
    private Integer vrs;

    @JsonIgnore
    public Class getBusinessClass() {
        return TrustAccountPopup.class;
    }
}
