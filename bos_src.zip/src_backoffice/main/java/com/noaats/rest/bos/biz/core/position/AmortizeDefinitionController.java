package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.AmortizeDefinitionCatalogue;
import com.noaats.rest.bos.biz.cr.IAmortizeDefinitionCatalogueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/amortize")
public class AmortizeDefinitionController extends BaseController {

    private final IAmortizeDefinitionCatalogueService amortizeDefinitionCatalogueService;

    @GetMapping
    public ResponseEntity<AmortizeDefinitionOut> findUseAll(@RequestBody BaseRequest<AmortizeDefinitionIn> request) throws CustomException {
        AmortizeDefinitionIn in = request.getData();
        AmortizeDefinitionOut out = new AmortizeDefinitionOut();
        // convert
        AmortizeDefinitionCatalogue amortizeDefinitionCatalogue = convert(in.getAmortizeDefinitionCatalogue());

        List<AmortizeDefinitionCatalogue> amortizeDefinitionCatalogueList = amortizeDefinitionCatalogueService.findUseAll(amortizeDefinitionCatalogue);
        out.setAmortizeDefinitionCatalogueList(amortizeDefinitionCatalogueList);
        return ResponseEntity.ok(out);
    }
}
