package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConditionTypeDefinitionCatalogueDto extends BaseDto {
    private String cndTpId;
    private String cndTpNm;
    private String rdmInfTc;
    private String intCalTc;
    private String dfrRecvTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return ConditionTypeDefinitionCatalogue.class;
    }
}
