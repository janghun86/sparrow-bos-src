package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.trade.TradeDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeSimulationDto extends TradeDto {
    private String fscMngGrpId;
    private String ptMngGrpId;
    private String trFntPcsInf;
    private String itmId;
    private String ptMngId;
    private String cptyCno;
    private String xrtDt;
    private String calDtIcdYn;
    private String calDtEomYn;
    private String cttUsrId;
    private String cpnCd;
    private String trTp;
    private String flwTp;
    private String sts;
    private String prjId;
    private String agrId;
    private String trDt;
    private String xcr;
    private String cur;
    private String stmDtDtt;
    private String ccsStkQty;
    private String agrAmt;
    private String agrUpr;
    private String fee;
    private String xclAmt;
    private String pof;
    private String mgmtFnd;
    private String hldPpo;
    private String mgmtDpm;
    private String fnmn;
    private String scuTrDtt;
    private String cpty;
    private String thcoAct;
    private String dpsIst;
    private String bkgAct;
    private String stmAct;
    private String fscPcsTp;

    @JsonIgnore
    public Class getBusinessClass() {
        return TradeSimulation.class;
    }
}
