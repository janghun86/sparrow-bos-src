package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CounterpartyBasicDto extends BaseDto {
    private Long cptyNo;
    private Integer vrs;
    private String cptyStsTc;
    private String cptyTc;
    private String hfcNtnCd;
    private String lctpNtnCd;
    private String cptyNm;
    private String cptyEnlNm;
    private String cptyAbvNm;
    private String cptyEnlAbvNm;
    private String trBnkTc;
    private String adr;
    private String tpn;
    private String faxn;
    private String rmk;

    @JsonIgnore
    public Class getBusinessClass() {
        return CounterpartyBasic.class;
    }
}
