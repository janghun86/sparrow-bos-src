package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FunctionTradeProcessTypeMappingDto extends BaseDto {
    private String fncId;
    private String trPcsTpId;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return FunctionTradeProcessTypeMapping.class;
    }
}
