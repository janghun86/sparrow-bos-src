/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.abc.taskmanagement;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/abc/taskmanagement/popup")
public class TaskProcessSpecificsPopupController extends BaseController {

    private final ITaskProcessSpecificsPopupService<TaskProcessSpecificsPopUp> taskProcessSpecificsPopupService;

    @GetMapping
    public ResponseEntity<TaskProcessSpecificsPopupOut> inquiry(@RequestBody BaseRequest<TaskProcessSpecificsPopupIn> request) throws CustomException {
        TaskProcessSpecificsPopupIn in = request.getData();
        TaskProcessSpecificsPopupOut out = new TaskProcessSpecificsPopupOut();
        // convert
        TaskProcessSpecificsPopUp taskProcessSpecificsPopUp = convert(in.getTaskProcessSpecificsPopUp());

        List<TaskProcessSpecificsPopUp> taskProcessSpecificsPopUpList = taskProcessSpecificsPopupService.inquiry(taskProcessSpecificsPopUp);
        out.setTaskProcessSpecificsPopUpList(taskProcessSpecificsPopUpList);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TaskProcessSpecificsPopupOut> delete(@RequestBody BaseRequest<TaskProcessSpecificsPopupIn> request) throws CustomException {
        TaskProcessSpecificsPopupIn in = request.getData();
        TaskProcessSpecificsPopupOut out = new TaskProcessSpecificsPopupOut();
        // convert
        List<TaskProcessSpecificsPopUp> taskProcessSpecificsPopUpList = convertList(in.getTaskProcessSpecificsPopUpList());

        taskProcessSpecificsPopupService.delete(taskProcessSpecificsPopUpList);
        return ResponseEntity.ok(out);
    }
}
