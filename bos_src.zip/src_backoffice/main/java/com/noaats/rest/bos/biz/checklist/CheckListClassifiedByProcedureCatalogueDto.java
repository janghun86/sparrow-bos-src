package com.noaats.rest.bos.biz.checklist;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import com.noaats.rest.bos.biz.co.checklist.CheckListClassifiedByProcedureCatalogue;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckListClassifiedByProcedureCatalogueDto extends BaseDto {

    private String cklId;

    private String cklPcdrId;

    private Integer vrs;

    private String cklPcdrNm;

    private String colDefnYn;

    private String hdnDefnYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return CheckListClassifiedByProcedureCatalogue.class;
    }
}
