package com.noaats.rest.bos.biz.businesscommon.popup;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.lib.frk.mci.util.DtoConverter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/popup")
public class BusinessCommonPopupManagementController extends BaseController {

    private final IBusinessCommonPopupManagementService businessCommonPopupManagementService;
    private BaseRequest<BusinessCommonPopupManagementIn> request;

    @GetMapping("/counterparty-open")
    public ResponseEntity<BusinessCommonPopupManagementOut> counterpartyOpenPopup(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        CounterpartyPopup counterpartyPopup = convert(in.getCounterpartyPopup());
        // 거래상대방 팝업(팝업 화면)
        List<CounterpartyPopup> counterpartyPopupList = businessCommonPopupManagementService.counterpartyOpenPopup(counterpartyPopup);
        out.setCounterpartyPopupList(counterpartyPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/counterparty-biz")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquirycounterpartyBizPopup(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        CounterpartyPopup counterpartyPopup = convert(in.getCounterpartyPopup());
        // 거래상대방 팝업(팝업호출 화면)
        List<CounterpartyPopup> counterpartyPopupList = businessCommonPopupManagementService.inquirycounterpartyBizPopup(counterpartyPopup);
        out.setCounterpartyPopupList(counterpartyPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/currency")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryCurrency(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        CurrencyCodePopup currencyCodePopup = convert(in.getCurrencyCodePopup());
        // 통화코드 팝업
        List<CurrencyCodePopup> currencyCodePopupList = businessCommonPopupManagementService.inquiry(currencyCodePopup);
        out.setCurrencyCodePopupList(currencyCodePopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/nation")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryNation(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        NationalCodePopup nationalCodePopup = convert(in.getNationalCodePopup());
        // 국가코드 팝업
        List<NationalCodePopup> nationalCodePopupList = businessCommonPopupManagementService.inquiry(nationalCodePopup);
        out.setNationalCodePopupList(nationalCodePopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/user")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryUser(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        UserPopup userPopup = convert(in.getUserPopup());
        // 사용자 팝업
        List<UserPopup> userPopupList = businessCommonPopupManagementService.inquiry(userPopup);
        out.setUserPopupList(userPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/agreement")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryAgreement(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        AgreementPopup agreementPopup = convert(in.getAgreementPopup());
        // 약정 팝업
        List<AgreementPopup> agreementPopupList = businessCommonPopupManagementService.inquiry(agreementPopup);
        out.setAgreementPopupList(agreementPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/this-company-account")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryThisCompanyAccount(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        ThisCompanyAccountPopup thisCompanyAccountPopup = convert(in.getThisCompanyAccountPopup());
        // 당사계좌 팝업
        List<ThisCompanyAccountPopup> thisCompanyAccountPopupList = businessCommonPopupManagementService.inquiry(thisCompanyAccountPopup);
        out.setThisCompanyAccountPopupList(thisCompanyAccountPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/deposit-site")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryDepositSite(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        DepositSitePopup depositSitePopup = convert(in.getDepositSitePopup());
        // 예탁처 팝업
        List<DepositSitePopup> depositSitePopupList = businessCommonPopupManagementService.inquiry(depositSitePopup);
        out.setDepositSitePopupList(depositSitePopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/trust-account")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryTrustAccount(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        TrustAccountPopup trustAccountPopup = convert(in.getTrustAccountPopup());
        // 위탁계좌 팝업
        List<TrustAccountPopup> trustAccountPopupList = businessCommonPopupManagementService.inquiry(trustAccountPopup);
        out.setTrustAccountPopupList(trustAccountPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/settlement-account")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquirySettlementAccount(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        SettlementAccountPopup settlementAccountPopup = convert(in.getSettlementAccountPopup());
        // 결제계좌 팝업
        List<SettlementAccountPopup> settlementAccountnPopupList = businessCommonPopupManagementService.inquiry(settlementAccountPopup);
        out.setSettlementAccountPopupList(settlementAccountnPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/department")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryDepartment(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        DepartmentPopup departmentPopup = convert(in.getDepartmentPopup());
        // 부서 팝업
        List<DepartmentPopup> departmentPopupPopupList = businessCommonPopupManagementService.inquiry(departmentPopup);
        out.setDepartmentPopupList(departmentPopupPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/headquarter")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryHeadquarter(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        HeadquarterPopup headquarterPopup = convert(in.getHeadquarterPopup());
        // 본부 팝업
        List<HeadquarterPopup> headquarterPopupList = businessCommonPopupManagementService.inquiry(headquarterPopup);
        out.setHeadquarterPopupList(headquarterPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/project")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryProject(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        ProjectPopup projectPopup = convert(in.getProjectPopup());
        // 프로젝트 팝업
        List<ProjectPopup> projectPopupList = businessCommonPopupManagementService.inquiry(projectPopup);
        out.setProjectPopupList(projectPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/borrower")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryBorrower(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        BorrowerPopup borrowerPopup = convert(in.getBorrowerPopup());
        // 차주 팝업
        List<BorrowerPopup> borrowerPopupList = businessCommonPopupManagementService.inquiry(borrowerPopup);
        out.setBorrowerPopupList(borrowerPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/tranche")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryTranche(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        TranchePopup tranchePopup = convert(in.getTranchePopup());
        // 트렌치 팝업
        List<TranchePopup> tranchePopupList = businessCommonPopupManagementService.inquiry(tranchePopup);
        out.setTranchePopupList(tranchePopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/publish-institution")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryPublishInstitution(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        PublishInstitutionPopup publishInstitutionPopup = convert(in.getPublishInstitutionPopup());
        // 발행기관 팝업
        List<PublishInstitutionPopup> publishInstitutionPopupList = businessCommonPopupManagementService.inquiry(publishInstitutionPopup);
        out.setPublishInstitutionPopupList(publishInstitutionPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/market-types")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryMarketTypes(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        MarketTypesOfBusinessPopup marketTypesOfBusinessPopup = convert(in.getMarketTypesOfBusinessPopup());
        // 시장업종 팝업
        List<MarketTypesOfBusinessPopup> marketTypesOfBusinessPopupList = businessCommonPopupManagementService.inquiry(marketTypesOfBusinessPopup);
        out.setMarketTypesOfBusinessPopupList(marketTypesOfBusinessPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/holiday")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryHoliday(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        HolidayPopup holidayPopup = convert(in.getHolidayPopup());
        // 휴일 팝업
        List<HolidayPopup> holidayPopupList = businessCommonPopupManagementService.inquiry(holidayPopup);
        out.setHolidayPopupList(holidayPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/business-id")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryBusinessId(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        BusinessIdentificationPopup businessIdentificationPopup = convert(in.getBusinessIdentificationPopup());
        // 사업ID 팝업
        List<BusinessIdentificationPopup> businessIdentificationPopupList = businessCommonPopupManagementService.inquiry(businessIdentificationPopup);
        out.setBusinessIdentificationPopupList(businessIdentificationPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/reference-interest")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryReferenceInterest(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        ReferenceInterestPopup referenceInterestPopup = convert(in.getReferenceInterestPopup());
        // 참조금리 팝업
        List<ReferenceInterestPopup> referenceInterestPopupList = businessCommonPopupManagementService.inquiry(referenceInterestPopup);
        out.setReferenceInterestPopupList(referenceInterestPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/management-team")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryManagementTeam(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        ManagementTeam managementTeam = convert(in.getManagementTeam());
        // 운용팀 팝업
        List<ManagementTeam> managementTeamList = businessCommonPopupManagementService.inquiry((ManagementTeam) managementTeam);
        out.setManagementTeamList(managementTeamList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/standard-industry-classification")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryStandardIndustryClassification(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        StandardIndustryClassificationPopup standardIndustryClassificationPopup = convert(in.getStandardIndustryClassificationPopup());
        // 표준산업분류 팝업
        List<StandardIndustryClassificationPopup> StandardIndustryClassificationPopupList = businessCommonPopupManagementService.inquiry(standardIndustryClassificationPopup);
        out.setStandardIndustryClassificationPopupList(StandardIndustryClassificationPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/trade-bank")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryTradeBank(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        TradeBankPopup tradeBankPopup = convert(in.getTradeBankPopup());
        // 거래은행구분 팝업
        List<TradeBankPopup> tradeBankPopupList = businessCommonPopupManagementService.inquiry(tradeBankPopup);
        out.setTradeBankPopupList(tradeBankPopupList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/table")
    public ResponseEntity<BusinessCommonPopupManagementOut> inquiryTable(@RequestBody BaseRequest<BusinessCommonPopupManagementIn> request) throws CustomException {
        BusinessCommonPopupManagementIn in = request.getData();
        BusinessCommonPopupManagementOut out = new BusinessCommonPopupManagementOut();
        // convert
        TablePopup tablePopup = convert(in.getTablePopup());
        // 테이블조회 팝업
        List<TablePopup> tablePopupList = businessCommonPopupManagementService.getTablePopupList(tablePopup);
        out.setTablePopupList(tablePopupList);
        return ResponseEntity.ok(out);
    }
}
