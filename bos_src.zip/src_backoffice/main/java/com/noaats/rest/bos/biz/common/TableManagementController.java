package com.noaats.rest.bos.biz.common;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/common/table")
public class TableManagementController extends BaseController {

    private final ITableManagementService tableManagementService;

    @GetMapping
    public ResponseEntity<TableManagementOut> searchTableList(@RequestBody BaseRequest<TableManagementIn> request) throws CustomException {
        TableManagementIn in = request.getData();
        TableManagementOut out = new TableManagementOut();
        List<TableManagement> tableManagementList = tableManagementService.searchTableList();
        out.setTableManagementList(tableManagementList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/info")
    public ResponseEntity<TableManagementOut> searchTableInfo(@RequestBody BaseRequest<TableManagementIn> request) throws CustomException {
        TableManagementIn in = request.getData();
        TableManagementOut out = new TableManagementOut();
        // convert
        TableManagement tableManagement = convert(in.getTableManagement());

        TableInfo tableInfo = tableManagementService.searchTableInfo(tableManagement);
        out.setTableManagementList(tableInfo.getTableStructureList());
        out.setTableDataList(tableInfo.getTableDataList());
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TableManagementOut> save(@RequestBody BaseRequest<TableManagementIn> request) throws CustomException {
        TableManagementIn in = request.getData();
        TableManagementOut out = new TableManagementOut();
        // convert
        List<TableManagement> tableManagementList = convertList(in.getTableManagementList());

        tableManagementService.saveTableData(tableManagementList, in.getTableDataList());
        return ResponseEntity.ok(out);
    }
}
