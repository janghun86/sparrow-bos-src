package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.pr.LendingItemBasicDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TranchePopupDto extends LendingItemBasicDto {
    private String prjId;
    private String agrNm;
    private String prjNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return TranchePopup.class;
    }
}
