package com.noaats.rest.bos.biz.abc.taskmanagement;

import com.noaats.lib.frk.mci.BaseMessage;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class TaskProcessSpecificsPopupIn extends BaseMessage {
    private TaskProcessSpecificsPopUpDto taskProcessSpecificsPopUp = new TaskProcessSpecificsPopUpDto();
    private List<TaskProcessSpecificsPopUpDto> taskProcessSpecificsPopUpList = new ArrayList<>();
}
