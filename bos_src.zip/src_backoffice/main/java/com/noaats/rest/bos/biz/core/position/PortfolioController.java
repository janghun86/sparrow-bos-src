package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.configuration.IPortfolioService;
import com.noaats.rest.bos.biz.cr.configuration.Portfolio;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/portfolio")
public class PortfolioController extends BaseController {

    private final IPortfolioService portfolioService;

    @GetMapping
    public ResponseEntity<PortfolioOut> getPortfolio(@RequestBody BaseRequest<PortfolioIn> request) throws CustomException {
        PortfolioIn in = request.getData();
        PortfolioOut out = new PortfolioOut();

        Portfolio portfolio = convert(in.getPortfolio());

        List<Portfolio> portfolioList = portfolioService.getPortfolio(portfolio);
        out.setPortfolioList(portfolioList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/ac-mng-grp-id")
    public ResponseEntity<PortfolioOut> inquiryAcMngGrpId(@RequestBody BaseRequest<PortfolioIn> request) throws CustomException {
        PortfolioIn in = request.getData();
        PortfolioOut out = new PortfolioOut();

        Portfolio portfolio = convert(in.getPortfolio());

        List<Portfolio> portfolioList = portfolioService.inquiryAcMngGrpId(portfolio);
        out.setPortfolioList(portfolioList);
        return ResponseEntity.ok(out);
    }
}
