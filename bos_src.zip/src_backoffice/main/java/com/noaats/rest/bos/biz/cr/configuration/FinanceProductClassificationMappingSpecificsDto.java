package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import com.noaats.rest.bos.biz.cr.FinanceProductClassificationMappingSpecifics;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FinanceProductClassificationMappingSpecificsDto extends BaseDto {

    private String prdTpId;
    private String qtaFnoTc;
    private String bizModlTc;
    private String sppiTesTc;
    private String fvociApmYn;
    private String evlTpId;

    @JsonIgnore
    public Class getBusinessClass() {
        return FinanceProductClassificationMappingSpecifics.class;
    }
}
