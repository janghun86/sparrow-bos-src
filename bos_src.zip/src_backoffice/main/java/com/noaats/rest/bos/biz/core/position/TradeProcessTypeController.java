/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.ITradeProcessTypeCatalogueService;
import com.noaats.rest.bos.biz.cr.TradeProcessTypeCatalogue;
import com.noaats.rest.bos.biz.cr.configuration.TradeProcessType;
import com.noaats.rest.bos.biz.cr.position.ITradeProcessTypeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <pre>
 *
 * description : 거래처리유형목록
 *
 * com.noaats.sol.controller.core.position
 *    TradeProcessTypeController.java
 *
 * </pre>
 *
 * @author : jwyang@noaats.com
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2020. 12. 22.	jwyang@noaats.com		최초생성
 *
 * </pre>
 * @version :
 * @date : 2020. 12. 22. 오후 1:42:30
 */

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/trade-process-type")
public class TradeProcessTypeController extends BaseController {

    private final ITradeProcessTypeCatalogueService tradeProcessTypeCatalogueService;

    private final ITradeProcessTypeService tradeProcessTypeService;

    @GetMapping
    public ResponseEntity<TradeProcessTypeOut> findUseAll(@RequestBody BaseRequest<TradeProcessTypeIn> request) throws CustomException {
        TradeProcessTypeIn in = request.getData();
        TradeProcessTypeOut out = new TradeProcessTypeOut();

        TradeProcessTypeCatalogue tradeProcessTypeCatalogue = convert(in.getTradeProcessTypeCatalogue());

        List<TradeProcessTypeCatalogue> tradeProcessTypeCatalogueList = tradeProcessTypeCatalogueService.findUseAll(tradeProcessTypeCatalogue);
        out.setTradeProcessTypeCatalogueList(tradeProcessTypeCatalogueList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/trade-process-type")
    public ResponseEntity<TradeProcessTypeOut> getTradeProcessType(@RequestBody BaseRequest<TradeProcessTypeIn> request) throws CustomException {
        TradeProcessTypeIn in = request.getData();
        TradeProcessTypeOut out = new TradeProcessTypeOut();

        TradeProcessType tradeProcessType = convert(in.getTradeProcessType());

        List<TradeProcessType> tradeProcessTypeList = tradeProcessTypeService.getTradeProcessType(tradeProcessType);
        out.setTradeProcessTypeList(tradeProcessTypeList);
        return ResponseEntity.ok(out);
    }
}
