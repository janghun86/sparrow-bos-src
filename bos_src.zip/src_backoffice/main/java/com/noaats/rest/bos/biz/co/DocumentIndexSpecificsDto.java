package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentIndexSpecificsDto extends BaseDto {
    private String docMngNo;
    private Integer vrs;
    private Long ivPpsEnrNo;
    private String prjId;
    private String ptTlzGrpId;
    private String agrId;
    private String prdNo;
    private String heldYy;
    private Integer heldDgr;
    private String ptTlzId;
    private Long trno;
    private Long cptyNo;
    private String osdUsid;
    private String dwuBseDt;
    private String docEnrDt;
    private String enrUsid;
    private String enrHdqCd;
    private String enrDpmCd;
    private String opbRngTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return DocumentIndexSpecifics.class;
    }
}
