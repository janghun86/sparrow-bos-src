package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.configuration.ProductTypeDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductTypeInformationDto extends ProductTypeDto {
    private String prdClsIdList;

    @JsonIgnore
    public Class getBusinessClass() {
        return ProductTypeInformation.class;
    }
}
