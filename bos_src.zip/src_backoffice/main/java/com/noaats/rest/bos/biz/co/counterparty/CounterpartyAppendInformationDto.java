package com.noaats.rest.bos.biz.co.counterparty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CounterpartyAppendInformationDto extends BaseDto {
    private String c0001;
    private String c0002;
    private String c0003;
    private String c0004;
    private String c0005;
    private String c0006;
    private String c0007;
    private String c0008;
    private String c0009;

    @JsonIgnore
    public Class getBusinessClass() {
        return CounterpartyAppendInformation.class;
    }
}
