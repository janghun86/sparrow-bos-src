package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.IIntegrationSettingUpInformationClassificationService;
import com.noaats.rest.bos.biz.cr.IntegrationSettingUpInformationClassification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/integration-setting-up")
public class IntegrationSettingUpInformationController extends BaseController {

    private final IIntegrationSettingUpInformationClassificationService integrationSettingUpInformationClassificationService;

    private final IIntegrationSettingUpInformationService<IntegrationSettingUpInformation> integrationSettingUpInformationService;

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<IntegrationSettingUpInformationOut> save(@RequestBody BaseRequest<IntegrationSettingUpInformationIn> request) throws CustomException {
        IntegrationSettingUpInformationIn in = request.getData();
        IntegrationSettingUpInformationOut out = new IntegrationSettingUpInformationOut();
        integrationSettingUpInformationService.save(setIntegrationSettingUpInformation(in));
        return ResponseEntity.ok(out);
    }

    @PostMapping("/forwarding")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<IntegrationSettingUpInformationOut> forwarding(@RequestBody BaseRequest<IntegrationSettingUpInformationIn> request) throws CustomException {
        IntegrationSettingUpInformationIn in = request.getData();
        IntegrationSettingUpInformationOut out = new IntegrationSettingUpInformationOut();
        IntegrationSettingUpInformation integrationSettingUpInformation = setIntegrationSettingUpInformation(in);
//        integrationSettingUpInformation.setIntgSupTc(convert(in.getIntegrationSettingUpInformation()).getIntgSupTc());
//        integrationSettingUpInformation.setTbId(convert(in.getIntegrationSettingUpInformation()).getTbId());
//        integrationSettingUpInformation.setIstCdFrom(convert(in.getIntegrationSettingUpInformation()).getIstCdFrom());
//        integrationSettingUpInformation.setIstCdTo(convert(in.getIntegrationSettingUpInformation()).getIstCdTo());
//        integrationSettingUpInformation.setFwdDtt(convert(in.getIntegrationSettingUpInformation()).getFwdDtt());
        integrationSettingUpInformationService.forwarding(integrationSettingUpInformation);
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<IntegrationSettingUpInformationOut> update(@RequestBody BaseRequest<IntegrationSettingUpInformationIn> request) throws CustomException {
        IntegrationSettingUpInformationIn in = request.getData();
        IntegrationSettingUpInformationOut out = new IntegrationSettingUpInformationOut();
        integrationSettingUpInformationService.update(setIntegrationSettingUpInformation(in));
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<IntegrationSettingUpInformationOut> delete(@RequestBody BaseRequest<IntegrationSettingUpInformationIn> request) throws CustomException {
        IntegrationSettingUpInformationIn in = request.getData();
        IntegrationSettingUpInformationOut out = new IntegrationSettingUpInformationOut();
        integrationSettingUpInformationService.delete(setIntegrationSettingUpInformation(in));
        return ResponseEntity.ok(out);
    }

    @GetMapping
    public ResponseEntity<IntegrationSettingUpInformationOut> findAll(@RequestBody BaseRequest<IntegrationSettingUpInformationIn> request) throws CustomException {
        IntegrationSettingUpInformationIn in = request.getData();
        IntegrationSettingUpInformationOut out = new IntegrationSettingUpInformationOut();

        IntegrationSettingUpInformation integrationSettingUpInformation = convert(in.getIntegrationSettingUpInformation());

        List<IntegrationSettingUpInformationClassification> integrationSettingUpInformationClassificationList = integrationSettingUpInformationClassificationService.findAll(integrationSettingUpInformation);
        out.setIntegrationSettingUpInformationClassificationList(integrationSettingUpInformationClassificationList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/inf-list")
    public ResponseEntity<IntegrationSettingUpInformationOut> findUseAll(@RequestBody BaseRequest<IntegrationSettingUpInformationIn> request) throws CustomException {
        IntegrationSettingUpInformationIn in = request.getData();
        IntegrationSettingUpInformationOut out = new IntegrationSettingUpInformationOut();
        IntegrationSettingUpInformation integrationSettingUpInformation = integrationSettingUpInformationService.findUseAll(setIntegrationSettingUpInformation(in));
        out.setTargetModelList(integrationSettingUpInformation.getTargetModelList());
        return ResponseEntity.ok(out);
    }

    public IntegrationSettingUpInformation setIntegrationSettingUpInformation(IntegrationSettingUpInformationIn in) throws CustomException {

        IntegrationSettingUpInformation integrationSettingUpInformation = convert(in.getIntegrationSettingUpInformation());

//        integrationSettingUpInformation.setBasTbMdelNm(in.getIntegrationSettingUpInformation().getBasTbMdelNm());

        integrationSettingUpInformation.setInstitutionCodeCatalogueList(convertList(in.getInstitutionCodeCatalogueList()));
        integrationSettingUpInformation.setAccountManagementGroupCatalogueList(convertList(in.getAccountManagementGroupCatalogueList()));
        integrationSettingUpInformation.setEvaluationAreaCatalogueList(convertList(in.getEvaluationAreaCatalogueList()));
        integrationSettingUpInformation.setEvaluationAreaMappingSpecificsList(convertList(in.getEvaluationAreaMappingSpecificsList()));
        integrationSettingUpInformation.setEvaluationGroupMappingSpecificsList(convertList(in.getEvaluationGroupMappingSpecificsList()));
        integrationSettingUpInformation.setEvaluationGroupCatalogueList(convertList(in.getEvaluationGroupCatalogueList()));
        integrationSettingUpInformation.setEvaluationTypeCatalogueList(convertList(in.getEvaluationTypeCatalogueList()));
        integrationSettingUpInformation.setEvaluationTypeMappingSpecificsList(convertList(in.getEvaluationTypeMappingSpecificsList()));
        integrationSettingUpInformation.setAccountEvaluationTypeCatalogueList(convertList(in.getAccountEvaluationTypeCatalogueList()));
        integrationSettingUpInformation.setProductEvaluationAreaMappingSpecificsList(convertList(in.getProductEvaluationAreaMappingSpecificsList()));
        integrationSettingUpInformation.setProductEvaluationGroupMappingSpecificsList(convertList(in.getProductEvaluationGroupMappingSpecificsList()));
        integrationSettingUpInformation.setPortfolioCatalogueList(convertList(in.getPortfolioCatalogueList()));
        integrationSettingUpInformation.setPositionTotalizationGroupCatalogueList(convertList(in.getPositionTotalizationGroupCatalogueList()));
        integrationSettingUpInformation.setPositionClassificationUnitCatalogueList(convertList(in.getPositionClassificationUnitCatalogueList()));
        integrationSettingUpInformation.setPositionEvaluationProcedureCatalogueList(convertList(in.getPositionEvaluationProcedureCatalogueList()));
        integrationSettingUpInformation.setPositionEvaluationProcedureMappingSpecificsList(convertList(in.getPositionEvaluationProcedureMappingSpecificsList()));
        integrationSettingUpInformation.setPositionProcessTypeMappingSpecificsList(convertList(in.getPositionProcessTypeMappingSpecificsList()));
        integrationSettingUpInformation.setAmountProcessTypeCatalogueList(convertList(in.getAmountProcessTypeCatalogueList()));
        integrationSettingUpInformation.setPositionHeadingConfigurationElementMappingSpecificsList(convertList(in.getPositionHeadingConfigurationElementMappingSpecificsList()));
        integrationSettingUpInformation.setPositionHeadingSpecificsList(convertList(in.getPositionHeadingSpecificsList()));
        integrationSettingUpInformation.setDisposalRestrictionPositionProcessTypeMappingSpecificsList(convertList(in.getDisposalRestrictionPositionProcessTypeMappingSpecificsList()));
        integrationSettingUpInformation.setAmortizeDefinitionCatalogueList(convertList(in.getAmortizeDefinitionCatalogueList()));
        integrationSettingUpInformation.setForeignCurrencyValuationDefinitionCatalogueList(convertList(in.getForeignCurrencyValuationDefinitionCatalogueList()));
        integrationSettingUpInformation.setMarketPriceEvaluationDefinitionCatalogueList(convertList(in.getMarketPriceEvaluationDefinitionCatalogueList()));
        integrationSettingUpInformation.setEvaluationPositionProcessTypeMappingSpecificsList(convertList(in.getEvaluationPositionProcessTypeMappingSpecificsList()));
        integrationSettingUpInformation.setReceivableAdvanceReceivePositionProcessTypeMappingSpecificsList(convertList(in.getReceivableAdvanceReceivePositionProcessTypeMappingSpecificsList()));
        integrationSettingUpInformation.setDependencyPositionProcessTypeAmortizeMappingSpecificsList(convertList(in.getDependencyPositionProcessTypeAmortizeMappingSpecificsList()));
        integrationSettingUpInformation.setDependencyPositionProcessTypeOutflowOrInflowMappingSpecificsList(convertList(in.getDependencyPositionProcessTypeOutflowOrInflowMappingSpecificsList()));
        integrationSettingUpInformation.setDependencyPositionProcessTypeRealizationMappingSpecificsList(convertList(in.getDependencyPositionProcessTypeRealizationMappingSpecificsList()));
        integrationSettingUpInformation.setDependencyPositionProcessTypeTransferMappingSpecificsList(convertList(in.getDependencyPositionProcessTypeTransferMappingSpecificsList()));
        integrationSettingUpInformation.setDependencyPositionProcessTypeAccountTransferMappingSpecificsList(convertList(in.getDependencyPositionProcessTypeAccountTransferMappingSpecificsList()));
        integrationSettingUpInformation.setAccountSubjectCatalogueList(convertList(in.getAccountSubjectCatalogueList()));
        integrationSettingUpInformation.setAccountProcessIdentifierCatalogueList(convertList(in.getAccountProcessIdentifierCatalogueList()));
        integrationSettingUpInformation.setAccountProcessIdentifierMappingSpecificsList(convertList(in.getAccountProcessIdentifierMappingSpecificsList()));
        integrationSettingUpInformation.setAccountsSymbolCatalogueList(convertList(in.getAccountsSymbolCatalogueList()));
        integrationSettingUpInformation.setSlipRuleCatalogueList(convertList(in.getSlipRuleCatalogueList()));
        integrationSettingUpInformation.setSlipRulePositionProcessTypeMappingSpecificsList(convertList(in.getSlipRulePositionProcessTypeMappingSpecificsList()));
        integrationSettingUpInformation.setAccountsSymbolAccountSubjectMappingSpecificsList(convertList(in.getAccountsSymbolAccountSubjectMappingSpecificsList()));
        integrationSettingUpInformation.setPositionProcessTypeSlipGenerationMappingSpecificsList(convertList(in.getPositionProcessTypeSlipGenerationMappingSpecificsList()));
        integrationSettingUpInformation.setConditionGroupCatalogueList(convertList(in.getConditionGroupCatalogueList()));
        integrationSettingUpInformation.setProductClassificationCatalogueList(convertList(in.getProductClassificationCatalogueList()));
        integrationSettingUpInformation.setProductTypeCatalogueList(convertList(in.getProductTypeCatalogueList()));
        integrationSettingUpInformation.setEvaluationUnitPriceClassificationCodeSpecificsList(convertList(in.getEvaluationUnitPriceClassificationCodeSpecificsList()));
        integrationSettingUpInformation.setConditionTypeConditionGroupMappingSpecificsList(convertList(in.getConditionTypeConditionGroupMappingSpecificsList()));
        integrationSettingUpInformation.setConditionTypeDefinitionCatalogueList(convertList(in.getConditionTypeDefinitionCatalogueList()));
        integrationSettingUpInformation.setConditionTypePositionProcessTypeMappingSpecificsList(convertList(in.getConditionTypePositionProcessTypeMappingSpecificsList()));
        integrationSettingUpInformation.setTradeProcessTypeCatalogueList(convertList(in.getTradeProcessTypeCatalogueList()));
        integrationSettingUpInformation.setTradeClassificationCatalogueList(convertList(in.getTradeClassificationCatalogueList()));
        integrationSettingUpInformation.setTradeTypeCatalogueList(convertList(in.getTradeTypeCatalogueList()));
        integrationSettingUpInformation.setEventClassificationCatalogueList(convertList(in.getEventClassificationCatalogueList()));
        integrationSettingUpInformation.setEventTypeCatalogueList(convertList(in.getEventTypeCatalogueList()));
        integrationSettingUpInformation.setTradeEventTypeMappingSpecificsList(convertList(in.getTradeEventTypeMappingSpecificsList()));
        integrationSettingUpInformation.setEventPositionProcessTypeMappingSpecificsList(convertList(in.getEventPositionProcessTypeMappingSpecificsList()));
        integrationSettingUpInformation.setFunctionTradeProcessTypeMappingSpecificsList(convertList(in.getFunctionTradeProcessTypeMappingSpecificsList()));
        integrationSettingUpInformation.setPositionProcessTypeCatalogueList(convertList(in.getPositionProcessTypeCatalogueList()));
        integrationSettingUpInformation.setUnsettlementAccountsManagementSpecificsList(convertList(in.getUnsettlementAccountsManagementSpecificsList()));
        integrationSettingUpInformation.setCommonTableMappingSpecificsList(convertList(in.getCommonTableMappingSpecificsList()));
        integrationSettingUpInformation.setFinanceProductClassificationMappingSpecificsList(convertList(in.getFinanceProductClassificationMappingSpecificsList()));
        integrationSettingUpInformation.setPaymentTaxAmountSpecificsWithholdingTaxProcessTypeMappingSpecificsList(convertList(in.getPaymentTaxAmountSpecificsWithholdingTaxProcessTypeMappingSpecificsList()));
        integrationSettingUpInformation.setPaymentTaxAmountSpecificsPositionTaxProcessTypeMappingSpecificsList(convertList(in.getPaymentTaxAmountSpecificsPositionTaxProcessTypeMappingSpecificsList()));

        /* 대손충당금 */
        integrationSettingUpInformation.setAllowanceForBadDebtsSettingUpTargetBaseSpecificsList(convertList(in.getAllowanceForBadDebtsSettingUpTargetBaseSpecificsList()));
        integrationSettingUpInformation.setCreditGradeNumberGradeMappingSpecificsList(convertList(in.getCreditGradeNumberGradeMappingSpecificsList()));
        integrationSettingUpInformation.setApplyCreditGradeComputationBaseSpecificsList(convertList(in.getApplyCreditGradeComputationBaseSpecificsList()));
        integrationSettingUpInformation.setCreditRiskHeedIncreaseBaseSpecificsList(convertList(in.getCreditRiskHeedIncreaseBaseSpecificsList()));
        integrationSettingUpInformation.setAllowanceForBadDebtsStageClassificationBaseSpecificsList(convertList(in.getAllowanceForBadDebtsStageClassificationBaseSpecificsList()));
        integrationSettingUpInformation.setAllowanceForBadDebtsPositionProcessTypeMappingSpecificsList(convertList(in.getAllowanceForBadDebtsPositionProcessTypeMappingSpecificsList()));
        /* 개인대출 */
        integrationSettingUpInformation.setPersonalLoanAttributeGroupCodeCatalogueList(convertList(in.getPersonalLoanAttributeGroupCodeCatalogueList()));
        integrationSettingUpInformation.setPersonalLoanAttributeGroupSettingUpSpecificsList(convertList(in.getPersonalLoanAttributeGroupSettingUpSpecificsList()));
        integrationSettingUpInformation.setPersonalLoanEventCodeCatalogueList(convertList(in.getPersonalLoanEventCodeCatalogueList()));
        integrationSettingUpInformation.setPersonalLoanEarlierRedemptionComputationTermSettingUpSpecificsList(convertList(in.getPersonalLoanEarlierRedemptionComputationTermSettingUpSpecificsList()));
        /* 금리커브 */
        integrationSettingUpInformation.setInterestRateCurveCatalogueList(convertList(in.getInterestRateCurveCatalogueList()));
        integrationSettingUpInformation.setInterestRateCurveSettingUpSpecificsList(convertList(in.getInterestRateCurveSettingUpSpecificsList()));
        integrationSettingUpInformation.setRiskFreeInterestRateCurveEvaluationGroupMappingSpecificsList(convertList(in.getRiskFreeInterestRateCurveEvaluationGroupMappingSpecificsList()));

        return integrationSettingUpInformation;
    }
}
