package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.configuration.AccountManagementGroup;
import com.noaats.rest.bos.biz.cr.configuration.IAccountManagementGroupService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/account-management-group")
public class AccountManagementGroupController extends BaseController {

    private final IAccountManagementGroupService accountManagementGroupService;

    @GetMapping
    public ResponseEntity<AccountManagementGroupOut> getAccountManagementGroup(@RequestBody BaseRequest<AccountManagementGroupIn> request) throws CustomException {
        AccountManagementGroupIn in = request.getData();
        AccountManagementGroupOut out = new AccountManagementGroupOut();
        // convert
        AccountManagementGroup accountManagementGroup = convert(in.getAccountManagementGroup());

        List<AccountManagementGroup> accountManagementGroupList = accountManagementGroupService.getAccountManagementGroup(accountManagementGroup);
        out.setAccountManagementGroupList(accountManagementGroupList);
        return ResponseEntity.ok(out);
    }
}
