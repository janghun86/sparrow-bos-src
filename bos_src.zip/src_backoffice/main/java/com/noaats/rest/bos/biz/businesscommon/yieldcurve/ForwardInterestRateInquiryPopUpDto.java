package com.noaats.rest.bos.biz.businesscommon.yieldcurve;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ForwardInterestRateInquiryPopUpDto extends BaseDto {
    private double frwdIrt;
    private double irtM;
    private String dtAplyM;
    private String dtM;
    private double irtN;
    private String dtAplyN;
    private String dtN;
    private String dtT;
    private String bseDt;
    private String rfrIrtCd;

    @JsonIgnore
    public Class getBusinessClass() {
        return ForwardInterestRateInquiryPopUp.class;
    }
}
