package com.noaats.rest.bos.biz.account.journalize;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.account.journalize.JournalizeDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AssetsSlipGenerationDto extends JournalizeDto {
    private String trPcsTp;
    private String sttBseDt;
    private String endBseDt;
    private String prdNm;
    private String chkYn;
    private String prdGrp;
    private String trPcsTpNm;
    private String pofNm;
    private String ptTlzGrpNm;
    private String asjNm;
    private String nettingYn;
    private String ptPcsTpNm;
    private String slpRulNm;
    private String atsSymCdNm;
    private String acPcsIdfrNm;
    private String cptyNm;
    private String acEvlTpNm;
    private String evlAreaNm;
    private long scrnSqn;
    private String rowPtTrnoGubun;
    private String evlGrpIdList;

    @JsonIgnore
    public Class getBusinessClass() {
        return AssetsSlipGeneration.class;
    }
}
