package com.noaats.rest.bos.biz.cr.cashflow.flexibleinterestrate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionFlexibleInterestRateDto extends BaseDto {
    private String prdNo;
    private Long sno;
    private String aplySttDt;
    private String aplyEndDt;
    private String irtCpuBseDt;
    private String irtDfnDt;
    private String irtAplyDt;
    private Double mktIrt;
    private Double addIrt;
    private Double aplyIrt;
    private String mnwkRflYn;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionFlexibleInterestRate.class;
    }
}
