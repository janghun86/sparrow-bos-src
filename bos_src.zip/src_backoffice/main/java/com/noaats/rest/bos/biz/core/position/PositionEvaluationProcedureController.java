package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.IPositionEvaluationProcedureCatalogueService;
import com.noaats.rest.bos.biz.cr.PositionEvaluationProcedureCatalogue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/evaluation-procedure")
public class PositionEvaluationProcedureController extends BaseController {

    private final IPositionEvaluationProcedureCatalogueService positionEvaluationProcedureCatalogueService;

    @GetMapping
    public ResponseEntity<PositionEvaluationProcedureOut> service(@RequestBody BaseRequest<PositionEvaluationProcedureIn> request) throws CustomException {
        PositionEvaluationProcedureIn in = request.getData();
        PositionEvaluationProcedureOut out = new PositionEvaluationProcedureOut();

        PositionEvaluationProcedureCatalogue positionEvaluationProcedureCatalogue = convert(in.getPositionEvaluationProcedureCatalogue());

        List<PositionEvaluationProcedureCatalogue> positionEvaluationProcedureCatalogueList = positionEvaluationProcedureCatalogueService.findUseAll(positionEvaluationProcedureCatalogue);
        out.setPositionEvaluationProcedureCatalogueList(positionEvaluationProcedureCatalogueList);
        return ResponseEntity.ok(out);
    }
}
