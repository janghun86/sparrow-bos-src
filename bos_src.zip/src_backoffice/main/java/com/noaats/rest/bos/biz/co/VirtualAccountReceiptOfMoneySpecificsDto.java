package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class VirtualAccountReceiptOfMoneySpecificsDto extends BaseDto {
    private String moAno;
    private String vaNo;
    private LocalDateTime bseDtm;
    private String ptTlzGrpId;
    private String ptTlzGrpNm;
    private String brn;
    private String bprNm;
    private LocalDateTime isnDtm;
    private String drwIstCd;
    private String drwAno;
    private String drwActNm;
    private Double trAmt;
    private Double feeAmt;
    private LocalDateTime trDtm;
    private String rfrNo;
    private String cclRsnCd;
    private String actUsgCd;
    private String bizAreaTc;
    private String trTc;
    private String tfrCgprId;
    private String rpyPcsYn;
    private String rpyPcsDt;
    private String rpyPcsUsid;
    private Long stmLnkNo;

    @JsonIgnore
    public Class getBusinessClass() {
        return VirtualAccountReceiptOfMoneySpecifics.class;
    }
}
