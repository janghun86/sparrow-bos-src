package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.data.PositionType;
import com.noaats.rest.bos.biz.cr.position.Position;
import com.noaats.rest.bos.biz.cr.position.PositionEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/engine-test")
public class PositionEngineTestController extends BaseController {

    private final IPositionEngineTestService<PositionEngineTest> positionEngineTestService;

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<PositionEngineTestOut> process(@RequestBody BaseRequest<PositionEngineTestIn> request) throws CustomException {
        PositionEngineTestIn in = request.getData();
        PositionEngineTest positionEngineTest = new PositionEngineTest();
        Position position = new Position();

        positionEngineTest = convert(in.getPositionEngineTest());

        position.setIstCd(positionEngineTest.getIstCd());                                // 기관코드
        position.setAcMngGrpId(positionEngineTest.getAcMngGrpId());                      // 회계관리그룹ID
        position.setPofId(positionEngineTest.getPofId());                                // 포트폴리오ID
        position.setPrdNo(positionEngineTest.getPrdNo());                                // 상품번호
        position.setPtBseDt(positionEngineTest.getPtBseDt());                            // 포지션기준일자
        position.setStmDt(positionEngineTest.getStmDt());                                // 결제일자
        position.setPtTlzId(positionEngineTest.getPtTlzId());                            // 포지션집계ID
        position.setPtTlzGrpId(positionEngineTest.getPtTlzGrpId());                      // 포지션집계그룹ID
        position.setTrFntTc(positionEngineTest.getTrFntTc());
        position.setPrdTpId(positionEngineTest.getPrdTpId());                            // 상품유형ID
        position.setTrCurCd(positionEngineTest.getPtCurCd());                            // 포지션통화코드
        position.setEvlTpId(positionEngineTest.getEvlTpId());
        position.setPtLdgTc("01");                                                       //
        position.setPositionType(PositionType.POS.code());
        position.setTrPcsTpId(in.getPositionEngineEventList().get(0).getTrPcsTpId());   // 거래처리유형ID
        position.setPcsStsTc(positionEngineTest.getPcsStsTc());                          // 처리유형구분코드
        position.setLnkTrPtTrno(positionEngineTest.getLnkTrPtTrno());

        List<PositionEvent> positionEventList = new ArrayList<>();
        List<PositionEngineEvent> positionEngineEventList = convertList(in.getPositionEngineEventList());
        for (PositionEngineEvent positionEngineEvent : positionEngineEventList) {

            positionEventList.add(positionEngineEvent);
        }

        positionEngineTestService.process(position, positionEventList);

        String ptTrno = position.getPositionManagementBaseList().get(0).getPositionTradeList().get(0).getPtTrno();

        for (PositionEngineEvent positionEngineEvent : positionEngineEventList) {
            positionEngineEvent.setPtTrno(ptTrno);
        }

        PositionEngineTestOut out = new PositionEngineTestOut();
        out.setPositionEngineEventList(positionEngineEventList);

        //시스템 메시지
        //systemMessageService.setReadMsgCd(out.getPositionEngineEventList(), requestHeader);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<PositionEngineTestOut> cancel(@RequestBody
                                                            BaseRequest<PositionEngineTestIn> request) throws CustomException {
        PositionEngineTestIn in = request.getData();
        PositionEngineTestOut out = new PositionEngineTestOut();
        positionEngineTestService.cancel((PositionEngineTest) convert(in.getPositionEngineTest()));
        return ResponseEntity.ok(out);
    }

    @GetMapping
    public ResponseEntity<PositionEngineTestOut> inquiry(@RequestBody BaseRequest<PositionEngineTestIn> request) throws CustomException {
        PositionEngineTestIn in = request.getData();
        PositionEngineTestOut out = new PositionEngineTestOut();
        PositionEngineTest positionEngineTest = positionEngineTestService.inquiry(convert(in.getPositionEngineTest()));
        out.setPositionEngineTest(positionEngineTest);
        out.setPositionEngineEventList(positionEngineTest.getPositionEngineEventList());
        //시스템 메시지
        //systemMessageService.setReadMsgCd(out.getPositionEngineTest(), requestHeader);
        return ResponseEntity.ok(out);
    }
}
