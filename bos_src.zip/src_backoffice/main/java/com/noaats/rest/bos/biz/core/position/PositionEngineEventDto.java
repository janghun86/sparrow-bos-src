package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.position.PositionEventDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionEngineEventDto extends PositionEventDto {
    private String trPcsTpId;
    private String ptPcsTpNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionEngineEvent.class;
    }
}
