package com.noaats.rest.bos.biz.cr.account;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountDto extends BaseDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return Account.class;
    }
}
