package com.noaats.rest.bos.biz.co.marketdata;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EvaluationPriceDto extends BaseDto {
    private String prdNm;
    private String cndGrpId;
    private String prdTpNm;
    private String prdClsId;
    private String acMngGrpId;
    private String trTpId;
    private String evlGrpNm;
    private String evlGrpId;
    private String curCd;
    private String rmk;
    private String bseDt;
    private Double evlUpr;
    private String prdNo;
    private Integer vrs;
    private String prdTpId;
    private String evlUprTpId;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return EvaluationPrice.class;
    }
}
