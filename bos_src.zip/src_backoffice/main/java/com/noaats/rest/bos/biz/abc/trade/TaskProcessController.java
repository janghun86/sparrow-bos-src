package com.noaats.rest.bos.biz.abc.trade;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.abc.tr.*;
import com.noaats.rest.bos.biz.tr.TaskBasic;
import com.noaats.rest.bos.biz.tr.TaskProcessSpecifics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/abc/trade")
public class TaskProcessController extends BaseController {

    private final TaskProcessService taskProcessService;

    @GetMapping
    public ResponseEntity<TaskProcessOut> inquiry(@RequestBody BaseRequest<TaskProcessIn> request) throws CustomException {
        TaskProcessIn in = request.getData();
        TaskProcessOut out = new TaskProcessOut();
        // convert
        TaskProcessSpecifics taskProcessSpecifics = convert(in.getTaskProcessSpecifics());
        TaskBasic taskBasic = convert(in.getTaskBasic());

        TaskProcess taskProcess = taskProcessService.searchTask(taskBasic, taskProcessSpecifics);
        out.setTaskBasic(taskProcess.getTaskBasic()); // 태스크기본
        out.setTaskServiceInfoList(taskProcess.getTaskServiceInfoList()); // 태스크서비스
        out.setHeadingGroupInfoList(taskProcess.getHeadingGroupInfoList()); // 항목그룹
        out.setHeadingInfoList(taskProcess.getHeadingInfoList()); // 항목
        out.setPluralHeadingMappingSpecificsList(taskProcess.getPluralHeadingMappingSpecificsList()); // 복수항목

        if (!StringUtils.isEmpty(taskProcessSpecifics.getTskUnqId())) {
            out.setTaskHistoryList(taskProcess.getTaskHistoryList()); // 처리명세
            out.setTaskProcessHeadingSpecificsList(taskProcess.getTaskProcessHeadingSpecificsList()); // 처리항목명세
            out.setTaskProcessPluralHeadingSpecificsList(taskProcess.getTaskProcessPluralHeadingSpecificsList()); // 처리복수항목명세
        }
        return ResponseEntity.ok(out);
    }

    @GetMapping("/transaction")
    public ResponseEntity<TaskProcessOut> callTransaction(@RequestBody BaseRequest<TaskProcessIn> request) throws CustomException {
        TaskProcessIn in = request.getData();
        TaskProcessOut out = new TaskProcessOut();
        // convert
        List<DynamicDataStructure> dynamicDataStructureList = convertList(in.getDynamicDataStructureList());
        TaskServiceInfo taskServiceInfo = convert(in.getTaskServiceInfo());

        List<DynamicDataStructure> resultList = taskProcessService.callTransaction(dynamicDataStructureList, taskServiceInfo);
        out.setDynamicDataStructureList(resultList);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TaskProcessOut> registration(@RequestBody BaseRequest<TaskProcessIn> request) throws CustomException {
        TaskProcessIn in = request.getData();
        TaskProcessOut out = new TaskProcessOut();
        // convert
        TaskServiceInfo taskServiceInfo = convert(in.getTaskServiceInfo());

        TaskProcess taskProcess = taskProcessService.registerLog(taskServiceInfo); // 태스크처리명세 적재
        out.setTaskServiceInfo(taskProcess.getTaskServiceInfo());
        return ResponseEntity.ok(out);
    }
}
