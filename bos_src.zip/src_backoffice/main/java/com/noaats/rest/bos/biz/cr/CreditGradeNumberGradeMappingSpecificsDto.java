package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreditGradeNumberGradeMappingSpecificsDto extends BaseDto {
    private String crdGrTc;
    private String crdGrClsTc;
    private String crdGrCd;
    private Integer vrs;
    private Long noCrdGrCd;

    @JsonIgnore
    public Class getBusinessClass() {
        return CreditGradeNumberGradeMappingSpecifics.class;
    }
}
