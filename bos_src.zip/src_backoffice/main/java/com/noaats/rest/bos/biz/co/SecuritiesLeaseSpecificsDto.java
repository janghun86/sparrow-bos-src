package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecuritiesLeaseSpecificsDto extends BaseDto {
    private String ptTrno;
    private String cttCcsDt;
    private Long lseImdIstNo;
    private String lseTrTc;
    private Double bdFeeAplyUpr;
    private Double lseFrt;
    private String imdFeeCalBseTc;
    private Double imdFrt;
    private Double intcFrt;

    @JsonIgnore
    public Class getBusinessClass() {
        return SecuritiesLeaseSpecifics.class;
    }
}
