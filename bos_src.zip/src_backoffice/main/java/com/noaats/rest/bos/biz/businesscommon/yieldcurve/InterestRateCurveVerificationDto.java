package com.noaats.rest.bos.biz.businesscommon.yieldcurve;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InterestRateCurveVerificationDto extends BaseDto {
    private String istCd;
    private String irtCurvId;
    private String rfrIrtCd;
    private Integer irtTrm;
    private String trmUntTc;
    private String ddsCalMthTc;
    private String irtCurvDt;
    private String intBseDt;
    private Integer dds;
    private Double zroCpnIrt;
    private Double zroCpnDcrt;
    private String rfrIrtNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return InterestRateCurveVerification.class;
    }
}
