/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.businesscommon.evaluation;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.EvaluationUnitPriceClassificationCodeSpecifics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/evaluation/unit-price")
public class EvaluationUnitPriceTypeController extends BaseController {

    private final IEvaluationUnitPriceTypeService<EvaluationUnitPriceClassificationCodeSpecifics> evaluationUnitPriceTypeService;

    @GetMapping
    public ResponseEntity<EvaluationUnitPriceTypeOut> inquiry(@RequestBody BaseRequest<EvaluationUnitPriceTypeIn> request) throws CustomException {
        EvaluationUnitPriceTypeIn in = request.getData();
        EvaluationUnitPriceTypeOut out = new EvaluationUnitPriceTypeOut();
        // convert
        EvaluationUnitPriceClassificationCodeSpecifics evaluationUnitPriceClassificationCodeSpecifics = convert(in.getEvaluationUnitPriceClassificationCodeSpecifics());

        List<EvaluationUnitPriceClassificationCodeSpecifics> resultList = evaluationUnitPriceTypeService.inquiry(evaluationUnitPriceClassificationCodeSpecifics);
        out.setEvaluationUnitPriceClassificationCodeSpecificsList(resultList);
        return ResponseEntity.ok(out);
    }
}
