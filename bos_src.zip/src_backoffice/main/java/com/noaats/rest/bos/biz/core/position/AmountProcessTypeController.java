package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.AmountProcessTypeCatalogue;
import com.noaats.rest.bos.biz.cr.IAmountProcessTypeCatalogueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/amount-process-type")
public class AmountProcessTypeController extends BaseController {

    private final IAmountProcessTypeCatalogueService amountProcessTypeCatalogueService;

    @GetMapping
    public ResponseEntity<AmountProcessTypeOut> service(@RequestBody BaseRequest<AmountProcessTypeIn> request) throws CustomException {
        AmountProcessTypeIn in = request.getData();
        AmountProcessTypeOut out = new AmountProcessTypeOut();
        // convert
        AmountProcessTypeCatalogue amountProcessTypeCatalogue = convert(in.getAmountProcessTypeCatalogue());

        List<AmountProcessTypeCatalogue> amountProcessTypeCatalogueList = amountProcessTypeCatalogueService.findUseAll(amountProcessTypeCatalogue);
        out.setAmountProcessTypeCatalogueList(amountProcessTypeCatalogueList);
        return ResponseEntity.ok(out);
    }
}
