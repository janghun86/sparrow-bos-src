package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.core.position.eventtype.IConfigurationManagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/configuration")
public class ConfigurationManagementController extends BaseController {

    private final IConfigurationManagementService<ConfigurationManagement> configurationManagementService;

    @GetMapping
    public ResponseEntity<ConfigurationManagementOut> inquiry(@RequestBody BaseRequest<ConfigurationManagementIn> request) throws CustomException {
        ConfigurationManagementIn in = request.getData();
        ConfigurationManagement configurationManagement = new ConfigurationManagement();

        List<TableSchemaInfo> tableSchemaInfoList = convertList(in.getTableSchemaInfoList());

        configurationManagement.setTableSchemaInfoList(tableSchemaInfoList);

        configurationManagementService.inquiry(configurationManagement);
        ConfigurationManagementOut out = new ConfigurationManagementOut();

        out.setAccountManagementGroupList(configurationManagement.getAccountManagementGroupList());
        out.setAccountProcessIdentifierList(configurationManagement.getAccountProcessIdentifierList());
        out.setAccountProcessIdentifierMappingList(configurationManagement.getAccountProcessIdentifierMappingList());
        out.setAmountProcessTypeList(configurationManagement.getAmountProcessTypeList());
        out.setConditionGroupList(configurationManagement.getConditionGroupList());
        out.setDependencyPositionProcessTypeOutflowOrInflowMappingList(configurationManagement.getDependencyPositionProcessTypeOutflowOrInflowMappingList());
        out.setDependencyPositionProcessTypeRealizationMappingList(configurationManagement.getDependencyPositionProcessTypeRealizationMappingList());
        out.setDependencyPositionProcessTypeTransferMappingList(configurationManagement.getDependencyPositionProcessTypeTransferMappingList());
        out.setEvaluationAreaList(configurationManagement.getEvaluationAreaList());
        out.setEvaluationAreaMappingList(configurationManagement.getEvaluationAreaMappingList());
        out.setEvaluationGroupMappingList(configurationManagement.getEvaluationGroupMappingList());
        out.setEvaluationTypeList(configurationManagement.getEvaluationTypeList());
        out.setEvaluationTypeMappingList(configurationManagement.getEvaluationTypeMappingList());
        out.setEventCategoryList(configurationManagement.getEventCategoryList());
        out.setEventPositionProcessTypeMappingList(configurationManagement.getEventPositionProcessTypeMappingList());
        out.setEventTypeList(configurationManagement.getEventTypeList());
        out.setFunctionTradeProcessTypeMappingList(configurationManagement.getFunctionTradeProcessTypeMappingList());
        out.setInstitutionCodeList(configurationManagement.getInstitutionCodeList());
        out.setPortfolioList(configurationManagement.getPortfolioList());
        out.setProductCategoryList(configurationManagement.getProductCategoryList());
        out.setProductEvaluationAreaMappingList(configurationManagement.getProductEvaluationAreaMappingList());
        out.setProductEvaluationGroupMappingList(configurationManagement.getProductEvaluationGroupMappingList());
        out.setProductTypeList(configurationManagement.getProductTypeList());
        out.setPositionClassificationUnitCatalogueList(configurationManagement.getPositionClassificationUnitCatalogueList());
        out.setPositionEvaluationProcedureList(configurationManagement.getPositionEvaluationProcedureList());
        out.setPositionEvaluationProcedureMappingList(configurationManagement.getPositionEvaluationProcedureMappingList());
        out.setPositionHeadingConfigurationElementMappingList(configurationManagement.getPositionHeadingConfigurationElementMappingList());
        out.setPositionHeadingList(configurationManagement.getPositionHeadingList());
        out.setPositionProcessTypeList(configurationManagement.getPositionProcessTypeList());
        out.setPositionProcessTypeMappingList(configurationManagement.getPositionProcessTypeMappingList());
        out.setPositionTotalizationGroupList(configurationManagement.getPositionTotalizationGroupList());
        out.setPositionUniqueNumberMappingList(configurationManagement.getPositionUniqueNumberMappingList());
        out.setTradeCategoryList(configurationManagement.getTradeCategoryList());
        out.setTradeEventTypeMappingList(configurationManagement.getTradeEventTypeMappingList());
        out.setTradeProcessTypeList(configurationManagement.getTradeProcessTypeList());
        out.setTradeTypeList(configurationManagement.getTradeTypeList());

        return ResponseEntity.ok(out);
    }

    @GetMapping("/table-schema")
    public ResponseEntity<ConfigurationManagementOut> inquiryTableSchema(@RequestBody BaseRequest<ConfigurationManagementIn> request) throws CustomException {
        ConfigurationManagementIn in = request.getData();
        ConfigurationManagement configurationManagement = new ConfigurationManagement();

        List<TableSchemaInfo> tableSchemaInfoList = convertList(in.getTableSchemaInfoList());

        configurationManagement.setTableSchemaInfoList(tableSchemaInfoList);
        configurationManagementService.inquiryTableSchema(configurationManagement);
        ConfigurationManagementOut out = new ConfigurationManagementOut();
        out.setTableSchemaInfoList(configurationManagement.getTableSchemaInfoList());
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<ConfigurationManagementOut> modify(@RequestBody BaseRequest<ConfigurationManagementIn> request) throws CustomException {
        ConfigurationManagementIn in = request.getData();
        ConfigurationManagementOut out = new ConfigurationManagementOut();
        ConfigurationManagement configurationManagement = new ConfigurationManagement();
        configurationManagement.setTableSchemaInfoList(convertList(in.getTableSchemaInfoList()));
        configurationManagement.setAccountManagementGroupList(convertList(in.getAccountManagementGroupList()));
        configurationManagement.setAccountProcessIdentifierList(convertList(in.getAccountProcessIdentifierList()));
        configurationManagement.setAccountProcessIdentifierMappingList(convertList(in.getAccountProcessIdentifierMappingList()));
        configurationManagement.setAmountProcessTypeList(convertList(in.getAmountProcessTypeList()));
        configurationManagement.setConditionGroupList(convertList(in.getConditionGroupList()));
        configurationManagement.setDependencyPositionProcessTypeOutflowOrInflowMappingList(convertList(in.getDependencyPositionProcessTypeOutflowOrInflowMappingList()));
        configurationManagement.setDependencyPositionProcessTypeRealizationMappingList(convertList(in.getDependencyPositionProcessTypeRealizationMappingList()));
        configurationManagement.setDependencyPositionProcessTypeTransferMappingList(convertList(in.getDependencyPositionProcessTypeTransferMappingList()));
        configurationManagement.setEvaluationAreaList(convertList(in.getEvaluationAreaList()));
        configurationManagement.setEvaluationAreaMappingList(convertList(in.getEvaluationAreaMappingList()));
        configurationManagement.setEvaluationGroupMappingList(convertList(in.getEvaluationGroupMappingList()));
        configurationManagement.setEvaluationTypeList(convertList(in.getEvaluationTypeList()));
        configurationManagement.setEvaluationTypeMappingList(convertList(in.getEvaluationTypeMappingList()));
        configurationManagement.setEventCategoryList(convertList(in.getEventCategoryList()));
        configurationManagement.setEventPositionProcessTypeMappingList(convertList(in.getEventPositionProcessTypeMappingList()));
        configurationManagement.setEventTypeList(convertList(in.getEventTypeList()));
        configurationManagement.setFunctionTradeProcessTypeMappingList(convertList(in.getFunctionTradeProcessTypeMappingList()));
        configurationManagement.setInstitutionCodeList(convertList(in.getInstitutionCodeList()));
        configurationManagement.setPortfolioList(convertList(in.getPortfolioList()));
        configurationManagement.setProductCategoryList(convertList(in.getProductCategoryList()));
        configurationManagement.setProductEvaluationAreaMappingList(convertList(in.getProductEvaluationAreaMappingList()));
        configurationManagement.setProductEvaluationGroupMappingList(convertList(in.getProductEvaluationGroupMappingList()));
        configurationManagement.setProductTypeList(convertList(in.getProductTypeList()));
        configurationManagement.setPositionClassificationUnitCatalogueList(convertList(in.getPositionClassificationUnitCatalogueList()));
        configurationManagement.setPositionEvaluationProcedureList(convertList(in.getPositionEvaluationProcedureList()));
        configurationManagement.setPositionEvaluationProcedureMappingList(convertList(in.getPositionEvaluationProcedureMappingList()));
        configurationManagement.setPositionHeadingConfigurationElementMappingList(convertList(in.getPositionHeadingConfigurationElementMappingList()));
        configurationManagement.setPositionHeadingList(convertList(in.getPositionHeadingList()));
        configurationManagement.setPositionProcessTypeList(convertList(in.getPositionProcessTypeList()));
        configurationManagement.setPositionProcessTypeMappingList(convertList(in.getPositionProcessTypeMappingList()));
        configurationManagement.setPositionTotalizationGroupList(convertList(in.getPositionTotalizationGroupList()));
        configurationManagement.setPositionUniqueNumberMappingList(convertList(in.getPositionUniqueNumberMappingList()));
        configurationManagement.setTradeCategoryList(convertList(in.getTradeCategoryList()));
        configurationManagement.setTradeEventTypeMappingList(convertList(in.getTradeEventTypeMappingList()));
        configurationManagement.setTradeProcessTypeList(convertList(in.getTradeProcessTypeList()));
        configurationManagement.setTradeTypeList(convertList(in.getTradeTypeList()));

        configurationManagementService.modify(configurationManagement);

        return ResponseEntity.ok(out);
    }
}
