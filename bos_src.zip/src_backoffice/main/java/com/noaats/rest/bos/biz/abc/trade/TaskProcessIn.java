package com.noaats.rest.bos.biz.abc.trade;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.abc.tr.DynamicDataStructureDto;
import com.noaats.rest.bos.biz.abc.tr.HeadingGroupInfoDto;
import com.noaats.rest.bos.biz.abc.tr.TaskServiceInfoDto;
import com.noaats.rest.bos.biz.tr.TaskBasicDto;
import com.noaats.rest.bos.biz.tr.TaskProcessHeadingSpecificsDto;
import com.noaats.rest.bos.biz.tr.TaskProcessPluralHeadingSpecificsDto;
import com.noaats.rest.bos.biz.tr.TaskProcessSpecificsDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class TaskProcessIn extends BaseMessage {
    private TaskBasicDto taskBasic = new TaskBasicDto();
    private TaskServiceInfoDto taskServiceInfo = new TaskServiceInfoDto();
    private HeadingGroupInfoDto headingGroupInfo = new HeadingGroupInfoDto();
    private TaskProcessSpecificsDto taskProcessSpecifics = new TaskProcessSpecificsDto();
    private TaskProcessHeadingSpecificsDto taskProcessHeadingSpecifics = new TaskProcessHeadingSpecificsDto();
    private TaskProcessPluralHeadingSpecificsDto taskProcessPluralHeadingSpecifics = new TaskProcessPluralHeadingSpecificsDto();
    private List<DynamicDataStructureDto> dynamicDataStructureList = new ArrayList<>();
}
