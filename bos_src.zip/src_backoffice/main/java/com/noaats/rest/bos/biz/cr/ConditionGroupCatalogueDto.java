package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConditionGroupCatalogueDto extends BaseDto {
    private String prdGrpTc;
    private String cndGrpId;
    private String cndGrpNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return ConditionGroupCatalogue.class;
    }
}
