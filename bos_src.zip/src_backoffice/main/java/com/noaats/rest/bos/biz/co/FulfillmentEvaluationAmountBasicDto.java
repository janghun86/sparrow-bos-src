package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FulfillmentEvaluationAmountBasicDto extends BaseDto {
    private String bseDt;
    private String pofId;
    private String prdNo;
    private String ptTlzGrpId;
    private String ptTlzId;
    private String acMngGrpId;
    private String evlAreaId;
    private Long dpsIstCptyNo;
    private Double amrAmt;
    private Double amrVca;
    private Double fcCvsPnlAmt;
    private Double mrprEvlPnlAmt;
    private Double mrprEvlPnlVca;

    @JsonIgnore
    public Class getBusinessClass() {
        return FulfillmentEvaluationAmountBasic.class;
    }
}
