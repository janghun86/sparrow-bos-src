package com.noaats.rest.bos.biz.core.position;

import com.noaats.rest.bos.biz.cr.evaluation.EffectivenessInterestRateMethodAmortize;
import com.noaats.rest.bos.biz.cr.evaluation.EffectivenessInterestRateMethodAmortizeCalculation;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class EvaluationProcessOut {
    private List<EvaluationProcess> evaluationProcessList;
    private List<EffectivenessInterestRateMethodAmortize> effectivenessInterestRateMethodAmortizeList;
    private List<EffectivenessInterestRateMethodAmortizeCalculation> effectivenessInterestRateMethodAmortizeCalculationList;
    private EvaluationProcess evaluationProcessForPaging;
    private List<EvaluationProcess> acEvlTpList;
}
