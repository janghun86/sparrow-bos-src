package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationGroupAchieveBusinessDetailsHistoryDto extends BaseDto {
    private String ptTlzGrpId;
    private String bseDt;
    private String achvBzTc;
    private Long sno;
    private String achvBzOtl;
    private String achvBzDtlCts;
    private String docKpnTc;
    private String docMngNo;
    private String ekpBlbNo;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionTotalizationGroupAchieveBusinessDetailsHistory.class;
    }
}
