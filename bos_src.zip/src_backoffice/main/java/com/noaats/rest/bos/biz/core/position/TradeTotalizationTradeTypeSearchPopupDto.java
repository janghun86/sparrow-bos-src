package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.TradeTotalizationTradeTypeCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeTotalizationTradeTypeSearchPopupDto extends TradeTotalizationTradeTypeCatalogueDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return TradeTotalizationTradeTypeSearchPopup.class;
    }
}
