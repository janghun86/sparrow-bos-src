package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionEvaluationProcedureDto extends BaseDto {
    private String ptEvlPcdrId;
    private String ptEvlPcdrNm;
    private String evlStg1Tc;
    private String evlPcs1Id;
    private String evlStg2Tc;
    private String evlPcs2Id;
    private String evlStg3Tc;
    private String evlPcs3Id;
    private String evlStg4Tc;
    private String evlPcs4Id;
    private String evlStg5Tc;
    private String evlPcs5Id;
    private String astDbtPtTc;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionEvaluationProcedure.class;
    }
}
