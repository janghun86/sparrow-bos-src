package com.noaats.rest.bos.biz.abc.taskmanagement;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServiceFunctionManagementDto extends BaseDto {
    private long seqlNo;
    private String istCd;
    private String tskSvcId;
    private Integer vrs;
    private String tskSvcNm;
    private String tskSvcTc;
    private String tbId;
    private String svcId;
    private String fncId;

    @JsonIgnore
    public Class getBusinessClass() {
        return ServiceFunctionManagement.class;
    }
}
