package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.FinanceProductClassificationMappingSpecifics;
import com.noaats.rest.bos.biz.cr.IFinanceProductClassificationMappingSpecificsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <pre>
 *
 * description : 금융상품분류 정보 조회
 *
 * com.noaats.sol.controller.position
 *    FinanceProductClassificationController.java
 *
 * </pre>
 *
 * @author : 이예린
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2024. 07. 16.	이예린		최초생성
 *
 * </pre>
 * @version :
 * @date : 2024. 07. 16. 오후 5:50:07
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/finance")
public class FinanceProductClassificationController extends BaseController {

    private final IFinanceProductClassificationMappingSpecificsService financeProductClassificationMappingSpecificsService ;

    @GetMapping
    public ResponseEntity<FinanceProductClassificationOut> inquiry(@RequestBody BaseRequest<FinanceProductClassificationIn> request) throws CustomException {
        FinanceProductClassificationIn in = request.getData();
        FinanceProductClassificationOut out = new FinanceProductClassificationOut();

        FinanceProductClassificationMappingSpecifics financeProductClassificationMappingSpecifics = convert(in.getFinanceProductClassificationMappingSpecifics());

        List<FinanceProductClassificationMappingSpecifics> modelReturn = financeProductClassificationMappingSpecificsService.findByPrdTpIdAndQtaFnoTc(financeProductClassificationMappingSpecifics);
        out.setFinanceProductClassificationMappingSpecificsList(modelReturn);
        return ResponseEntity.ok(out);
    }
}
