package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EvaluationPositionProcessTypeMappingSpecificsDto extends BaseDto {
    private String ptEvlPcdrId;
    private String evlStgTc;
    private String pftPtPcsTpId;
    private String lssPtPcsTpId;
    private String pftRsuPtPcsTpId;
    private String lssRsuPtPcsTpId;
    private String bftPftRpyPtPcsTpId;
    private String bftLssRpyPtPcsTpId;
    private String bftPftRpyRsuPtPcsTpId;
    private String bftLssRpyRsuPtPcsTpId;
    private String evlPftAdjtPtPcsTpId;
    private String evlLssAdjtPtPcsTpId;
    private String evlPftAdjtRsuPtPcsTpId;
    private String evlLssAdjtRsuPtPcsTpId;
    private String cfhAstPtPcsTpId;
    private String cfhDbtPtPcsTpId;
    private String bftCfhAstRpyPtPcsTpId;
    private String bftCfhDbtRpyPtPcsTpId;
    private String cfhepPtPcsTpId;
    private String cfhelPtPcsTpId;
    private String bftCfhepRpyPtPcsTpId;
    private String bftCfhelRpyPtPcsTpId;
    private String cfhipPtPcsTpId;
    private String cfhilPtPcsTpId;
    private String cfhFccPftPtPcsTpId;
    private String cfhFccLssPtPcsTpId;
    private String cfhAstRsuPtPcsTpId;
    private String cfhDbtRsuPtPcsTpId;
    private String bftCfhAstRpyRsuPtPcsTpId;
    private String bftCfhDbtRpyRsuPtPcsTpId;
    private String cfhepRsuPtPcsTpId;
    private String cfhelRsuPtPcsTpId;
    private String bftCfhepRpyRsuPtPcsTpId;
    private String bftCfhelRpyRsuPtPcsTpId;
    private String cfhipRsuPtPcsTpId;
    private String cfhilRsuPtPcsTpId;
    private String cfhFccPftRsuPtPcsTpId;
    private String cfhFccLssRsuPtPcsTpId;
    private String iohDrsLssAtnPtPcsTpId;
    private String iohDrsPftAtnPtPcsTpId;

    @JsonIgnore
    public Class getBusinessClass() {
        return EvaluationPositionProcessTypeMappingSpecifics.class;
    }
}
