package com.noaats.rest.bos.biz.businesscommon.counterparty;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.co.CounterpartyAppendInformationSpecifics;
import com.noaats.rest.bos.biz.co.CounterpartyBasic;
import com.noaats.rest.bos.biz.co.CounterpartyRoleSpecifics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/counterparty")
public class CounterpartyManagementController extends BaseController {

    private final ICounterpartyManagementService<CounterpartyManagement> counterpartyManagementService;

    @GetMapping
    public ResponseEntity<CounterpartyManagementOut> inquiry(@RequestBody BaseRequest<CounterpartyManagementIn> request) throws CustomException {
        CounterpartyManagementIn in = request.getData();
        CounterpartyManagementOut out = new CounterpartyManagementOut();
        CounterpartyManagement counterpartyManagement = new CounterpartyManagement();
        // convert
        CounterpartyBasic counterpartyBasic = convert(in.getCounterpartyBasic());

        counterpartyManagement.setCounterpartyBasic(counterpartyBasic);
        CounterpartyManagement result = counterpartyManagementService.inquiry(counterpartyManagement);
        out.setCounterpartyBasic(result.getCounterpartyBasic());
        out.setCounterpartyRoleSpecificsList(result.getCounterpartyRoleSpecificsList());
        out.setCounterpartyAppendInformationSpecificsList(result.getCounterpartyAppendInformationSpecificsList());
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CounterpartyManagementOut> registration(@RequestBody BaseRequest<CounterpartyManagementIn> request) throws CustomException {
        CounterpartyManagementIn in = request.getData();
        CounterpartyManagementOut out = new CounterpartyManagementOut();
        CounterpartyManagement counterpartyManagement = new CounterpartyManagement();
        // convert
        CounterpartyBasic counterpartyBasic = convert(in.getCounterpartyBasic());
        List<CounterpartyRoleSpecifics> counterpartyRoleSpecificsList = convertList(in.getCounterpartyRoleSpecificsList());
        List<CounterpartyAppendInformationSpecifics> counterpartyAppendInformationSpecificsList = convertList(in.getCounterpartyAppendInformationSpecificsList());

        counterpartyManagement.setCounterpartyBasic(counterpartyBasic);
        counterpartyManagement.setCounterpartyRoleSpecificsList(counterpartyRoleSpecificsList);
        counterpartyManagement.setCounterpartyAppendInformationSpecificsList(counterpartyAppendInformationSpecificsList);
        counterpartyManagementService.registration(counterpartyManagement);
        out.setCounterpartyBasic(counterpartyManagement.getCounterpartyBasic());
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CounterpartyManagementOut> update(@RequestBody BaseRequest<CounterpartyManagementIn> request) throws CustomException {
        CounterpartyManagementIn in = request.getData();
        CounterpartyManagementOut out = new CounterpartyManagementOut();
        CounterpartyManagement counterpartyManagement = new CounterpartyManagement();
        // convert
        CounterpartyBasic counterpartyBasic = convert(in.getCounterpartyBasic());
        List<CounterpartyRoleSpecifics> counterpartyRoleSpecificsList = convertList(in.getCounterpartyRoleSpecificsList());
        List<CounterpartyAppendInformationSpecifics> counterpartyAppendInformationSpecificsList = convertList(in.getCounterpartyAppendInformationSpecificsList());

        counterpartyManagement.setCounterpartyBasic(counterpartyBasic);
        counterpartyManagement.setCounterpartyRoleSpecificsList(counterpartyRoleSpecificsList);
        counterpartyManagement.setCounterpartyAppendInformationSpecificsList(counterpartyAppendInformationSpecificsList);
        counterpartyManagementService.registration(counterpartyManagement);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CounterpartyManagementOut> cancel(@RequestBody BaseRequest<CounterpartyManagementIn> request) throws CustomException {
        CounterpartyManagementIn in = request.getData();
        CounterpartyManagementOut out = new CounterpartyManagementOut();
        CounterpartyManagement counterpartyManagement = new CounterpartyManagement();
        // convert
        CounterpartyBasic counterpartyBasic = convert(in.getCounterpartyBasic());
        List<CounterpartyRoleSpecifics> counterpartyRoleSpecificsList = convertList(in.getCounterpartyRoleSpecificsList());

        counterpartyManagement.setCounterpartyBasic(counterpartyBasic);
        counterpartyManagement.setCounterpartyRoleSpecificsList(counterpartyRoleSpecificsList);
        counterpartyManagementService.cancel(counterpartyManagement);
        return ResponseEntity.ok(out);
    }
}
