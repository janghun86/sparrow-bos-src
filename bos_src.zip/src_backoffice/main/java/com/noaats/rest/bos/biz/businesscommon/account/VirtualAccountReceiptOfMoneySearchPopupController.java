package com.noaats.rest.bos.biz.businesscommon.account;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/account/popup")
public class VirtualAccountReceiptOfMoneySearchPopupController extends BaseController {

    private final IVirtualAccountReceiptOfMoneySearchPopupService<VirtualAccountReceiptOfMoneySearchPopup> virtualAccountReceiptOfMoneySearchPopupService;

    @GetMapping
    public ResponseEntity<VirtualAccountReceiptOfMoneySearchPopupOut> inquiry(BaseRequest<VirtualAccountReceiptOfMoneySearchPopupIn> request) throws CustomException {
        VirtualAccountReceiptOfMoneySearchPopupIn in = request.getData();
        VirtualAccountReceiptOfMoneySearchPopupOut out = new VirtualAccountReceiptOfMoneySearchPopupOut();
        // convert
        VirtualAccountReceiptOfMoneySearchPopup virtualAccountReceiptOfMoneySearchPopup = convert(in.getVirtualAccountReceiptOfMoneySearchPopup());

        List<VirtualAccountReceiptOfMoneySearchPopup> resultList = virtualAccountReceiptOfMoneySearchPopupService.inquiry(virtualAccountReceiptOfMoneySearchPopup);
        out.setVirtualAccountReceiptOfMoneySearchPopupList(resultList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/generate")
    public ResponseEntity<VirtualAccountReceiptOfMoneySearchPopupOut> generateStmLnkNo(BaseRequest<VirtualAccountReceiptOfMoneySearchPopupIn> request) throws CustomException {
        VirtualAccountReceiptOfMoneySearchPopupIn in = request.getData();
        VirtualAccountReceiptOfMoneySearchPopupOut out = new VirtualAccountReceiptOfMoneySearchPopupOut();
        // convert
        List<VirtualAccountReceiptOfMoneySearchPopup> virtualAccountReceiptOfMoneySearchPopupList = convertList(in.getVirtualAccountReceiptOfMoneySearchPopupList());

        List<VirtualAccountReceiptOfMoneySearchPopup> resultList = virtualAccountReceiptOfMoneySearchPopupService.generateStmLnkNo(virtualAccountReceiptOfMoneySearchPopupList);
        out.setVirtualAccountReceiptOfMoneySearchPopupList(resultList);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    public ResponseEntity<VirtualAccountReceiptOfMoneySearchPopupOut> save(BaseRequest<VirtualAccountReceiptOfMoneySearchPopupIn> request) throws CustomException {
        VirtualAccountReceiptOfMoneySearchPopupIn in = request.getData();
        VirtualAccountReceiptOfMoneySearchPopupOut out = new VirtualAccountReceiptOfMoneySearchPopupOut();
        // convert
        List<VirtualAccountReceiptOfMoneySearchPopup> virtualAccountReceiptOfMoneySearchPopupList = convertList(in.getVirtualAccountReceiptOfMoneySearchPopupList());

        virtualAccountReceiptOfMoneySearchPopupService.save(virtualAccountReceiptOfMoneySearchPopupList);
        out.setVirtualAccountReceiptOfMoneySearchPopupList(virtualAccountReceiptOfMoneySearchPopupList);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    public ResponseEntity<VirtualAccountReceiptOfMoneySearchPopupOut> delete(BaseRequest<VirtualAccountReceiptOfMoneySearchPopupIn> request) throws CustomException {
        VirtualAccountReceiptOfMoneySearchPopupIn in = request.getData();
        VirtualAccountReceiptOfMoneySearchPopupOut out = new VirtualAccountReceiptOfMoneySearchPopupOut();
        // convert
        List<VirtualAccountReceiptOfMoneySearchPopup> virtualAccountReceiptOfMoneySearchPopupList = convertList(in.getVirtualAccountReceiptOfMoneySearchPopupList());

        virtualAccountReceiptOfMoneySearchPopupService.delete(virtualAccountReceiptOfMoneySearchPopupList);
        out.setVirtualAccountReceiptOfMoneySearchPopupList(virtualAccountReceiptOfMoneySearchPopupList);
        return ResponseEntity.ok(out);
    }
}
