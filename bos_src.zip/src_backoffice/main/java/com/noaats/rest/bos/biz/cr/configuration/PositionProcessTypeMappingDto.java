package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionProcessTypeMappingDto extends BaseDto {
    private String cshCrnYn;
    private String dfrRecvTc;
    private String ptPcsTpId;
    private String evlAreaId;
    private String istCd;
    private String acMngGrpId;
    private String qtyPcsTpTc;
    private String amtPcsTpId;
    private String prdGrpTc;
    private String evtTpId;
    private String funOfifTc;
    private String amtPcsTpNm;
    private String amtTp1Tc;
    private String ptInd1Tc;
    private String amtTp2Tc;
    private String ptInd2Tc;
    private String amtTp3Tc;
    private String ptInd3Tc;
    private String ptEvlPcdrId;
    private String dpdMpnTpId;
    private String dpdMpnTpNm;
    private String pnbDpdTpId;
    private String pnbPtPcsTpId;
    private String nnbDpdTpId;
    private String nnbPtPcsTpId;
    private String qtyAmtPcsTpNm;
    private String qtyAmtTp1Tc;
    private String qtyPtInd1Tc;
    private String qtyAmtTp2Tc;
    private String qtyPtInd2Tc;
    private String qtyAmtTp3Tc;
    private String qtyPtInd3Tc;
    private String pnbEvlAreaId;
    private String pnbAcMngGrpId;
    private String pnbQtyPcsTpTc;
    private String pnbAmtPcsTpId;
    private String pnbAmtPcsTpNm;
    private String pnbAmtTp1Tc;
    private String pnbPtInd1Tc;
    private String pnbAmtTp2Tc;
    private String pnbPtInd2Tc;
    private String nnbEvlAreaId;
    private String nnbAcMngGrpId;
    private String nnbQtyPcsTpTc;
    private String nnbAmtPcsTpId;
    private String nnbAmtPcsTpNm;
    private String nnbAmtTp1Tc;
    private String nnbPtInd1Tc;
    private String nnbAmtTp2Tc;
    private String nnbPtInd2Tc;
    private String nftDpdTpId;
    private String nftPtPcsTpId;
    private String plnOtfDpdTpId;
    private String plnOtfPtPcsTpId;
    private String nftEvlAreaId;
    private String nftAcMngGrpId;
    private String nftQtyPcsTpTc;
    private String nftAmtPcsTpId;
    private String nftAmtPcsTpNm;
    private String nftAmtTp1Tc;
    private String nftPtInd1Tc;
    private String nftAmtTp2Tc;
    private String nftPtInd2Tc;
    private String plnOtfEvlAreaId;
    private String plnOtfAcMngGrpId;
    private String plnOtfQtyPcsTpTc;
    private String plnOtfAmtPcsTpId;
    private String plnOtfAmtPcsTpNm;
    private String plnOtfAmtTp1Tc;
    private String plnOtfPtInd1Tc;
    private String plnOtfAmtTp2Tc;
    private String plnOtfPtInd2Tc;
    private String pnbAmtTp3Tc;
    private String pnbPtInd3Tc;
    private String nnbAmtTp3Tc;
    private String nnbPtInd3Tc;
    private String nftAmtTp3Tc;
    private String nftPtInd3Tc;
    private String plnOtfAmtTp3Tc;
    private String plnOtfPtInd3Tc;
    private String crPtPcsTpId;
    private String crPnbPtPcsTpId;
    private String crNnbPtPcsTpId;
    private String crNftPtPcsTpId;
    private String crPlnOtfPtPcsTpId;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionProcessTypeMapping.class;
    }
}
