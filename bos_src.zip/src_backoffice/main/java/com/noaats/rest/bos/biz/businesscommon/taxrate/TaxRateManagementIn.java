package com.noaats.rest.bos.biz.businesscommon.taxrate;

import com.noaats.lib.frk.mci.BaseMessage;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class TaxRateManagementIn extends BaseMessage {
    private TaxRateDto taxRate = new TaxRateDto();
    private List<TaxRateDto> taxRateList = new ArrayList<>();
}
