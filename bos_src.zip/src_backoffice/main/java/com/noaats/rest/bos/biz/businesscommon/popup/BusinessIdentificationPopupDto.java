package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class BusinessIdentificationPopupDto extends BaseDto {
    private String ptTlzGrpNm;
    private String ptTlzGrpId;
    private String acMngGrpId;
    private String delYn;
    private String fstEnrTrid;
    private String istCd;
    private String fstEnrUsid;
    private String fstEnrIp;
    private String lstChgIp;
    private String lstChgTrid;
    private String lstChgUsid;
    private String bizPrgStsTc;
    private String bizGrpCd;
    private String bizCls1Tc;
    private String bizCls2Tc;
    private String bizCls3Tc;
    private String cflAtrTc;
    private String bizSttDt;
    private String bizXrtDt;
    private String fndSttDt;
    private String fndXrtDt;
    private String fndIvSttDt;
    private String fndIvXrtDt;
    private String bfdBseIvCurCd;
    private Double bfdBseIvAmt;
    private Double bfdBseNwIvAmt;
    private Double bfdBseReIvAmt;
    private Double bfdBseIrrRor;
    private String bfdBseIrrRorCts;
    private String bizTrmtDt;
    private String bizTrmtUsid;
    private Integer vrs;
    private String prjTgtYn;
    private String prjId;
    private String hbrdTc;
    private String ivAreTc;
    private String ivAtrTc;
    private String ivFml1Tc;
    private String ivFml2Tc;
    private String moAno;
    private String hdgSgcTc;
    private Long rndCptyNo;
    private String vaNo;
    private String vaNm;
    private String piAnlTrmtDt;
    private String piAnlTrmtUsid;

    @JsonIgnore
    public Class getBusinessClass() {
        return BusinessIdentificationPopup.class;
    }
}
