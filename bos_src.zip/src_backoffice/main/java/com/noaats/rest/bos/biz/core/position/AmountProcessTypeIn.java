package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.AmountProcessTypeCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AmountProcessTypeIn extends BaseMessage {
    private AmountProcessTypeCatalogueDto amountProcessTypeCatalogue = new AmountProcessTypeCatalogueDto();
}
