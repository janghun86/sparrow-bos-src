package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.position.business.UnitPriceCalculateDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UnitPriceCalculateProcessDto extends UnitPriceCalculateDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return UnitPriceCalculateProcess.class;
    }
}
