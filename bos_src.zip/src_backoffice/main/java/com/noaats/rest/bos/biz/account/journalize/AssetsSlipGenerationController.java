package com.noaats.rest.bos.biz.account.journalize;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/account/journalize")
public class AssetsSlipGenerationController extends BaseController {

    private final IAssetsSlipGenerationStandardService<AssetsSlipGeneration> assetsSlipGenerationStandardService;

    @GetMapping("/generate")
    public ResponseEntity<AssetsSlipGenerationOut> inquiryGenerateSlip(@RequestBody BaseRequest<AssetsSlipGenerationIn> request) throws CustomException {
        AssetsSlipGenerationIn in = request.getData();
        AssetsSlipGenerationOut out = new AssetsSlipGenerationOut();
        // convert
        AssetsSlipGeneration assetsSlipGeneration = convert(in.getAssetsSlipGeneration());

        AssetsSlipGeneration result = assetsSlipGenerationStandardService.inquiryGenerateSlip(assetsSlipGeneration);
        out.setAssetsSlipGenerationList(result.getAssetsSlipGenerationList());
        out.setAssetsSlipGenerationForPaging(result.getAssetsSlipGenerationForPaging());
        return ResponseEntity.ok(out);
    }

    @GetMapping("/confirm")
    public ResponseEntity<AssetsSlipGenerationOut> inquiryConfirmSlip(@RequestBody BaseRequest<AssetsSlipGenerationIn> request) throws CustomException {
        AssetsSlipGenerationIn in = request.getData();
        AssetsSlipGenerationOut out = new AssetsSlipGenerationOut();
        // convert
        AssetsSlipGeneration assetsSlipGeneration = convert(in.getAssetsSlipGeneration());

        AssetsSlipGeneration result = assetsSlipGenerationStandardService.inquiryConfirmSlip(assetsSlipGeneration);
        out.setAssetsSlipGenerationList(result.getAssetsSlipGenerationList());
        return ResponseEntity.ok(out);
    }

    @GetMapping("/merge")
    public ResponseEntity<AssetsSlipGenerationOut> mergeSlipData(@RequestBody BaseRequest<AssetsSlipGenerationIn> request) throws CustomException {
        AssetsSlipGenerationIn in = request.getData();
        AssetsSlipGenerationOut out = new AssetsSlipGenerationOut();
        // convert
        List<AssetsSlipGeneration> assetsSlipGenerationList = convertList(in.getAssetsSlipGenerationList());

        List<AssetsSlipGeneration> resultList = assetsSlipGenerationStandardService.mergeSlipData(assetsSlipGenerationList);
        out.setAssetsSlipGenerationByMerge(resultList);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<AssetsSlipGenerationOut> save(@RequestBody BaseRequest<AssetsSlipGenerationIn> request) throws CustomException {
        AssetsSlipGenerationIn in = request.getData();
        AssetsSlipGenerationOut out = new AssetsSlipGenerationOut();
        // convert
        List<AssetsSlipGeneration> assetsSlipGenerationList = convertList(in.getAssetsSlipGenerationList());

        assetsSlipGenerationStandardService.save(assetsSlipGenerationList);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<AssetsSlipGenerationOut> cancel(@RequestBody BaseRequest<AssetsSlipGenerationIn> request) throws CustomException {
        AssetsSlipGenerationIn in = request.getData();
        AssetsSlipGenerationOut out = new AssetsSlipGenerationOut();
        // convert
        List<AssetsSlipGeneration> assetsSlipGenerationList = convertList(in.getAssetsSlipGenerationList());

        assetsSlipGenerationStandardService.cancel(assetsSlipGenerationList);
        return ResponseEntity.ok(out);
    }
}
