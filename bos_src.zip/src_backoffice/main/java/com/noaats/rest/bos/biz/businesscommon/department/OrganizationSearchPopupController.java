package com.noaats.rest.bos.biz.businesscommon.department;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/department/popup")
public class OrganizationSearchPopupController extends BaseController {

    private final IOrganizationSearchPopupService<OrganizationSearchPopup> organizationSearchPopupService;

    @GetMapping
    public ResponseEntity<OrganizationSearchPopupOut> inquiry(@RequestBody BaseRequest<OrganizationSearchPopupIn> request) throws CustomException {
        OrganizationSearchPopupIn in = request.getData();
        OrganizationSearchPopupOut out = new OrganizationSearchPopupOut();
        // convert
        OrganizationSearchPopup organizationSearchPopup = convert(in.getOrganizationSearchPopup());

        out.setOrganizationSearchPopup(organizationSearchPopupService.inquiry(organizationSearchPopup));
        return ResponseEntity.ok(out);
    }
}
