package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.EvaluationTypeCatalogue;
import com.noaats.rest.bos.biz.cr.IEvaluationTypeCatalogueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/holding-purpose")
public class HoldingPurposeController extends BaseController {

    private final IHoldingPurposeService<HoldingPurpose> holdingPurposeService;

    private final IEvaluationTypeCatalogueService evaluationTypeCatalogueService;

    @GetMapping
    public ResponseEntity<HoldingPurposeOut> getHoldingPurpose(@RequestBody BaseRequest<HoldingPurposeIn> request) throws CustomException {
        HoldingPurposeIn in = request.getData();
        HoldingPurposeOut out = new HoldingPurposeOut();

        HoldingPurpose holdingPurpose = convert(in.getHoldingPurpose());

        List<HoldingPurpose> evaluationTypeCatalogueList = holdingPurposeService.getHoldingPurpose(holdingPurpose);
        out.setHoldingPurposeList(evaluationTypeCatalogueList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/evl-tp-ctl")
    public ResponseEntity<HoldingPurposeOut> findUseAll(@RequestBody BaseRequest<HoldingPurposeIn> request) throws CustomException {
        HoldingPurposeIn in = request.getData();
        HoldingPurposeOut out = new HoldingPurposeOut();

        EvaluationTypeCatalogue evaluationTypeCatalogue = convert(in.getEvaluationTypeCatalogue());

        List<EvaluationTypeCatalogue> evaluationTypeCatalogueList = evaluationTypeCatalogueService.findUseAll(evaluationTypeCatalogue);
        out.setEvaluationTypeCatalogueList(evaluationTypeCatalogueList);
        return ResponseEntity.ok(out);
    }
}
