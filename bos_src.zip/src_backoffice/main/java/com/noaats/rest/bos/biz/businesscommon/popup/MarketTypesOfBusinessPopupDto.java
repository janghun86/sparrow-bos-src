package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MarketTypesOfBusinessPopupDto extends BaseDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return MarketTypesOfBusinessPopup.class;
    }
}
