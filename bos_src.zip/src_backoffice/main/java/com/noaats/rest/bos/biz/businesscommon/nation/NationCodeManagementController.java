package com.noaats.rest.bos.biz.businesscommon.nation;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.co.NationCodeCatalogue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/nation/management")
public class NationCodeManagementController extends BaseController {

    private final INationCodeManagementService<NationCodeManagement> nationCodeManagementService;

    @GetMapping
    public ResponseEntity<NationCodeManagementOut> inquiry(@RequestBody BaseRequest<NationCodeManagementIn> request) throws CustomException {
        NationCodeManagementIn in = request.getData();
        NationCodeManagementOut out = new NationCodeManagementOut();
        NationCodeManagement nationCodeManagement = new NationCodeManagement();
        // convert
        NationCodeCatalogue nationCodeCatalogue = convert(in.getNationCodeCatalogue());

        nationCodeManagement.setNationCodeCatalogue(nationCodeCatalogue);
        nationCodeManagement = nationCodeManagementService.inquiry(nationCodeManagement);
        out.setNationCodeCatalogueList(nationCodeManagement.getNationCodeCatalogueList());
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<NationCodeManagementOut> registration(@RequestBody BaseRequest<NationCodeManagementIn> request) throws CustomException {
        NationCodeManagementIn in = request.getData();
        NationCodeManagementOut out = new NationCodeManagementOut();
        NationCodeManagement nationCodeManagement = new NationCodeManagement();
        // convert
        NationCodeCatalogue nationCodeCatalogue = convert(in.getNationCodeCatalogue());

        nationCodeManagement.setNationCodeCatalogue(nationCodeCatalogue);
        nationCodeManagementService.registration(nationCodeManagement);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<NationCodeManagementOut> cancel(@RequestBody BaseRequest<NationCodeManagementIn> request) throws CustomException {
        NationCodeManagementIn in = request.getData();
        NationCodeManagementOut out = new NationCodeManagementOut();
        NationCodeManagement nationCodeManagement = new NationCodeManagement();
        // convert
        NationCodeCatalogue nationCodeCatalogue = convert(in.getNationCodeCatalogue());

        nationCodeManagement.setNationCodeCatalogue(nationCodeCatalogue);
        nationCodeManagementService.cancel(nationCodeManagement);
        return ResponseEntity.ok(out);
    }
}
