package com.noaats.rest.bos.biz.abc.taskmanagement;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/abc/taskmanagement/service")
public class ServiceFunctionManagementController extends BaseController {

    private final IServiceFunctionManagementService<ServiceFunctionManagement> serviceFunctionManagementService;

    @GetMapping
    public ResponseEntity<ServiceFunctionManagementOut> inquiry(@RequestBody BaseRequest<ServiceFunctionManagementIn> request) throws CustomException {
        log.debug("=========ServiceFunctionManagementController.inquiry Start================");
        ServiceFunctionManagementIn in = request.getData();
        ServiceFunctionManagementOut out = new ServiceFunctionManagementOut();
        // convert
        ServiceFunctionManagement serviceFunctionManagement = convert(in.getServiceFunctionManagement());

        List<ServiceFunctionManagement> result = serviceFunctionManagementService.list(serviceFunctionManagement);
        out.setServiceFunctionList(result);
        return ResponseEntity.ok(out);
    }
}
