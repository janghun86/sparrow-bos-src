package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllowanceForBadDebtsSettingUpTargetBaseSpecificsDto extends BaseDto {
    private String ijrModlTc;
    private String evlAreaId;
    private String acMngGrpId;
    private String prdTpId;
    private String evlTpId;
    private String acEvlTpId;
    private String pofId;
    private String ptTlzGrpId;
    private Integer vrs;

    @JsonIgnore
    public Class getBusinessClass() {
        return AllowanceForBadDebtsSettingUpTargetBaseSpecifics.class;
    }
}
