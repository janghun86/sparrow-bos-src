package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationGroupAssistanceBusinessGradeSpecificsDto extends BaseDto {
    private String ptTlzGrpId;
    private String bizGrAplyDt;
    private Integer vrs;
    private String bizGrTc;
    private String bizGrEnrUsid;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionTotalizationGroupAssistanceBusinessGradeSpecifics.class;
    }
}
