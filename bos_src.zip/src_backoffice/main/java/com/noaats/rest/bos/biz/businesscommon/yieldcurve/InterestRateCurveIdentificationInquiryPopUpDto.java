package com.noaats.rest.bos.biz.businesscommon.yieldcurve;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InterestRateCurveIdentificationInquiryPopUpDto extends BaseDto {
    private String irtCurvId;
    private String irtCurvNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return InterestRateCurveIdentificationInquiryPopUp.class;
    }
}
