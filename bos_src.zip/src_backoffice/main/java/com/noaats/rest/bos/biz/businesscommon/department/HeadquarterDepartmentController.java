package com.noaats.rest.bos.biz.businesscommon.department;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/department/headquarter")
public class HeadquarterDepartmentController extends BaseController {

    private final IHeadquarterDepartmentService<HeadquarterDepartment> headquarterDepartmentService;

    @GetMapping("/dpmCd")
    public ResponseEntity<HeadquarterDepartmentOut> getDpmCd(@RequestBody BaseRequest<HeadquarterDepartmentIn> request) throws CustomException {
        HeadquarterDepartmentIn in = request.getData();
        HeadquarterDepartmentOut out = new HeadquarterDepartmentOut();
        // 본부코드 조회
        out.setHeadquarterDepartmentList(headquarterDepartmentService.getDpmCd(new HeadquarterDepartment()));
        return ResponseEntity.ok(out);
    }

    @GetMapping("/temCd")
    public ResponseEntity<HeadquarterDepartmentOut> getTemCd(@RequestBody BaseRequest<HeadquarterDepartmentIn> request) throws CustomException {
        HeadquarterDepartmentIn in = request.getData();
        HeadquarterDepartmentOut out = new HeadquarterDepartmentOut();
        //convert
        HeadquarterDepartment headquarterDepartment = convert(in.getHeadquarterDepartment());

        // 팀코드 조회
        out.setHeadquarterDepartmentList(headquarterDepartmentService.getTemCd(headquarterDepartment));
        return ResponseEntity.ok(out);
    }
}
