package com.noaats.rest.bos.biz.businesscommon.amount;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class AmountMappingInformationManagementDto extends BaseDto {
    private Integer totalCount;
    private Integer totalPage;
    private Integer currentPage;
    private Integer pageSize;
    private boolean pagingEnable;
    private String istCd;
    private String pofTlzFntTc;
    private String ptPcsTpId;
    private String pofAmtTc;
    private String netPtPcsTpId;
    private String rmk;
    private String delYn;
    private String fstEnrUsid;
    private String fstEnrTrid;
    private String fstEnrIp;
    private String lstChgUsid;
    private String lstChgTrid;
    private String lstChgIp;
    private Integer code;

    @JsonIgnore
    public Class getBusinessClass() {
        return AmountMappingInformationManagement.class;
    }
}
