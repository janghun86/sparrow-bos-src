package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.ManagementInformationChangeSpecifics;
import com.noaats.rest.bos.biz.cr.position.PositionTotalization;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 *
 * description : 포지션 집계 조회
 *
 *
 * </pre>
 *
 * @author : 정유진
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일              수정자       수정내용
 * ----------------------------------------------
 * 2018. 12. 13.	   정유진		최초생성
 *
 * </pre>
 * @version :
 * @date : 2018. 12. 13. 오후 2:00:53
 */

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/totalization")
public class PositionTotalizationController extends BaseController {
    private final IPositionTotalizationSearchService<PositionTotalization> positionTotalizationSearchService;

    private final IPositionTotalizationManagementService<PositionTotalization> positionTotalizationManagementService;

    @GetMapping("/view")
    public ResponseEntity<PositionTotalizationOut> inquiryByView(@RequestBody BaseRequest<PositionTotalizationIn> request) throws CustomException {
        PositionTotalizationIn in = request.getData();
        PositionTotalizationOut out = new PositionTotalizationOut();
        List<PositionTotalizationSearch> positionTotalizationSearchList = new ArrayList<>();
        // convert
        PositionTotalization positionTotalization = convert(in.getPositionTotalization());

        positionTotalizationSearchList.addAll(positionTotalizationSearchService.inquiryByView(positionTotalization));
        out.setPositionTotalizationSearchList(positionTotalizationSearchList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/table")
    public ResponseEntity<PositionTotalizationOut> inquiryByTable(@RequestBody BaseRequest<PositionTotalizationIn> request) throws CustomException {
        PositionTotalizationIn in = request.getData();
        PositionTotalizationOut out = new PositionTotalizationOut();
        List<PositionTotalizationSearch> positionTotalizationSearchList = new ArrayList<>();
        // convert
        PositionTotalization positionTotalization = convert(in.getPositionTotalization());

        positionTotalizationSearchList.addAll(positionTotalizationSearchService.inquiryByTable(positionTotalization));
        out.setPositionTotalizationSearchList(positionTotalizationSearchList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/mng-inf-chg")
    public ResponseEntity<PositionTotalizationOut> inquiryManagementInformationChange(@RequestBody BaseRequest<PositionTotalizationIn> request) throws CustomException {
        PositionTotalizationIn in = request.getData();
        PositionTotalizationOut out = new PositionTotalizationOut();
        // convert
        PositionTotalization positionTotalization = convert(in.getPositionTotalization());

        ManagementInformationChangeSpecifics managementInformationChangeSpecifics = positionTotalizationSearchService.inquiryManagementInformationChange(positionTotalization);
        out.setManagementInformationChangeSpecifics(managementInformationChangeSpecifics);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<PositionTotalizationOut> registration(@RequestBody BaseRequest<PositionTotalizationIn> request) throws CustomException {
        PositionTotalizationIn in = request.getData();
        PositionTotalizationOut out = new PositionTotalizationOut();
        // convert
        PositionTotalization positionTotalization = convert(in.getPositionTotalization());

        positionTotalizationManagementService.regenerate((PositionTotalization) positionTotalization);
        return ResponseEntity.ok(out);
    }
}
