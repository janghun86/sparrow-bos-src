package com.noaats.rest.bos.biz.account.journalize;

import com.noaats.lib.frk.mci.BaseMessage;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class AssetsSlipGenerationIn extends BaseMessage {
    private AssetsSlipGenerationDto assetsSlipGeneration = new AssetsSlipGenerationDto();
    private List<AssetsSlipGenerationDto> assetsSlipGenerationList = new ArrayList<>();
}
