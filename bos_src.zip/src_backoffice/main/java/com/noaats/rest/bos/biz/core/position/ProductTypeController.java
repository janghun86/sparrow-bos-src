package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.configuration.IProductTypeService;
import com.noaats.rest.bos.biz.cr.configuration.ProductType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/product-type")
public class ProductTypeController extends BaseController {

    private final IProductTypeService productTypeService;

    @GetMapping
    public ResponseEntity<ProductTypeOut> getProductType(@RequestBody BaseRequest<ProductTypeIn> request) throws CustomException {
        ProductTypeIn in = request.getData();
        ProductTypeOut out = new ProductTypeOut();

        ProductType productType = convert(in.getProductType());

        List<ProductType> productTypeList = productTypeService.getProductType(productType);
        out.setProductTypeList(productTypeList);
        return ResponseEntity.ok(out);
    }
}
