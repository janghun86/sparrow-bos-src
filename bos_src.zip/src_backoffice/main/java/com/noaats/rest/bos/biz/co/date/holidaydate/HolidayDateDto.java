package com.noaats.rest.bos.biz.co.date.holidaydate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HolidayDateDto extends BaseDto {
    private String hddCdDesCts;
    private String isoCd;
    private String istCd;
    private String hddCd;
    private String hddDt;
    private String hddNm;
    private String bsdTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return HolidayDate.class;
    }
}
