package com.noaats.rest.bos.biz.core.position;

import com.noaats.rest.bos.biz.cr.FinanceProductClassificationMappingSpecifics;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class FinanceProductClassificationOut {
    private List<FinanceProductClassificationMappingSpecifics> financeProductClassificationMappingSpecificsList;
}
