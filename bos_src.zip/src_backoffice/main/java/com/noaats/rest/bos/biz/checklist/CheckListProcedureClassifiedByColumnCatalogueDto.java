package com.noaats.rest.bos.biz.checklist;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import com.noaats.rest.bos.biz.co.checklist.CheckListProcedureClassifiedByColumnCatalogue;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckListProcedureClassifiedByColumnCatalogueDto extends BaseDto {

    private String cklId;

    private String cklPcdrId;

    private String colId;

    private Integer vrs;

    private String colNm;

    private String colAtrTc;

    private String chcHdnId;

    @JsonIgnore
    public Class getBusinessClass() {
        return CheckListProcedureClassifiedByColumnCatalogue.class;
    }
}
