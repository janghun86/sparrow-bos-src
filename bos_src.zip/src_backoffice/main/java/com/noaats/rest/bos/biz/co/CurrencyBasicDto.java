package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CurrencyBasicDto extends BaseDto {
    private String curCd;
    private Integer vrs;
    private String curNm;
    private String curEnlNm;
    private String mnCurYn;
    private String useYn;
    private String curPubIsoNtnCd;
    private Long xcrBltnUntNbr;
    private String curBltnTc;
    private Integer curIdcRkg;
    private Integer bokRprCurIdcRkg;
    private String curIdcSym;
    private Integer dmpCphrNbr;
    private String rdofTc;
    private String hddCd;
    private Integer tzon;

    @JsonIgnore
    public Class getBusinessClass() {
        return CurrencyBasic.class;
    }
}
