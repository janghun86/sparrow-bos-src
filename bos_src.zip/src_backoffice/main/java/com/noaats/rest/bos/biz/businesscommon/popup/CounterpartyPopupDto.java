package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.co.CounterpartyBasicDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CounterpartyPopupDto extends CounterpartyBasicDto {
    private String cptyRolTc;
    private String rowId;
    private String brn;
    private String crno;
    private String aflTc;
    private String stnIdsClsCd;
    private String eprSclTc;
    private String kscPubIstCd;
    private String lkgSysCptyNo;
    private String encoCd;
    private String amcoCd;

    @JsonIgnore
    public Class getBusinessClass() {
        return CounterpartyPopup.class;
    }
}
