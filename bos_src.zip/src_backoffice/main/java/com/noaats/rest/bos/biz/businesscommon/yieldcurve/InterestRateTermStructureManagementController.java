package com.noaats.rest.bos.biz.businesscommon.yieldcurve;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/yieldcurve/interestRate-Term-Structure-management")
public class InterestRateTermStructureManagementController extends BaseController {

    private final IInterestRateTermStructureManagementService<InterestRateTermStructureManagement> interestRateTermStructureManagementService;

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<InterestRateTermStructureManagementOut> registration(@RequestBody BaseRequest<InterestRateTermStructureManagementIn> request) throws CustomException {
        InterestRateTermStructureManagementIn in = request.getData();
        InterestRateTermStructureManagementOut out = new InterestRateTermStructureManagementOut();
        interestRateTermStructureManagementService.modify(convertList(in.getInterestRateTermStructureManagementList()));
        return ResponseEntity.ok(out);
    }

    @GetMapping
    public ResponseEntity<InterestRateTermStructureManagementOut> inquiry(@RequestBody BaseRequest<InterestRateTermStructureManagementIn> request) throws CustomException {
        InterestRateTermStructureManagementIn in = request.getData();
        InterestRateTermStructureManagementOut out = new InterestRateTermStructureManagementOut();
        out.setInterestRateTermStructureManagementList(interestRateTermStructureManagementService.inquiry(convert(in.getInterestRateTermStructureManagement())));
        return ResponseEntity.ok(out);
    }
}
