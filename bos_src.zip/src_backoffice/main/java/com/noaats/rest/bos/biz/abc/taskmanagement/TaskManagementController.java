package com.noaats.rest.bos.biz.abc.taskmanagement;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.tr.TaskBasic;
import com.noaats.rest.bos.biz.tr.TaskServiceMappingSpecifics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/abc/taskmanagement")
public class TaskManagementController extends BaseController {

    private final ITaskManagementService<TaskManagement> taskManagementService;

    @GetMapping
    public ResponseEntity<TaskManagementOut> inquiry(@RequestBody BaseRequest<TaskManagementIn> request) throws CustomException {

        log.debug("=========TaskManagementController.inquiry Start================");
        TaskManagementIn in = request.getData();
        TaskManagementOut out = new TaskManagementOut();
        // convert
        TaskManagement taskManagement = convert(in.getTaskManagement());
        TaskBasic taskBasic = convert(in.getTaskBasic());

        taskManagement.setTaskBasic(taskBasic);
        TaskManagement result = taskManagementService.inquiry(taskManagement);
        out.setTaskBasic(result.getTaskBasic());
        out.setServiceList(result.getServiceList());
        out.setKeyWordList(result.getKeyWordList());
        return ResponseEntity.ok(out);
    }

    @GetMapping("/tree")
    public ResponseEntity<TaskManagementOut> inquiryTree(@RequestBody BaseRequest<TaskManagementIn> request) throws CustomException {
        // 전체 트리 구조 조회
        log.debug("=========TaskManagementController.inquiryTree Start================");
        TaskManagementIn in = request.getData();
        TaskManagementOut out = new TaskManagementOut();
        // convert
        TaskManagement taskManagement = convert(in.getTaskManagement());

        List<TaskManagement> resultList = taskManagementService.list(taskManagement);
        out.setTaskTree(resultList.get(0).getTaskTree());
//        systemMessageService.setReadMsgCd(taskOut.getTaskTree(), requestHeader);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/my-task")
    public ResponseEntity<TaskManagementOut> inquiryMyTask(@RequestBody BaseRequest<TaskManagementIn> request) throws CustomException {
        // 나의 태스크 트리 구조 조회
        log.debug("=========TaskManagementController.inquiryMyTask Start================");
        TaskManagementIn in = request.getData();
        TaskManagementOut out = new TaskManagementOut();
        // convert
        TaskManagement taskManagement = convert(in.getTaskManagement());

        TaskManagement result = taskManagementService.listMyTask(taskManagement);
        out.setTaskTree(result.getTaskTree());
//        systemMessageService.setReadMsgCd(taskOut.getTaskTree(), requestHeader);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/team-task")
    public ResponseEntity<TaskManagementOut> inquiryTeamTask(@RequestBody BaseRequest<TaskManagementIn> request) throws CustomException {
        // 팀 태스크 트리 구조 조회
        log.debug("=========TaskManagementController.inquiryMyTask Start================");
        TaskManagementIn in = request.getData();
        TaskManagementOut out = new TaskManagementOut();
        // convert
        TaskManagement taskManagement = convert(in.getTaskManagement());

        TaskManagement result = taskManagementService.listTeamTask(taskManagement);
        out.setTaskTree(result.getTaskTree());
//        systemMessageService.setReadMsgCd(taskOut.getTaskTree(), requestHeader);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TaskManagementOut> registration(@RequestBody BaseRequest<TaskManagementIn> request) throws CustomException {
        // 신규
        log.debug("=========TaskManagementController.registration Start================");
        TaskManagementIn in = request.getData();
        TaskManagementOut out = new TaskManagementOut();
        // convert
        TaskManagement taskManagement = convert(in.getTaskManagement());
        TaskBasic taskBasic = convert(in.getTaskBasic());
        List<TaskServiceMappingSpecifics> serviceMappingList = convertList(in.getServiceMappingList());

        taskManagement.setTaskBasic(taskBasic);
        taskManagement.setServiceMappingList(serviceMappingList);
        TaskManagement result = taskManagementService.registration(taskManagement);
        out.setTaskTree(result.getTaskTree());
        return ResponseEntity.ok(out);
    }

    @PostMapping("/copy-task")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TaskManagementOut> copyTask(@RequestBody BaseRequest<TaskManagementIn> request) throws CustomException {
        // 복제
        log.debug("=========TaskManagementController.copyTask Start================");
        TaskManagementIn in = request.getData();
        TaskManagementOut out = new TaskManagementOut();
        // convert
        TaskManagement taskManagement = convert(in.getTaskManagement());
        TaskBasic taskBasic = convert(in.getTaskBasic());
        List<TaskServiceMappingSpecifics> serviceMappingList = convertList(in.getServiceMappingList());

        taskManagement.setTaskBasic(taskBasic);
        taskManagement.setServiceMappingList(serviceMappingList);
        TaskManagement result = taskManagementService.copyTask(taskManagement);
        out.setTaskTree(result.getTaskTree());
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TaskManagementOut> modify(@RequestBody BaseRequest<TaskManagementIn> request) throws CustomException {
        // 복제
        log.debug("=========TaskManagementController.modify Start================");
        TaskManagementIn in = request.getData();
        TaskManagementOut out = new TaskManagementOut();
        // convert
        TaskManagement taskManagement = convert(in.getTaskManagement());
        TaskBasic taskBasic = convert(in.getTaskBasic());
        List<TaskServiceMappingSpecifics> serviceMappingList = convertList(in.getServiceMappingList());

        taskManagement.setTaskBasic(taskBasic);
        taskManagement.setServiceMappingList(serviceMappingList);
        TaskManagement modelReturn = taskManagementService.update(taskManagement);
        out.setTaskTree(modelReturn.getTaskTree());
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TaskManagementOut> delete(@RequestBody BaseRequest<TaskManagementIn> request) throws CustomException {

        log.debug("=========TaskManagementController.delete Start================");
        TaskManagementIn in = request.getData();
        TaskManagementOut out = new TaskManagementOut();
        // convert
        TaskManagement taskManagement = convert(in.getTaskManagement());
        TaskBasic taskBasic = convert(in.getTaskBasic());

        taskManagement.setTaskBasic(taskBasic);
        taskManagementService.delete(taskManagement);
        return ResponseEntity.ok(out);
    }
}
