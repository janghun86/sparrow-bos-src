package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EventClassificationCatalogueDto extends BaseDto {
    private String evtGrpTc;
    private String evtClsId;
    private String evtClsNm;
    private String flwClsUseYn;
    private String cndClsUseYn;
    private String calClsId;

    @JsonIgnore
    public Class getBusinessClass() {
        return EventClassificationCatalogue.class;
    }
}
