package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AgreementInjuryDetailsSpecificsDto extends BaseDto {
    private String agrId;
    private Long sqn;
    private String agrVltMatTc;
    private String agrVltDt;
    private Integer vrs;
    private String agrVltDtls;

    @JsonIgnore
    public Class getBusinessClass() {
        return AgreementInjuryDetailsSpecifics.class;
    }
}
