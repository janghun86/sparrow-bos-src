package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionEvaluationProcedureMappingDto extends BaseDto {
    private String acMngGrpId;
    private String ptEvlPcdrId;
    private String acPcsIdfrId;
    private String evlAreaId;
    private String acEvlTpId;
    private String prdClsId;
    private String prdTpId;
    private String trTpId;
    private String pofId;
    private String ptTlzGrpId;
    private String ptTlzId;
    private String evlGrpId;
    private String evlTpId;
    private String evlCurCd;
    private String ptClsUntId;
    private String bkgCttYn;
    private String ptClsCnd5Tc;
    private String ptClsCnd4Tc;
    private String ptClsCnd3Tc;
    private String ptClsCnd2Tc;
    private String ptClsCnd1Tc;
    private String ptBseDt;
    private String ptEvlPcdrNm;
    private String ptEvlTc;
    private String ptChgEffTc;
    private String astDbtPtTc;
    private String ociYn;
    private String bseEvlAreaYn;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionEvaluationProcedureMapping.class;
    }
}
