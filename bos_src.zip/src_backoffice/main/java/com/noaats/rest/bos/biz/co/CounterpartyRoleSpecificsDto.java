package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CounterpartyRoleSpecificsDto extends BaseDto {
    private Long cptyNo;
    private String cptyRolTc;
    private Integer vrs;
    private String rmk;

    @JsonIgnore
    public Class getBusinessClass() {
        return CounterpartyRoleSpecifics.class;
    }
}
