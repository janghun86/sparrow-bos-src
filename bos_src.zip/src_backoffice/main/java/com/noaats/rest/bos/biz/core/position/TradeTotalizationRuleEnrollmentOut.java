package com.noaats.rest.bos.biz.core.position;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class TradeTotalizationRuleEnrollmentOut {
    private List<TradeTotalizationRuleEnrollment> tradeTypeCatalogueList;
    private List<TradeTotalizationRuleEnrollment> tradeTypeMappingSpecificsList;
    private List<TradeTotalizationRuleEnrollment> columnCatalogueList;
    private List<TradeTotalizationRuleEnrollment> columnMappingSpecificsList;
    private List<TradeTotalizationRuleEnrollment> accountsSymbolMappingSpecificsList;
}
