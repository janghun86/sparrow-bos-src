package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EventTypeCatalogueDto extends BaseDto {
    private String prdGrpTc;
    private String evtTpId;
    private String evtTpNm;
    private String evtGrpTc;
    private String evtClsId;
    private String cshCrnYn;
    private String tctCrnYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return EventTypeCatalogue.class;
    }
}
