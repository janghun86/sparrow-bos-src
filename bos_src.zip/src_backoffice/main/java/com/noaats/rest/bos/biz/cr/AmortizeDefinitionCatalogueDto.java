package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AmortizeDefinitionCatalogueDto extends BaseDto {
    private String evlStgTc;
    private String evlPcsId;
    private String evlPcsNm;
    private String amrPcsMthTc;
    private String eirPcsMthTc;
    private String rsuYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return AmortizeDefinitionCatalogue.class;
    }
}
