package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/integration-setting-up-management")
public class IntegrationSettingUpInformationManagementController extends BaseController {

    private final IIntegrationSettingUpInformationManagementService<IntegrationSettingUpInformationManagement> integrationSettingUpInformationManagementService;

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<IntegrationSettingUpInformationManagementOut> save(@RequestBody BaseRequest<IntegrationSettingUpInformationManagementIn> request) throws CustomException {
        IntegrationSettingUpInformationManagementIn in = request.getData();
        IntegrationSettingUpInformationManagementOut out = new IntegrationSettingUpInformationManagementOut();

        List<IntegrationSettingUpInformationManagement> integrationSettingUpInformationManagementList = convertList(in.getIntegrationSettingUpInformationManagementList());

        integrationSettingUpInformationManagementService.save(integrationSettingUpInformationManagementList);
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<IntegrationSettingUpInformationManagementOut> update(@RequestBody BaseRequest<IntegrationSettingUpInformationManagementIn> request) throws CustomException {
        IntegrationSettingUpInformationManagementIn in = request.getData();
        IntegrationSettingUpInformationManagementOut out = new IntegrationSettingUpInformationManagementOut();

        List<IntegrationSettingUpInformationManagement> integrationSettingUpInformationManagementList = convertList(in.getIntegrationSettingUpInformationManagementList());

        integrationSettingUpInformationManagementService.update(integrationSettingUpInformationManagementList);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<IntegrationSettingUpInformationManagementOut> delete(@RequestBody BaseRequest<IntegrationSettingUpInformationManagementIn> request) throws CustomException {
        IntegrationSettingUpInformationManagementIn in = request.getData();
        IntegrationSettingUpInformationManagementOut out = new IntegrationSettingUpInformationManagementOut();

        List<IntegrationSettingUpInformationManagement> integrationSettingUpInformationManagementList = convertList(in.getIntegrationSettingUpInformationManagementList());

        integrationSettingUpInformationManagementService.delete(integrationSettingUpInformationManagementList);
        return ResponseEntity.ok(out);
    }

    @GetMapping
    public ResponseEntity<IntegrationSettingUpInformationManagementOut> list(@RequestBody BaseRequest<IntegrationSettingUpInformationManagementIn> request) throws CustomException {
        IntegrationSettingUpInformationManagementIn in = request.getData();
        IntegrationSettingUpInformationManagementOut out = new IntegrationSettingUpInformationManagementOut();
        IntegrationSettingUpInformationManagement integrationSettingUpInformationManagement = integrationSettingUpInformationManagementService.list(convert(in.getIntegrationSettingUpInformationManagement()));
        out.setIntegrationSettingUpInformationClassificationList(integrationSettingUpInformationManagement.getIntegrationSettingUpInformationClassificationList());
        return ResponseEntity.ok(out);
    }
}
