package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class HolidayPopupDto extends BaseDto {
    private String isoCd;
    private String hddCdDesCts;
    private Integer vrs;
    private String hddCd;
    private String delYn;
    private String fstEnrTrid;
    private String istCd;
    private String fstEnrUsid;
    private String fstEnrIp;
    private String lstChgIp;
    private String lstChgTrid;
    private String lstChgUsid;

    @JsonIgnore
    public Class getBusinessClass() {
        return HolidayPopup.class;
    }
}
