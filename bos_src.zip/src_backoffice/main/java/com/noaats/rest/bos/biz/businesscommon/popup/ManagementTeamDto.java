package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ManagementTeamDto extends BaseDto {
    private String coCva;
    private String coCvaNm;
    private String coCvaCdNm;
    private String dpmCd;

    @JsonIgnore
    public Class getBusinessClass() {
        return ManagementTeam.class;
    }
}
