package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.AccountsSymbolCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountsSymbolIn extends BaseMessage {
    private AccountsSymbolCatalogueDto accountsSymbolCatalogue = new AccountsSymbolCatalogueDto();
}
