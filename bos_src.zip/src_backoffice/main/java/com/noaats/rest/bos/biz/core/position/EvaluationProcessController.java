/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.evaluation.EffectivenessInterestRateMethodAmortize;
import com.noaats.rest.bos.biz.cr.evaluation.EffectivenessInterestRateMethodAmortizeCalculation;
import com.noaats.rest.bos.biz.cr.evaluation.EffectivenessInterestRateMethodAmortizeCalculationDto;
import com.noaats.rest.bos.biz.cr.evaluation.EffectivenessInterestRateMethodAmortizeDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/evaluation-process")
public class EvaluationProcessController extends BaseController {

    private final IEvaluationProcessService<EvaluationProcess> evaluationProcessService;

    @GetMapping
    public ResponseEntity<EvaluationProcessOut> inquiry(@RequestBody BaseRequest<EvaluationProcessIn> request) throws CustomException {
        EvaluationProcessIn in = request.getData();
        EvaluationProcessOut out = new EvaluationProcessOut();



        List<EvaluationProcess> inquiryOut = evaluationProcessService.inquiry(convert(in.getEvaluationProcess()));
        if (!inquiryOut.isEmpty()) {

            out.setEvaluationProcessForPaging(inquiryOut.get(0));
            out.setEvaluationProcessList(inquiryOut);
            out.setEffectivenessInterestRateMethodAmortizeList(new ArrayList<EffectivenessInterestRateMethodAmortize> ());
            out.setEffectivenessInterestRateMethodAmortizeCalculationList(new ArrayList<EffectivenessInterestRateMethodAmortizeCalculation> ());

            for (EvaluationProcess evaluationProcess : inquiryOut) {
                if (evaluationProcess.getAmortizeEvaluation() != null) {
                    out.getEffectivenessInterestRateMethodAmortizeList().add(evaluationProcess.getAmortizeEvaluation().getEffectivenessInterestRateMethodAmortize());
                    out.getEffectivenessInterestRateMethodAmortizeCalculationList().addAll(evaluationProcess.getAmortizeEvaluation().getEffectivenessInterestRateMethodAmortizeCalculationList());
                }
            }
        }
        // TODO
        // 화면에서 올라오는 페이지 정보 처리
//            if(out.getEvaluationProcessForPaging() != null && out.getEvaluationProcessForPaging().getTotalPage() > out.getEvaluationProcessForPaging().getCurrentPage())
//            {
//                systemMessageService.setMsgCd("BIFW0032", requestHeader); // 조회가능한 내역이 남아있습니다.
//            }
//            else
//            {
//                systemMessageService.setReadMsgCd(out.getEvaluationProcessList(), requestHeader);
//            }
        return ResponseEntity.ok(out);
    }

    @GetMapping("/co-cd")
    public ResponseEntity<EvaluationProcessOut> searchCoCd(@RequestBody BaseRequest<EvaluationProcessIn> request) throws CustomException {
        EvaluationProcessIn in = request.getData();
        EvaluationProcessOut out = new EvaluationProcessOut();

        EvaluationProcess evaluationProcess = convert(in.getEvaluationProcess());

        EvaluationProcess inquiryOut = evaluationProcessService.inquiryCoCd(evaluationProcess);
        out.setAcEvlTpList(inquiryOut.getAcEvlTpList());
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<EvaluationProcessOut> registration(@RequestBody BaseRequest<EvaluationProcessIn> request) throws CustomException {
        EvaluationProcessIn in = request.getData();
        EvaluationProcessOut out = new EvaluationProcessOut();

        List<EvaluationProcess> evaluationProcessList = convertList(in.getEvaluationProcessList());
        List<EffectivenessInterestRateMethodAmortize> effectivenessInterestRateMethodAmortizeList = convertList(in.getEffectivenessInterestRateMethodAmortizeList());
        List<EffectivenessInterestRateMethodAmortizeCalculation> effectivenessInterestRateMethodAmortizeCalculationList = convertList(in.getEffectivenessInterestRateMethodAmortizeCalculationList());

        List<EvaluationProcess> saveOut = evaluationProcessService.save(evaluationProcessList, effectivenessInterestRateMethodAmortizeList, effectivenessInterestRateMethodAmortizeCalculationList);
        out.setEvaluationProcessList(saveOut);
        out.setEffectivenessInterestRateMethodAmortizeList(effectivenessInterestRateMethodAmortizeList);
        out.setEffectivenessInterestRateMethodAmortizeCalculationList(effectivenessInterestRateMethodAmortizeCalculationList);
//        systemMessageService.setMsgCd("BIFW0010", requestHeader); // 등록되었습니다.
        return ResponseEntity.ok(out);
    }




    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<EvaluationProcessOut> delete(@RequestBody BaseRequest<EvaluationProcessIn> request) throws CustomException {
        EvaluationProcessIn in = request.getData();
        EvaluationProcessOut out = new EvaluationProcessOut();

        List<EvaluationProcess> evaluationProcessList = convertList(in.getEvaluationProcessList());
        List<EffectivenessInterestRateMethodAmortize> effectivenessInterestRateMethodAmortizeList = convertList(in.getEffectivenessInterestRateMethodAmortizeList());
        List<EffectivenessInterestRateMethodAmortizeCalculation> effectivenessInterestRateMethodAmortizeCalculationList = convertList(in.getEffectivenessInterestRateMethodAmortizeCalculationList());

        List<EvaluationProcess> cancelOut = evaluationProcessService.cancel(evaluationProcessList, effectivenessInterestRateMethodAmortizeList, effectivenessInterestRateMethodAmortizeCalculationList);
        out.setEvaluationProcessList(cancelOut);
        out.setEffectivenessInterestRateMethodAmortizeList(effectivenessInterestRateMethodAmortizeList);
        out.setEffectivenessInterestRateMethodAmortizeCalculationList(effectivenessInterestRateMethodAmortizeCalculationList);
//        systemMessageService.setMsgCd("BIFW0012", requestHeader); // 취소되었습니다.
        return ResponseEntity.ok(out);
    }

}