/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <pre>
 *
 * description : 원천세 계산 Controller
 *
 * com.noaats.sol.controller.core.position
 *    WithholdingTaxCalculateProcessController.java
 *
 * </pre>
 *
 * @author : wook2647@noaats.com
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2020. 7. 29.	wook2647@noaats.com		최초생성
 *
 * </pre>
 * @version :
 * @date : 2020. 7. 29. 오후 1:45:14
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/withholding-tax")
public class WithholdingTaxCalculateProcessController extends BaseController {

    private final IWithholdingTaxCalculateProcessService<WithholdingTaxCalculateProcess> withholdingTaxCalculateProcessService;

    @GetMapping
    public ResponseEntity<WithholdingTaxCalculateProcessOut> inquiry(@RequestBody BaseRequest<WithholdingTaxCalculateProcessIn> request) throws CustomException {
        WithholdingTaxCalculateProcessIn in = request.getData();
        WithholdingTaxCalculateProcessOut out = new WithholdingTaxCalculateProcessOut();
        WithholdingTaxCalculateProcess inquiryOut = withholdingTaxCalculateProcessService.inquiry(convert(in.getWithholdingTaxCalculateProcess()));
        out.setWithholdingTaxCalculateProcess(inquiryOut);
        out.setListByCalEndDt(inquiryOut.getWithholdingTaxListByCalEndDt());
        out.setListByFstPrhDt(inquiryOut.getWithholdingTaxListByFstPrhDt());
        return ResponseEntity.ok(out);
    }
}
