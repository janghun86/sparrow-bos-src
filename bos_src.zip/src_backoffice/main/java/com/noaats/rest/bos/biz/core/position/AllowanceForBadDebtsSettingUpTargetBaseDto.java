package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllowanceForBadDebtsSettingUpTargetBaseDto extends BaseDto {
    private String istCd;
    private String ptEvlPcdrId;
    private String ptEvlPcdrNm;
    private String acEvlTpId;
    private String acMngGrpId;
    private String evlAreaId;
    private String evlTpId;
    private String ijrModlTc;
    private String pofId;
    private String prdTpId;
    private String ptTlzGrpId;
    private Integer vrs;

    @JsonIgnore
    public Class getBusinessClass() {
        return AllowanceForBadDebtsSettingUpTargetBase.class;
    }
}
