package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.fw.commoncode.CommonCodeDetailDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeBankPopupDto extends CommonCodeDetailDto {
    private String trBnkTc;
    private String trBnkNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return TradeBankPopup.class;
    }
}
