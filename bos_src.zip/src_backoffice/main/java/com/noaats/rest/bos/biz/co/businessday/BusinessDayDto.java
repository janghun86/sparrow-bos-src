package com.noaats.rest.bos.biz.co.businessday;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BusinessDayDto extends BaseDto {
    private String isHdd;
    private String bseDt;
    private String bzDt;
    private String lvl;
    private String bsdTc;
    private String hddNm;
    private String hddCd;
    private String hddDt;
    private String delYn;
    private String istCd;

    @JsonIgnore
    public Class getBusinessClass() {
        return BusinessDay.class;
    }
}
