package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountProcessIdentifierDto extends BaseDto {
    private String acPcsIdfrNm;
    private String acPcsIdfrId;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return AccountProcessIdentifier.class;
    }
}
