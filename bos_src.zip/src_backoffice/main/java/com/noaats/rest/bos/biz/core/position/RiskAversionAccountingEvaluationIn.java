package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class RiskAversionAccountingEvaluationIn extends BaseMessage {
    private RiskAversionAccountingEvaluationDto riskAversionAccountingEvaluation = new RiskAversionAccountingEvaluationDto();
    private List<RiskAversionAccountingEvaluationDto> riskAversionAccountingEvaluationList = new ArrayList<>();
}
