package com.noaats.rest.bos.biz.businesscommon.cashflow;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.position.cashflowpositionevent.regenerate.CashFlowPositionEventDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CashFlowRegenerationDto extends CashFlowPositionEventDto {
    private String chcYn;
    private Double srdIrt;
    private String rfrIrtCd;
    private String fxnFlxTc;
    private String prdNo;
    private String irtCpuBseTc;
    private Integer row;

    @JsonIgnore
    public Class getBusinessClass() {
        return CashFlowRegeneration.class;
    }
}
