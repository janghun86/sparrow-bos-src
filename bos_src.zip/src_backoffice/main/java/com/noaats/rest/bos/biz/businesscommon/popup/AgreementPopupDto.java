package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.ip.AgreementBasicDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AgreementPopupDto extends AgreementBasicDto {
    private String prjNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return AgreementPopup.class;
    }
}
