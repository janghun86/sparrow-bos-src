package com.noaats.rest.bos.biz.businesscommon.counterparty;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.co.CounterpartyAppendInformationSpecificsDto;
import com.noaats.rest.bos.biz.co.CounterpartyBasicDto;
import com.noaats.rest.bos.biz.co.CounterpartyRoleSpecificsDto;
import com.noaats.rest.bos.biz.co.counterparty.CounterpartyAppendInformationDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class CounterpartyManagementIn extends BaseMessage {
    private CounterpartyBasicDto counterpartyBasic = new CounterpartyBasicDto();
    private List<CounterpartyRoleSpecificsDto> counterpartyRoleSpecificsList = new ArrayList<>();
    private List<CounterpartyAppendInformationSpecificsDto> counterpartyAppendInformationSpecificsList = new ArrayList<>();
    private CounterpartyAppendInformationDto counterpartyAppendInformation = new CounterpartyAppendInformationDto();
}
