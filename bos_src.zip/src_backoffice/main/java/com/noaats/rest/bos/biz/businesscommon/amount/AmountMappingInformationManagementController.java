package com.noaats.rest.bos.biz.businesscommon.amount;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/amount")
public class AmountMappingInformationManagementController extends BaseController {

    private final IAmountMappingInformationManagementService<AmountMappingInformationManagement> amountMappingInformationManagementService;

    @GetMapping
    public ResponseEntity<AmountMappingInformationManagementOut> inquiry(@RequestBody BaseRequest<AmountMappingInformationManagementIn> request) throws CustomException {
        AmountMappingInformationManagementIn in = request.getData();
        AmountMappingInformationManagementOut out = new AmountMappingInformationManagementOut();
        // convert
        AmountMappingInformationManagement amountMappingInformationManagement = convert(in.getAmountMappingInformationManagement());

        out.setAmountMappingInformationManagementList(amountMappingInformationManagementService.inquiry(amountMappingInformationManagement));
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<AmountMappingInformationManagementOut> registration(@RequestBody BaseRequest<AmountMappingInformationManagementIn> request) throws CustomException {
        AmountMappingInformationManagementIn in = request.getData();
        AmountMappingInformationManagementOut out = new AmountMappingInformationManagementOut();
        // convert
        List<AmountMappingInformationManagement> amountMappingInformationManagementList = convertList(in.getAmountMappingInformationManagementList());

        Integer cnt = amountMappingInformationManagementService.registration(amountMappingInformationManagementList);
        out.getAmountMappingInformationManagement().setCode(cnt);
        return ResponseEntity.ok(out);
    }
}
