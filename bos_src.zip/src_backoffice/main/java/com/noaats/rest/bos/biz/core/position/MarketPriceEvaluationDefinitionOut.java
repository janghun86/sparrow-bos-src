package com.noaats.rest.bos.biz.core.position;

import com.noaats.rest.bos.biz.cr.MarketPriceEvaluationDefinitionCatalogue;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class MarketPriceEvaluationDefinitionOut {
    private List<MarketPriceEvaluationDefinitionCatalogue> marketPriceEvaluationDefinitionCatalogueList;
}
