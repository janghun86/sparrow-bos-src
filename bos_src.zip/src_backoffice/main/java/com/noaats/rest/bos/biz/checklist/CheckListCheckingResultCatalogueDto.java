package com.noaats.rest.bos.biz.checklist;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import com.noaats.rest.bos.biz.co.checklist.CheckListCheckingResultCatalogue;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckListCheckingResultCatalogueDto extends BaseDto {

    private String cklRltId;

    private String cklRltNm;

    private String cklId;

    private String prdTpId;

    private Long trno;

    private String cklLstRltTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return CheckListCheckingResultCatalogue.class;
    }
}
