package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.EffectivenessInterestRateMethodAmortizeCalculationSpecificsDto;
import com.noaats.rest.bos.biz.cr.EffectivenessInterestRateMethodAmortizeSpecificsDto;
import com.noaats.rest.bos.biz.position.AmortizeSimulationSearchPopupDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AmortizeSimulationSearchPopupIn extends BaseMessage {
    private AmortizeSimulationSearchPopupDto amortizeSimulationSearchPopup = new AmortizeSimulationSearchPopupDto();
    private EffectivenessInterestRateMethodAmortizeSpecificsDto effectivenessInterestRateMethodAmortizeSpecifics = new EffectivenessInterestRateMethodAmortizeSpecificsDto();
    private EffectivenessInterestRateMethodAmortizeCalculationSpecificsDto effectivenessInterestRateMethodAmortizeCalculationSpecifics = new EffectivenessInterestRateMethodAmortizeCalculationSpecificsDto();
}
