package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionUniqueNumberMappingDto extends BaseDto {
    private Long ptUnqNo;
    private String prdGrpTc;
    private String prdNo;
    private String ptTlzId;
    private Long trno;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionUniqueNumberMapping.class;
    }
}
