package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.configuration.PortfolioDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PortfolioIn extends BaseMessage {
    private PortfolioDto portfolio = new PortfolioDto();
}
