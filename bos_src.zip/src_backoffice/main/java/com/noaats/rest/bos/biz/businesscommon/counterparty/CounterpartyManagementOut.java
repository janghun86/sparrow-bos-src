package com.noaats.rest.bos.biz.businesscommon.counterparty;

import com.noaats.rest.bos.biz.co.CounterpartyAppendInformationSpecifics;
import com.noaats.rest.bos.biz.co.CounterpartyBasic;
import com.noaats.rest.bos.biz.co.CounterpartyRoleSpecifics;
import com.noaats.rest.bos.biz.co.counterparty.CounterpartyAppendInformation;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CounterpartyManagementOut {
    private CounterpartyBasic counterpartyBasic;
    private List<CounterpartyRoleSpecifics> counterpartyRoleSpecificsList;
    private List<CounterpartyAppendInformationSpecifics> CounterpartyAppendInformationSpecificsList;
    private CounterpartyAppendInformation counterpartyAppendInformation;
}
