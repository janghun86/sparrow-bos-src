package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/product-type-information")
public class ProductTypeInformationController extends BaseController {

    private final IProductTypeInformationService<ProductTypeInformation> productTypeInformationService;

    @GetMapping
    public ResponseEntity<ProductTypeInformationOut> service(@RequestBody BaseRequest<ProductTypeInformationIn> request) throws CustomException {
        ProductTypeInformationIn in = request.getData();
        ProductTypeInformationOut out = new ProductTypeInformationOut();

        ProductTypeInformation productTypeInformation = convert(in.getProductTypeInformation());

        out.setProductTypeInformationList(productTypeInformationService.inquiry(productTypeInformation));
        return ResponseEntity.ok(out);
    }
}
