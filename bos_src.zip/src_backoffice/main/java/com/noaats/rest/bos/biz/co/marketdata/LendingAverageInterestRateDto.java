package com.noaats.rest.bos.biz.co.marketdata;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LendingAverageInterestRateDto extends BaseDto {
    private String chkYn;
    private String crn1IrtNm;
    private Double avrIrt;
    private String bseSttDt;
    private String bseEndDt;
    private String istCd;
    private String rfrIrtCd;
    private String rfrIrtNm;
    private Integer vrs;
    private String curCd;
    private String irtTrm;
    private String trmUntTc;
    private String irtKdTc;
    private String crn1IrtCd;
    private String crn2IrtCd;
    private String crn3IrtCd;
    private String crn4IrtCd;
    private Integer avrDds;
    private String rmk;
    private Double rfrIrt;
    private String bseDt;

    @JsonIgnore
    public Class getBusinessClass() {
        return LendingAverageInterestRate.class;
    }
}
