package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.PositionManagementBaseSpecificsDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationIdentificationSearchPopupDto extends PositionManagementBaseSpecificsDto {
    private String prdNm;
    private String prdTpNm;
    private String acMngGrpNm;
    private String pofNm;
    private String ptTlzGrpNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionTotalizationIdentificationSearchPopup.class;
    }
}
