package com.noaats.rest.bos.biz.co.marketdata;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.co.ReferenceInterestRateCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReferenceInterestRateDto extends ReferenceInterestRateCatalogueDto {
    private String istCd;
    private String bseDt;
    private String rfrIrtCd;
    private Double rfrIrt;
    private String rmk;
    private String sttDt;
    private String endDt;

    @JsonIgnore
    public Class getBusinessClass() {
        return ReferenceInterestRate.class;
    }
}
