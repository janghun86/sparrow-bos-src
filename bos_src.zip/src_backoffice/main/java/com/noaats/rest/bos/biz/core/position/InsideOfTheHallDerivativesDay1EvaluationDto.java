package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.evaluation.EvaluationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InsideOfTheHallDerivativesDay1EvaluationDto extends EvaluationDto {
    private String chkYn;
    private String pcsStsDtt;
    private String errStgTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return InsideOfTheHallDerivativesDay1Evaluation.class;
    }
}
