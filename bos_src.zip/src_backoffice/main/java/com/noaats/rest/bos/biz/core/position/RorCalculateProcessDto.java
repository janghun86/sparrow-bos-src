package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.position.business.RorCalculateDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RorCalculateProcessDto extends RorCalculateDto {
    private Double prcGb;

    @JsonIgnore
    public Class getBusinessClass() {
        return RorCalculateProcess.class;
    }
}
