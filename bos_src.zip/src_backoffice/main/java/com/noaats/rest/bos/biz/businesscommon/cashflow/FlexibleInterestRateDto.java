package com.noaats.rest.bos.biz.businesscommon.cashflow;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.cashflow.flexibleinterestrate.PositionFlexibleInterestRateDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FlexibleInterestRateDto extends PositionFlexibleInterestRateDto {
    private String pcsStsTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return FlexibleInterestRate.class;
    }
}
