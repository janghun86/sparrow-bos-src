/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <pre>
 *
 * description : 손익집계명세 프로그램
 *
 *
 * </pre>
 *
 * @author : wook2647@noaats.com
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2020. 8. 12.	wook2647@noaats.com		최초생성
 *
 * </pre>
 * @version :
 * @date : 2020. 8. 12. 오후 5:30:10
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/profit-loss-totalization")
public class ProfitAndLossTotalizationProcessController extends BaseController {

    private final IProfitAndLossTotalizationProcessService<ProfitAndLossTotalizationProcess> profitAndLossTotalizationProcessService;

    /**
     * <pre>
     * description : 손익집계명세 조회
     * </pre>
     *
     * @throws Exception
     * @date : 2021. 1. 27.
     * @author : wook2647@noaats.com
     */
    @GetMapping
    public ResponseEntity<ProfitAndLossTotalizationProcessOut> inquiry(@RequestBody BaseRequest<ProfitAndLossTotalizationProcessIn> request) throws CustomException {
        ProfitAndLossTotalizationProcessIn in = request.getData();
        ProfitAndLossTotalizationProcessOut out = new ProfitAndLossTotalizationProcessOut();

        ProfitAndLossTotalizationProcess profitAndLossTotalizationProcess = convert(in.getProfitAndLossTotalizationProcess());

        List<ProfitAndLossTotalizationProcess> inquiryOut = profitAndLossTotalizationProcessService.inquiry(profitAndLossTotalizationProcess);
        out.setProfitAndLossTotalizationProcess(inquiryOut);
        //시스템 메시지
        //systemMessageService.setReadMsgCd(out.getProfitAndLossTotalizationProcess(), requestHeader);
        return ResponseEntity.ok(out);
    }

    /**
     * <pre>
     * description : 손익집계명세 실행
     * </pre>
     *
     * @throws Exception
     * @date : 2020. 8. 12.
     * @author : wook2647@noaats.com
     */
    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<ProfitAndLossTotalizationProcessOut> registration(@RequestBody BaseRequest<ProfitAndLossTotalizationProcessIn> request) throws CustomException {
        ProfitAndLossTotalizationProcessIn in = request.getData();
        ProfitAndLossTotalizationProcessOut out = new ProfitAndLossTotalizationProcessOut();

        ProfitAndLossTotalizationProcess profitAndLossTotalizationProcess = convert(in.getProfitAndLossTotalizationProcess());

        List<ProfitAndLossTotalizationProcess> inquiryOut = profitAndLossTotalizationProcessService.profitAndLossTotalizationGenerate(profitAndLossTotalizationProcess);
        out.setProfitAndLossTotalizationProcess(inquiryOut);
        return ResponseEntity.ok(out);
    }
}
