package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDefinitionReportBasicDto extends BaseDto {
    private String rptId;
    private String rptNm;
    private Integer vrs;
    private String rptPthNm;
    private String lgcFlNm;
    private String flPthNm;
    private String pysFlNm;
    private String tplId;
    private String mngUsid;
    private String apnDesCts;
    private String rptCss1Nm;
    private String rmk;

    @JsonIgnore
    public Class getBusinessClass() {
        return UserDefinitionReportBasic.class;
    }
}
