package com.noaats.rest.bos.biz.businesscommon.nation;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.co.NationCodeCatalogue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/nation")
public class NationCodeController extends BaseController {

    private final INationCodeService<NationCodeCatalogue> nationCodeService;

    @GetMapping
    public ResponseEntity<NationCodeOut> service(@RequestBody BaseRequest<NationCodeIn> request) throws CustomException {
        NationCodeIn in = request.getData();
        NationCodeOut out = new NationCodeOut();
        // convert
        NationCodeCatalogue nationCodeCatalogue = convert(in.getNationCodeCatalogue());

        out.setNationCodeCatalogueList(nationCodeService.inquiry(nationCodeCatalogue));
        return ResponseEntity.ok(out);
    }
}
