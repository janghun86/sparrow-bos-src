package com.noaats.rest.bos.biz.co.exchangerate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExchangeRateDto extends BaseDto {
    private String bseSttDt;
    private String bseEndDt;
    private Double mktAvrUsdCvsRt;
    private Long xcrBltnUntNbr;
    private String istCd;
    private Double kftcBltnBseRt;
    private String curCd;
    private Double bseAplyXcr;
    private String bseDt;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return ExchangeRate.class;
    }
}
