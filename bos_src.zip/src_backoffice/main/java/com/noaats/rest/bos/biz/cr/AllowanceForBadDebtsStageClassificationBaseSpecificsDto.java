package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllowanceForBadDebtsStageClassificationBaseSpecificsDto extends BaseDto {
    private Long sqn;
    private String aplyStgClsBseTc;
    private Integer vrs;
    private String asnTc;
    private Integer bseDds1;
    private Long noCrdGr1;
    private String opr1;
    private Integer bseDds2;
    private Long noCrdGr2;
    private String opr2;
    private String aplyStgClsTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return AllowanceForBadDebtsStageClassificationBaseSpecifics.class;
    }
}
