package com.noaats.rest.bos.biz.businesscommon.businessday;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.co.businessday.BusinessDayDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class BusinessDayManagementIn extends BaseMessage {
    private BusinessDayDto businessDay = new BusinessDayDto();
    private List<BusinessDayDto> businessDayList = new ArrayList<>();
}
