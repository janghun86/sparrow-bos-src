package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.fw.OrganizationDepartmentCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HeadquarterPopupDto extends OrganizationDepartmentCatalogueDto {
    private String hdqCd;
    private String hdqNm;
    private String temCd;
    private String temNm;
    private String dpmRolTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return HeadquarterPopup.class;
    }
}
