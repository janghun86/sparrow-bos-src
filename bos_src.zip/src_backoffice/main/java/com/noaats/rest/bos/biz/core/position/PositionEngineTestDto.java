package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionEngineTestDto extends BaseDto {
    private String trPcsTpId;
    private String prdTpId;
    private String istCd;
    private String acMngGrpId;
    private String pofId;
    private String prdNo;
    private String ptBseDt;
    private String ptTlzId;
    private String ptTlzGrpId;
    private String evlAreaId;
    private String evlTpId;
    private String trFntTc;
    private String ptCurCd;
    private String ptTrno;
    private String astDbtPtTc;
    private String pcsStsTc;
    private String lnkTrPtTrno;
    private String stmDt;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionEngineTest.class;
    }
}
