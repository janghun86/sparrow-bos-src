package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EvaluationAreaMappingDto extends BaseDto {
    private String acMngGrpId;
    private String evlAreaId;
    private String evlGrpId;
    private String prdTpId;
    private String bkgCttYn;
    private String ptClsUntId;
    private String evlCurCd;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return EvaluationAreaMapping.class;
    }
}
