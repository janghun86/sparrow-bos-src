package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeEventTypeDto extends BaseDto {
    private String ptBseDt;
    private String evtTpId;
    private String funOfifTc;
    private String stmCurCd;
    private Double stmAmt;
    private Double stmLca;
    private Double trQty;
    private Double trUpr;
    private Double parAmt;
    private String parCurCd;
    private String dfrCttCurCd;
    private Double dfrCttAmt;
    private String recvCttCurCd;
    private Double recvCttAmt;
    private Double stmAmtAplyXcr;

    @JsonIgnore
    public Class getBusinessClass() {
        return TradeEventType.class;
    }
}
