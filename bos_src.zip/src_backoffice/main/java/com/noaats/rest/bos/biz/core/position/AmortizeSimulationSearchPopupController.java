package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/amortize/popup")
public class AmortizeSimulationSearchPopupController extends BaseController {

    private final IAmortizeSimulationSearchPopupService<AmortizeSimulationSearchPopup> amortizeSimulationSearchPopupService;

    @GetMapping
    public ResponseEntity<AmortizeSimulationSearchPopupOut> inquiry(@RequestBody BaseRequest<AmortizeSimulationSearchPopupIn> request) throws CustomException {
        AmortizeSimulationSearchPopupIn in = request.getData();
        AmortizeSimulationSearchPopupOut out = new AmortizeSimulationSearchPopupOut();
        // convert
        AmortizeSimulationSearchPopup amortizeSimulationSearchPopup = convert(in.getAmortizeSimulationSearchPopup());

        AmortizeSimulationSearchPopup result = amortizeSimulationSearchPopupService.inquiry(amortizeSimulationSearchPopup);
        out.setEffectivenessInterestRateMethodAmortizeSpecifics(result.getEffectivenessInterestRateMethodAmortizeSpecifics());
        out.setEffectivenessInterestRateMethodAmortizeCalculationSpecificsList(result.getEffectivenessInterestRateMethodAmortizeCalculationSpecificsList());
        return ResponseEntity.ok(out);
    }
}
