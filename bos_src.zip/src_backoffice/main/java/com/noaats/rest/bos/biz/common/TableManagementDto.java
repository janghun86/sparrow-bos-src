package com.noaats.rest.bos.biz.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TableManagementDto extends BaseDto {
    private String tbNm;
    private String colNm;
    private String datTp;
    private Double datLen;
    private Double datPre;
    private Double datScl;
    private String nullYn;
    private Double colSeq;
    private String pkYn;
    private String scmNm;
    private String colId;
    private String tbId;
    private String sql;
    private String tbCts;
    private String sqlCnd;

    @JsonIgnore
    public Class getBusinessClass() {
        return TableManagement.class;
    }
}
