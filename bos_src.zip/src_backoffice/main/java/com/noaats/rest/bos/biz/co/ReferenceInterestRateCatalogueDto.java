package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReferenceInterestRateCatalogueDto extends BaseDto {
    private String rfrIrtCd;
    private String rfrIrtNm;
    private Integer vrs;
    private String curCd;
    private String irtTrm;
    private String trmUntTc;
    private String irtKdTc;
    private String crn1IrtCd;
    private String crn2IrtCd;
    private String crn3IrtCd;
    private String crn4IrtCd;
    private Integer avrDds;

    @JsonIgnore
    public Class getBusinessClass() {
        return ReferenceInterestRateCatalogue.class;
    }
}
