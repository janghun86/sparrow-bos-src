package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.ManagementInformationChangeSpecifics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <pre>
 *
 * description : 포지션 이벤트 정보 조회
 *
 *
 * </pre>
 *
 * @author : 정유진
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2018. 12. 17.	정유진		최초생성
 *
 * </pre>
 * @version :
 * @date : 2018. 12. 17. 오후 5:50:07
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/information")
public class PositionInformationController extends BaseController {

    private final IPositionInformationService<PositionInformation> positionInformationService;

    @GetMapping
    public ResponseEntity<PositionInformationOut> inquiry(@RequestBody BaseRequest<PositionInformationIn> request) throws CustomException {
        PositionInformationIn in = request.getData();
        PositionInformationOut out = new PositionInformationOut();

        PositionInformation positionInformation = convert(in.getPositionInformation());

        List<PositionInformation> modelReturn = positionInformationService.inquery(positionInformation);
        out.setPositionInformationList(modelReturn);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/mng-inf-chg")
    public ResponseEntity<PositionInformationOut> inquiryManagementInformationChange(@RequestBody BaseRequest<PositionInformationIn> request) throws CustomException {
        PositionInformationIn in = request.getData();
        PositionInformationOut out = new PositionInformationOut();

        PositionInformation positionInformation = convert(in.getPositionInformation());

        ManagementInformationChangeSpecifics managementInformationChangeSpecifics = positionInformationService.inquiryManagementInformationChange(positionInformation);
        out.setManagementInformationChangeSpecifics(managementInformationChangeSpecifics);
        return ResponseEntity.ok(out);
    }
}
