package com.noaats.rest.bos.biz.core.position;

import com.noaats.rest.bos.biz.cr.AccountsSymbolCatalogue;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AccountsSymbolOut {
    private List<AccountsSymbolCatalogue> accountsSymbolCatalogueList;
}
