package com.noaats.rest.bos.biz.cr.cashflow.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.pr.CashFlowCommonSpecificsDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CashFlowCommonDto extends CashFlowCommonSpecificsDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return CashFlowCommon.class;
    }
}
