package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.PositionClassificationUnitCatalogueDto;
import com.noaats.rest.bos.biz.cr.configuration.*;
import com.noaats.rest.bos.biz.cr.position.business.InstitutionCodeDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class ConfigurationManagementIn extends BaseMessage {
    private List<TableSchemaInfoDto> tableSchemaInfoList = new ArrayList<>();
    private ConfigurationManagementDto configurationManagement = new ConfigurationManagementDto();
    private List<AccountManagementGroupDto> accountManagementGroupList = new ArrayList<>();
    private List<AccountProcessIdentifierDto> accountProcessIdentifierList = new ArrayList<>();
    private List<AccountProcessIdentifierMappingDto> accountProcessIdentifierMappingList = new ArrayList<>();
    private List<AmountProcessTypeDto> amountProcessTypeList = new ArrayList<>();
    private List<ConditionGroupDto> conditionGroupList = new ArrayList<>();
    private List<DependencyPositionProcessTypeOutflowOrInflowMappingDto> dependencyPositionProcessTypeOutflowOrInflowMappingList = new ArrayList<>();
    private List<DependencyPositionProcessTypeRealizationMappingDto> dependencyPositionProcessTypeRealizationMappingList = new ArrayList<>();
    private List<DependencyPositionProcessTypeTransferMappingDto> dependencyPositionProcessTypeTransferMappingList = new ArrayList<>();
    private List<EvaluationAreaDto> evaluationAreaList = new ArrayList<>();
    private List<EvaluationAreaMappingDto> evaluationAreaMappingList = new ArrayList<>();
    private List<EvaluationGroupMappingDto> evaluationGroupMappingList = new ArrayList<>();
    private List<EvaluationTypeDto> evaluationTypeList = new ArrayList<>();
    private List<EvaluationTypeMappingDto> evaluationTypeMappingList = new ArrayList<>();
    private List<EventCategoryDto> eventCategoryList = new ArrayList<>();
    private List<EventPositionProcessTypeMappingDto> eventPositionProcessTypeMappingList = new ArrayList<>();
    private List<EventTypeDto> eventTypeList = new ArrayList<>();
    private List<FunctionTradeProcessTypeMappingDto> functionTradeProcessTypeMappingList = new ArrayList<>();
    private List<InstitutionCodeDto> institutionCodeList = new ArrayList<>();
    private List<PortfolioDto> portfolioList = new ArrayList<>();
    private List<ProductCategoryDto> productCategoryList = new ArrayList<>();
    private List<ProductEvaluationAreaMappingDto> productEvaluationAreaMappingList = new ArrayList<>();
    private List<ProductEvaluationGroupMappingDto> productEvaluationGroupMappingList = new ArrayList<>();
    private List<ProductTypeDto> productTypeList = new ArrayList<>();
    private List<PositionClassificationUnitCatalogueDto> positionClassificationUnitCatalogueList = new ArrayList<>();
    private List<PositionEvaluationProcedureDto> positionEvaluationProcedureList = new ArrayList<>();
    private List<PositionEvaluationProcedureMappingDto> positionEvaluationProcedureMappingList = new ArrayList<>();
    private List<PositionHeadingConfigurationElementMappingDto> positionHeadingConfigurationElementMappingList = new ArrayList<>();
    private List<PositionHeadingDto> positionHeadingList = new ArrayList<>();
    private List<PositionProcessTypeDto> positionProcessTypeList = new ArrayList<>();
    private List<PositionProcessTypeMappingDto> positionProcessTypeMappingList = new ArrayList<>();
    private List<PositionTotalizationGroupDto> positionTotalizationGroupList = new ArrayList<>();
    private List<PositionUniqueNumberMappingDto> positionUniqueNumberMappingList = new ArrayList<>();
    private List<TradeCategoryDto> tradeCategoryList = new ArrayList<>();
    private List<TradeEventTypeMappingDto> tradeEventTypeMappingList = new ArrayList<>();
    private List<TradeProcessTypeDto> tradeProcessTypeList = new ArrayList<>();
    private List<TradeTypeDto> tradeTypeList = new ArrayList<>();
}
