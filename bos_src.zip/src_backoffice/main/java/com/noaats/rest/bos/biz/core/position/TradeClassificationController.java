/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <pre>
 *
 * description : 거래분류목록
 *
 * com.noaats.sol.controller.core.position
 *    TradeClassificationController.java
 *
 * </pre>
 *
 * @author : jwyang@noaats.com
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2020. 12. 22.	jwyang@noaats.com		최초생성
 *
 * </pre>
 * @version :
 * @date : 2020. 12. 22. 오전 8:22:06
 */

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/trade-classification")
public class TradeClassificationController extends BaseController {

    private final ITradeClassificationService<TradeClassification> tradeClassificationService;

    /**
     * <pre>
     * description : 조회
     * </pre>
     *
     * @throws Exception
     * @date : 2020. 12. 22.
     * @author : jwyang@noaats.com
     */
    @GetMapping
    public ResponseEntity<TradeClassificationOut> inquiry(@RequestBody BaseRequest<TradeClassificationIn> request) throws CustomException {
        TradeClassificationIn in = request.getData();
        TradeClassificationOut out = new TradeClassificationOut();

        TradeClassification tradeClassification = convert(in.getTradeClassification());

        List<TradeClassification> resultList = tradeClassificationService.list(tradeClassification);
        out.setTradeClassificationList(resultList);
        return ResponseEntity.ok(out);
    }
}
