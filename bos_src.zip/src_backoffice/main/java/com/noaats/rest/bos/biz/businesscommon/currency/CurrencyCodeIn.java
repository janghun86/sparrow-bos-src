package com.noaats.rest.bos.biz.businesscommon.currency;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.co.CurrencyBasicDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CurrencyCodeIn extends BaseMessage {
    private CurrencyBasicDto currencyBasic = new CurrencyBasicDto();
}
