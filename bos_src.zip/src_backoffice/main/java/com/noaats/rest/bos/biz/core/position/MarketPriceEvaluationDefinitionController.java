package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.IMarketPriceEvaluationDefinitionCatalogueService;
import com.noaats.rest.bos.biz.cr.MarketPriceEvaluationDefinitionCatalogue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/market-price")
public class MarketPriceEvaluationDefinitionController extends BaseController {

    private final IMarketPriceEvaluationDefinitionCatalogueService marketPriceEvaluationDefinitionService;

    @GetMapping
    public ResponseEntity<MarketPriceEvaluationDefinitionOut> service(@RequestBody BaseRequest<MarketPriceEvaluationDefinitionIn> request) throws CustomException {
        MarketPriceEvaluationDefinitionIn in = request.getData();
        MarketPriceEvaluationDefinitionOut out = new MarketPriceEvaluationDefinitionOut();

        MarketPriceEvaluationDefinitionCatalogue marketPriceEvaluationDefinitionCatalogue = convert(in.getMarketPriceEvaluationDefinitionCatalogue());

        List<MarketPriceEvaluationDefinitionCatalogue> marketPriceEvaluationDefinitionCatalogueList = marketPriceEvaluationDefinitionService.findUseAll(marketPriceEvaluationDefinitionCatalogue);
        out.setMarketPriceEvaluationDefinitionCatalogueList(marketPriceEvaluationDefinitionCatalogueList);
        return ResponseEntity.ok(out);
    }
}
