package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DependencyPositionProcessTypeOutflowOrInflowMappingSpecificsDto extends BaseDto {
    private String ptEvlPcdrId;
    private String dpdMpnTpId;
    private String dpdMpnTpNm;
    private String pnbDpdTpId;
    private String pnbPtPcsTpId;
    private String nnbDpdTpId;
    private String nnbPtPcsTpId;

    @JsonIgnore
    public Class getBusinessClass() {
        return DependencyPositionProcessTypeOutflowOrInflowMappingSpecifics.class;
    }
}
