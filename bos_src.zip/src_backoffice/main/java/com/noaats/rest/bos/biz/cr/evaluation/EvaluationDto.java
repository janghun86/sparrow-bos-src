package com.noaats.rest.bos.biz.cr.evaluation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.position.positionbalance.PositionBalanceDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EvaluationDto extends PositionBalanceDto {
    private Double jbefFxevCpadVca;
    private Double jbefCpadVca;
    private Double jbefCpadAmt;
    private Double mrprEvlAfAbkVca;
    private Double mrprEvlAfAbkAmt;
    private Double mrprEvlPnlVca;
    private Double mrprEvlPnlAmt;
    private Double evlUpr;
    private Double mrprEvlBseAbkVca;
    private Double mrprEvlBseAbkAmt;
    private Double fxevAfAbkVca;
    private Double jbefAbkVca;
    private Double jbefAbkAmt;
    private Double fcCvsPnlAmt;
    private Double bseXcr;
    private Double amafAcqVca;
    private Double amafAcqAmt;
    private Double amrVca;
    private Double amrAmt;
    private Double avrXcr;
    private Double pvAmt;
    private Double jbefAmafAcqVca;
    private Double jbefAmafAcqAmt;
    private Double eir;
    private String jbefAmrDt;
    private String evlCurCd;
    private String ptTrno;
    private String delYn;
    private String ptTlzId;
    private String istCd;
    private String prdNo;
    private String bseDt;
    private String ptCurCd;
    private String eirPcsMthTc;
    private String amrRsuYn;
    private String evlCtgTc;
    private String evlAreaId;
    private Double rcbIntAmt;
    private Double parAmt;
    private Long ptMngBseNo;
    private String aplySttDt;
    private String aplyEndDt;
    private String ptEvlPcdrId;
    private String errMsg;
    private String rsuDt;
    private String astDbtPtTc;
    private String evlPcs5Id;
    private String evlStg5Tc;
    private String evlPcs4Id;
    private String evlStg4Tc;
    private String evlPcs3Id;
    private String evlStg3Tc;
    private String evlPcs2Id;
    private String evlStg2Tc;
    private String evlPcs1Id;
    private String evlStg1Tc;
    private String ptEvlPcdrNm;
    private String ptEvlTc;
    private String acMngGrpId;
    private String ptTlzGrpId;
    private String evlTpId;
    private String pofId;
    private Long dpsIstCptyNo;
    private Double ptQty;
    private String mrprTc;
    private Double rcbIntVca;

    @JsonIgnore
    public Class getBusinessClass() {
        return Evaluation.class;
    }
}
