/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/trade-totalization-process")
public class TradeTotalizationProcessController extends BaseController {

    private final ITradeTotalizationProcessService<TradeTotalizationProcess> tradeTotalizationProcessService;

    @GetMapping
    public ResponseEntity<TradeTotalizationProcessOut> searchTradeTotalization(@RequestBody BaseRequest<TradeTotalizationProcessIn> request) throws CustomException {
        TradeTotalizationProcessIn in = request.getData();
        TradeTotalizationProcessOut out = new TradeTotalizationProcessOut();

        List<TradeTotalizationProcess> tradeTotalizationProcess = convertList(in.getTradeTotalizationProcess());

        List<TradeTotalizationProcess> searchTradeTotalizationOut = tradeTotalizationProcessService.searchTradeTotalization(tradeTotalizationProcess.get(0));
        out.setTradeTotalizationProcess(searchTradeTotalizationOut);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/generate")
    public ResponseEntity<TradeTotalizationProcessOut> generateTradeTotalization(@RequestBody BaseRequest<TradeTotalizationProcessIn> request) throws CustomException {
        TradeTotalizationProcessIn in = request.getData();
        TradeTotalizationProcessOut out = new TradeTotalizationProcessOut();

        List<TradeTotalizationProcess> tradeTotalizationProcessList = convertList(in.getTradeTotalizationProcess());

        List<TradeTotalizationProcess> inquiryTradeTypeCatalogue = tradeTotalizationProcessService.generateTradeTotalization(tradeTotalizationProcessList);
        out.setTradeTotalizationProcess(inquiryTradeTypeCatalogue);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/co-cd")
    public ResponseEntity<TradeTotalizationProcessOut> searchCoCd(@RequestBody BaseRequest<TradeTotalizationProcessIn> request) throws CustomException {
        TradeTotalizationProcessIn in = request.getData();
        TradeTotalizationProcessOut out = new TradeTotalizationProcessOut();

        List<TradeTotalizationProcess> tradeTotalizationProcessList = convertList(in.getTradeTotalizationProcess());

        List<TradeTotalizationProcess> inquiryCoCd = tradeTotalizationProcessService.searchCoCd(tradeTotalizationProcessList);
        out.setTradeTotalizationProcess(inquiryCoCd);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TradeTotalizationProcessOut> registration(@RequestBody BaseRequest<TradeTotalizationProcessIn> request) throws CustomException {
        TradeTotalizationProcessIn in = request.getData();
        TradeTotalizationProcessOut out = new TradeTotalizationProcessOut();

        List<TradeTotalizationProcess> tradeTotalizationProcessList = convertList(in.getTradeTotalizationProcess());

        tradeTotalizationProcessService.save(tradeTotalizationProcessList);
        return ResponseEntity.ok(out);
    }
}
