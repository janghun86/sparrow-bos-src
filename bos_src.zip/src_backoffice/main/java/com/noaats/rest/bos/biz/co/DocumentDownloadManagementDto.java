package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentDownloadManagementDto extends BaseDto {
    private String docMngNo;
    private String docKpnNm;
    private Long sno;
    private String usid;
    private String dnldDt;
    private String dnldHr;

    @JsonIgnore
    public Class getBusinessClass() {
        return DocumentDownloadManagementSpecifics.class;
    }
}
