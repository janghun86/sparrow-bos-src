package com.noaats.rest.bos.biz.core.position;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class PositionManagementBaseInformationOut {
    private PositionManagementBaseInformation positionManagementBaseInformation;
}
