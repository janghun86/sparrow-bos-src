package com.noaats.rest.bos.biz.businesscommon.holiday;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.co.HolidayCodeCatalogueDto;
import com.noaats.rest.bos.biz.co.HolidayDateSpecificsDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class HolidayCodeManagementIn extends BaseMessage {
    private HolidayDateSpecificsDto holidayDateSpecifics = new HolidayDateSpecificsDto();
    private HolidayCodeCatalogueDto holidayCodeCatalogue = new HolidayCodeCatalogueDto();
    private List<HolidayDateDto> holidayDateInformationList = new ArrayList<>();
}
