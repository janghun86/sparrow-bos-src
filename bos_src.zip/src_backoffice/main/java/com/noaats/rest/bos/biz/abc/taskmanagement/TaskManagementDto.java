package com.noaats.rest.bos.biz.abc.taskmanagement;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaskManagementDto extends BaseDto {
    private String chat;
    private String usid;
    private String dpmId;
    private String tskId;

    @JsonIgnore
    public Class getBusinessClass() {
        return TaskManagement.class;
    }
}
