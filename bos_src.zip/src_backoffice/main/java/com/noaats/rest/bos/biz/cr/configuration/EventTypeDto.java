package com.noaats.rest.bos.biz.cr.configuration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EventTypeDto extends BaseDto {
    private String prdTpId;
    private String prdGrpTc;
    private String evtTpNm;
    private String evtTpId;
    private String evtGrpTc;
    private String evtClsId;
    private String cshCrnYn;
    private String tctCrnYn;
    private String istCd;
    private String delYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return EventType.class;
    }
}
