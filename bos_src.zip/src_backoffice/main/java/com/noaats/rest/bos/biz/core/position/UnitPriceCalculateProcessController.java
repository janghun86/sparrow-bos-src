/*
 * Copyright (c) 2017, NOA ATS Inc. All rights reserved.
 * NOA ATS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <pre>
 *
 * description : 단가계산화면 Controller
 *
 * com.noaats.sol.controller.core.position
 *    UnitPriceCalculateProcessController.java
 *
 * </pre>
 *
 * @author : wook2647@noaats.com
 *
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일                   수정자                            수정내용
 * ----------------------------------------------
 * 2020. 7. 20.	wook2647@noaats.com		최초생성
 *
 * </pre>
 * @version :
 * @date : 2020. 7. 20. 오전 9:02:21
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/unit-price")
public class UnitPriceCalculateProcessController extends BaseController {

    private final IUnitPriceCalculateProcessService<UnitPriceCalculateProcess> unitPriceCalculateProcessService;

    @GetMapping
    public ResponseEntity<UnitPriceCalculateProcessOut> inquiry(@RequestBody BaseRequest<UnitPriceCalculateProcessIn> request) throws CustomException {
        UnitPriceCalculateProcessIn in = request.getData();
        UnitPriceCalculateProcessOut out = new UnitPriceCalculateProcessOut();
        UnitPriceCalculateProcess inquiryOut = unitPriceCalculateProcessService.inquiry(convert(in.getUnitPriceCalculateProcess()));
        out.setUnitPriceCalculateProcess(inquiryOut);
        out.setCashFlow(inquiryOut.getUnitPriceCashFlow());
        return ResponseEntity.ok(out);
    }
}
