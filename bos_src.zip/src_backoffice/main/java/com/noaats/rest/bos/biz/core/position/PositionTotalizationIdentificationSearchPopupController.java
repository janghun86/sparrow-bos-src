package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/totalization-identification")
public class PositionTotalizationIdentificationSearchPopupController extends BaseController {

    private final IPositionTotalizationIdentificationSearchPopupService<PositionTotalizationIdentificationSearchPopup> positionTotalizationIdentificationSearchPopupService;

    @GetMapping
    public ResponseEntity<PositionTotalizationIdentificationSearchPopupOut> inquiry(@RequestBody BaseRequest<PositionTotalizationIdentificationSearchPopupIn> request) throws CustomException {
        PositionTotalizationIdentificationSearchPopupIn in = request.getData();
        PositionTotalizationIdentificationSearchPopupOut out = new PositionTotalizationIdentificationSearchPopupOut();

        PositionTotalizationIdentificationSearchPopup positionTotalizationIdentificationSearchPopup = convert(in.getPositionTotalizationIdentificationSearchPopup());

        List<PositionTotalizationIdentificationSearchPopup> resultList = positionTotalizationIdentificationSearchPopupService.inquiry(positionTotalizationIdentificationSearchPopup);
        out.setPositionTotalizationIdentificationSearchPopup(resultList);
        return ResponseEntity.ok(out);
    }
}