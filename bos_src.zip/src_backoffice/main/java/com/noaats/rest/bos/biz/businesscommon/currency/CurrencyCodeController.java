package com.noaats.rest.bos.biz.businesscommon.currency;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.co.CurrencyBasic;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/currency")
public class CurrencyCodeController extends BaseController {
    private final ICurrencyCodeService<CurrencyBasic> currencyCodeService;

    @GetMapping
    public ResponseEntity<CurrencyCodeOut> inquiry(@RequestBody BaseRequest<CurrencyCodeIn> request) throws CustomException {
        CurrencyCodeIn in = request.getData();
        CurrencyCodeOut out = new CurrencyCodeOut();
        // convert
        CurrencyBasic currencyBasic = convert(in.getCurrencyBasic());

        out.setCurrencyBasicList(currencyCodeService.inquiry(currencyBasic));
        return ResponseEntity.ok(out);
    }
}
