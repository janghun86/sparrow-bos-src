package com.noaats.rest.bos.biz.businesscommon.businessday;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.co.businessday.BusinessDay;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/businessday")
public class BusinessDayManagementController extends BaseController {

    private final IBusinessDayManagementService<BusinessDay> businessDayManagementService;

    @GetMapping
    public ResponseEntity<BusinessDayManagementOut> inquiry(@RequestBody BaseRequest<BusinessDayManagementIn> request) throws CustomException {
        BusinessDayManagementIn in = request.getData();
        BusinessDayManagementOut out = new BusinessDayManagementOut();
        // convert
        BusinessDay businessDay = convert(in.getBusinessDay());

        out.setBusinessDay(businessDayManagementService.inquiry(businessDay));
        return ResponseEntity.ok(out);
    }

    @GetMapping("/check")
    public ResponseEntity<BusinessDayManagementOut> inquiryHoliday(@RequestBody BaseRequest<BusinessDayManagementIn> request) throws CustomException {
        BusinessDayManagementIn in = request.getData();
        BusinessDayManagementOut out = new BusinessDayManagementOut();
        // convert
        BusinessDay businessDay = convert(in.getBusinessDay());
        // 휴일여부 체크
        out.setBusinessDayList(businessDayManagementService.inquiryHoliday(businessDay));
        return ResponseEntity.ok(out);
    }

    @GetMapping("/check-list")
    public ResponseEntity<BusinessDayManagementOut> checkHoliday(@RequestBody BaseRequest<BusinessDayManagementIn> request) throws CustomException {
        BusinessDayManagementIn in = request.getData();
        BusinessDayManagementOut out = new BusinessDayManagementOut();
        // convert
        List<BusinessDay> businessDayList = convertList(in.getBusinessDayList());

        // 휴일체크 리스트
        for (BusinessDay businessDayValue : businessDayList) {
            boolean bHoliday = businessDayManagementService.checkHoliday(businessDayValue.getBseDt());
            if (bHoliday) {
                businessDayValue.setIsHdd("Y");
            } else {
                businessDayValue.setIsHdd("N");
            }
            out.getBusinessDayList().add(businessDayValue);
        }
        return ResponseEntity.ok(out);
    }
}
