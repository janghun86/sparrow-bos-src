package com.noaats.rest.bos.biz.checklist;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.co.checklist.CheckListCatalogue;
import com.noaats.rest.bos.biz.co.checklist.CheckListCheckingResultCatalogue;
import com.noaats.rest.bos.biz.tr.ChoiceHeadingSpecifics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/checklist")
public class CheckListController extends BaseController {

    private final ICheckListService checkListService;

    @PostMapping("/listBox")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CheckListOut> registerListBox(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();

        List<ChoiceHeadingSpecifics> choiceHeadingSpecificsList = checkListService.registerListBox(convertList(in.getChoiceHeadingSpecificsList()));
        out.setChoiceHeadingSpecificsList(choiceHeadingSpecificsList);

        return ResponseEntity.ok(out);
    }

    @GetMapping("/listBox")
    public ResponseEntity<CheckListOut> searchListBox(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();

        List<ChoiceHeadingSpecifics> choiceHeadingSpecificsList = checkListService.searchListBox(convert(in.getChoiceHeadingSpecifics()));
        out.setChoiceHeadingSpecificsList(choiceHeadingSpecificsList);

        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CheckListOut> registerCheckList(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();
        CheckListInform checkListInform = new CheckListInform();
        checkListInform.setCheckListCatalogue(convert(in.getCheckListCatalogue()));
        checkListInform.setCheckListClassifiedByProcedureCatalogueList(convertList(in.getCheckListClassifiedByProcedureCatalogueList()));
        checkListInform.setCheckListProcedureClassifiedByColumnCatalogueList(convertList(in.getCheckListProcedureClassifiedByColumnCatalogueList()));
        checkListInform.setCheckListProcedureClassifiedByCheckingHeadingCatalogueList(convertList(in.getCheckListProcedureClassifiedByCheckingHeadingCatalogueList()));

        checkListInform = checkListService.registerCheckList(checkListInform);

        out.setCheckListCatalogue(checkListInform.getCheckListCatalogue());
        out.setCheckListClassifiedByProcedureCatalogueList(checkListInform.getCheckListClassifiedByProcedureCatalogueList());
        out.setCheckListProcedureClassifiedByColumnCatalogueList(checkListInform.getCheckListProcedureClassifiedByColumnCatalogueList());
        out.setCheckListProcedureClassifiedByCheckingHeadingCatalogueList(checkListInform.getCheckListProcedureClassifiedByCheckingHeadingCatalogueList());

        return ResponseEntity.ok(out);
    }

    @GetMapping("/popup")
    public ResponseEntity<CheckListOut> findCheckListPopup(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();

        List<CheckListCatalogue> checkListCatalogueList = checkListService.checkListPopupInquiry(convert(in.getCheckListCatalogue()));
        out.setCheckListCatalogueList(checkListCatalogueList);

        return ResponseEntity.ok(out);
    }

    @GetMapping()
    public ResponseEntity<CheckListOut> searchCheckList(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();

        CheckListInform checkListInform = new CheckListInform();
        checkListInform.setCheckListCatalogue(convert(in.getCheckListCatalogue()));

        checkListInform = checkListService.searchCheckList(checkListInform);

        out.setCheckListCatalogue(checkListInform.getCheckListCatalogue());
        out.setCheckListClassifiedByProcedureCatalogueList(checkListInform.getCheckListClassifiedByProcedureCatalogueList());
        out.setCheckListProcedureClassifiedByColumnCatalogueList(checkListInform.getCheckListProcedureClassifiedByColumnCatalogueList());
        out.setCheckListProcedureClassifiedByCheckingHeadingCatalogueList(checkListInform.getCheckListProcedureClassifiedByCheckingHeadingCatalogueList());
        out.setChoiceHeadingSpecificsList(checkListInform.getChoiceHeadingSpecificsList());

        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CheckListOut> updateCheckList(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();
        CheckListInform checkListInform = new CheckListInform();
        checkListInform.setCheckListCatalogue(convert(in.getCheckListCatalogue()));
        checkListInform.setCheckListClassifiedByProcedureCatalogueList(convertList(in.getCheckListClassifiedByProcedureCatalogueList()));
        checkListInform.setCheckListProcedureClassifiedByColumnCatalogueList(convertList(in.getCheckListProcedureClassifiedByColumnCatalogueList()));
        checkListInform.setCheckListProcedureClassifiedByCheckingHeadingCatalogueList(convertList(in.getCheckListProcedureClassifiedByCheckingHeadingCatalogueList()));

        checkListInform = checkListService.updateCheckList(checkListInform);

        out.setCheckListCatalogue(checkListInform.getCheckListCatalogue());
        out.setCheckListClassifiedByProcedureCatalogueList(checkListInform.getCheckListClassifiedByProcedureCatalogueList());
        out.setCheckListProcedureClassifiedByColumnCatalogueList(checkListInform.getCheckListProcedureClassifiedByColumnCatalogueList());
        out.setCheckListProcedureClassifiedByCheckingHeadingCatalogueList(checkListInform.getCheckListProcedureClassifiedByCheckingHeadingCatalogueList());

        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CheckListOut> deleteCheckList(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();

        CheckListInform checkListInform = new CheckListInform();
        checkListInform.setCheckListCatalogue(convert(in.getCheckListCatalogue()));

        checkListInform = checkListService.deleteCheckList(checkListInform);

        return ResponseEntity.ok(out);
    }

    @GetMapping("result")
    public ResponseEntity<CheckListOut> searchCheckListResult(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();

        CheckListInform checkListInform = new CheckListInform();

        checkListInform.setCheckListCatalogue(convert(in.getCheckListCatalogue()));
        checkListInform.setCheckListCheckingResultCatalogue(convert(in.getCheckListCheckingResultCatalogue()));

        checkListInform = checkListService.searchCheckList(checkListInform);

        out.setCheckListCheckingResultCatalogue(checkListInform.getCheckListCheckingResultCatalogue());
        out.setCheckListCheckingResultValueSpecificsList(checkListInform.getCheckListCheckingResultValueSpecificsList());
        out.setCheckListCatalogue(checkListInform.getCheckListCatalogue());
        out.setCheckListClassifiedByProcedureCatalogueList(checkListInform.getCheckListClassifiedByProcedureCatalogueList());
        out.setCheckListProcedureClassifiedByColumnCatalogueList(checkListInform.getCheckListProcedureClassifiedByColumnCatalogueList());
        out.setCheckListProcedureClassifiedByCheckingHeadingCatalogueList(checkListInform.getCheckListProcedureClassifiedByCheckingHeadingCatalogueList());
        out.setChoiceHeadingSpecificsList(checkListInform.getChoiceHeadingSpecificsList());

        checkListService.searchCheckListRule(checkListInform);
        out.setCheckListCheckingResultRuleSpecificsList(checkListInform.getCheckListCheckingResultRuleSpecificsList());


        return ResponseEntity.ok(out);
    }

    @PostMapping("result")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CheckListOut> registerChecklistResult(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();
        CheckListInform checkListInform = new CheckListInform();
        checkListInform.setCheckListCheckingResultCatalogue(convert(in.getCheckListCheckingResultCatalogue()));
        checkListInform.setCheckListCheckingResultValueSpecificsList(convertList(in.getCheckListCheckingResultValueSpecificsList()));

        checkListInform = checkListService.registerChecklistResult(checkListInform);

        out.setCheckListCheckingResultCatalogue(checkListInform.getCheckListCheckingResultCatalogue());

        return ResponseEntity.ok(out);
    }

    @GetMapping("result/popup")
    public ResponseEntity<CheckListOut> findCheckListResultPopup(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();

        List<CheckListCheckingResultCatalogue> checkListCheckingResultCatalogueList = checkListService.checkListResultPopupInquiry(convert(in.getCheckListCheckingResultCatalogue()));
        out.setCheckListCheckingResultCatalogueList(checkListCheckingResultCatalogueList);

        return ResponseEntity.ok(out);
    }

    @PutMapping("result")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CheckListOut> updateCheckListResult(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();
        CheckListInform checkListInform = new CheckListInform();
        checkListInform.setCheckListCheckingResultCatalogue(convert(in.getCheckListCheckingResultCatalogue()));
        checkListInform.setCheckListCheckingResultValueSpecificsList(convertList(in.getCheckListCheckingResultValueSpecificsList()));

        checkListInform = checkListService.updateCheckListResult(checkListInform);

        out.setCheckListCheckingResultCatalogue(checkListInform.getCheckListCheckingResultCatalogue());

        return ResponseEntity.ok(out);
    }

    @PutMapping("result/trno")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CheckListOut> updateCheckListResultTrno(@RequestBody BaseRequest<CheckListIn> request) throws CustomException {

        CheckListIn in = request.getData();
        CheckListOut out = new CheckListOut();

        CheckListCheckingResultCatalogue checkListCheckingResultCatalogue = checkListService.updateCheckListResultTrno(convert(in.getCheckListCheckingResultCatalogue()));

        out.setCheckListCheckingResultCatalogue(checkListCheckingResultCatalogue);

        return ResponseEntity.ok(out);
    }
}
