package com.noaats.rest.bos.biz.co.counterparty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CounterpartyDto extends BaseDto {
    private String c0009;
    private String c0008;
    private String c0007;
    private String c0006;
    private String c0005;
    private String c0004;
    private String c0003;
    private String c0002;
    private String c0001;
    private String istCd;
    private Long cptyNo;
    private Integer vrs;
    private String cptyStsTc;
    private String cptyTc;
    private String hfcNtnCd;
    private String lctpNtnCd;
    private String cptyNm;
    private String cptyEnlNm;
    private String cptyAbvNm;
    private String cptyEnlAbvNm;
    private String trBnkTc;
    private String adr;
    private String tpn;
    private String faxn;
    private String rmk;
    private String delYn;
    private String actTc;
    private String ano;
    private String curCd;
    private String actNm;
    private Long actOpnIstNo;
    private String acMngGrpId;
    private String ptTlzGrpId;
    private String moAno;
    private String aplyEndDt;
    private String aplySttDt;
    private String pofId;
    private String bblMngYn;
    private String ptTlzUseYn;
    private Long lnkTrno;
    private String asjCd;
    private String prdTpId;
    private String ntnCd;
    private String bicCd;
    private String dpwNm;
    private String dpwNmCrmYn;

    @JsonIgnore
    public Class getBusinessClass() {
        return Counterparty.class;
    }
}
