package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TablePopupDto extends BaseDto {
    private String tbNm;
    private String cmt;
    private String scmNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return TablePopup.class;
    }
}
