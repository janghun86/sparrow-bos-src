package com.noaats.rest.bos.biz.businesscommon.yieldcurve;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class InterestRateCurveIdentificationInquiryPopUpOut {
    private InterestRateCurveIdentificationInquiryPopUp interestRateCurveIdentificationInquiryPopUp;
    private List<InterestRateCurveIdentificationInquiryPopUp> interestRateCurveIdentificationInquiryPopUplist;
}
