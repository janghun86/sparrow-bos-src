package com.noaats.rest.bos.biz.businesscommon.account;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class AccountEnrollmentDto extends BaseDto {
    private String trBnkTc;
    private String ntnNm;
    private String ntnCd;
    private String bicCd;
    private String prdTpNm;
    private String prdTpId;
    private String acMngGrpId;
    private String curNm;
    private String cptyNm;
    private String actOpnIstNm;
    private String pofNm;
    private String ptTlzGrpNm;
    private String acMngGrpNm;
    private String lcoActIcdYn;
    private String actTc;
    private String ano;
    private String actNm;
    private Long actOpnIstNo;
    private String aplyEndDt;
    private String istCd;
    private Long cptyNo;
    private Integer vrs;
    private String curCd;
    private String ptTlzGrpId;
    private String moAno;
    private String aplySttDt;
    private String pofId;
    private String bblMngYn;
    private String ptTlzUseYn;
    private Long lnkTrno;
    private String asjCd;
    private String delYn;
    private String fstEnrUsid;
    private String fstEnrTrid;
    private String fstEnrIp;
    private String lstChgUsid;
    private String lstChgTrid;
    private String lstChgIp;
    private String dpwNm;
    private String dpwNmCrmYn;
    private String tpn;

    @JsonIgnore
    public Class getBusinessClass() {
        return AccountEnrollment.class;
    }
}
