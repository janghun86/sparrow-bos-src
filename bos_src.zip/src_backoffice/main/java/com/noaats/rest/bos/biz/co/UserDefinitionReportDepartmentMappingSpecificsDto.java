package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDefinitionReportDepartmentMappingSpecificsDto extends BaseDto {
    private String rptId;
    private String dpmCd;
    private Integer vrs;
    private String rmk;

    @JsonIgnore
    public Class getBusinessClass() {
        return UserDefinitionReportDepartmentMappingSpecifics.class;
    }
}
