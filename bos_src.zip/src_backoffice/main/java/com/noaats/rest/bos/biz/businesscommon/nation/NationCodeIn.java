package com.noaats.rest.bos.biz.businesscommon.nation;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.co.NationCodeCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NationCodeIn extends BaseMessage {
    private NationCodeCatalogueDto nationCodeCatalogue = new NationCodeCatalogueDto();
}
