package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecuritiesLeaseTradeBasicDto extends BaseDto {
    private String lseMngNo;
    private String lseTrTpId;
    private String cttCcsDt;
    private Integer vrs;
    private String prdNo;
    private String lseTrTc;
    private Long lseImdIstNo;
    private String imdIstCcsNo;
    private String cttXrtDt;
    private Double ccsQty;
    private Double ccsUpr;
    private Double ccsAmt;
    private Double bdFeeAplyUpr;
    private Double lseFrt;
    private String imdFeeCalBseTc;
    private Double imdFrt;
    private Double intcFrt;
    private String acMngGrpId;
    private String pofId;
    private String ptTlzGrpId;
    private String evlTpId;
    private String mgmtDpmCd;
    private String fnmnUsid;
    private String thcoRomAno;
    private String thcoDrwAno;
    private String stmAno;
    private String scuDpsAno;

    @JsonIgnore
    public Class getBusinessClass() {
        return SecuritiesLeaseTradeBasic.class;
    }
}
