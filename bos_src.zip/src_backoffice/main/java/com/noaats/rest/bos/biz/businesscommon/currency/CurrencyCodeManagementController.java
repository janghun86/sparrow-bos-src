package com.noaats.rest.bos.biz.businesscommon.currency;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.co.CurrencyBasic;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/currency/management")
public class CurrencyCodeManagementController extends BaseController {
    private final ICurrencyCodeManagementService<CurrencyCodeManagement> currencyCodeManagementService;

    @GetMapping
    public ResponseEntity<CurrencyCodeManagementOut> inquiry(@RequestBody BaseRequest<CurrencyCodeManagementIn> request) throws CustomException {
        CurrencyCodeManagementIn in = request.getData();
        CurrencyCodeManagementOut out = new CurrencyCodeManagementOut();
        CurrencyCodeManagement currencyCodeManagement = new CurrencyCodeManagement();
        // convert
        CurrencyBasic currencyBasic = convert(in.getCurrencyBasic());

        currencyCodeManagement.setCurrencyBasic(currencyBasic);
        BeanUtils.copyProperties(currencyCodeManagementService.inquiry(currencyCodeManagement), out);
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CurrencyCodeManagementOut> registration(@RequestBody BaseRequest<CurrencyCodeManagementIn> request) throws CustomException {
        CurrencyCodeManagementIn in = request.getData();
        CurrencyCodeManagementOut out = new CurrencyCodeManagementOut();
        CurrencyCodeManagement currencyCodeManagement = new CurrencyCodeManagement();
        // convert
        CurrencyBasic currencyBasic = convert(in.getCurrencyBasic());

        currencyCodeManagement.setCurrencyBasic(currencyBasic);
        currencyCodeManagementService.registration(currencyCodeManagement);
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CurrencyCodeManagementOut> modify(@RequestBody BaseRequest<CurrencyCodeManagementIn> request) throws CustomException {
        CurrencyCodeManagementIn in = request.getData();
        CurrencyCodeManagementOut out = new CurrencyCodeManagementOut();
        CurrencyCodeManagement currencyCodeManagement = new CurrencyCodeManagement();
        // convert
        CurrencyBasic currencyBasic = convert(in.getCurrencyBasic());

        currencyCodeManagement.setCurrencyBasic(currencyBasic);
        currencyCodeManagementService.modify(currencyCodeManagement);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CurrencyCodeManagementOut> cancel(@RequestBody BaseRequest<CurrencyCodeManagementIn> request) throws CustomException {
        CurrencyCodeManagementIn in = request.getData();
        CurrencyCodeManagementOut out = new CurrencyCodeManagementOut();
        CurrencyCodeManagement currencyCodeManagement = new CurrencyCodeManagement();
        // convert
        CurrencyBasic currencyBasic = convert(in.getCurrencyBasic());

        currencyCodeManagement.setCurrencyBasic(currencyBasic);
        currencyCodeManagementService.cancel(currencyCodeManagement);
        return ResponseEntity.ok(out);
    }
}
