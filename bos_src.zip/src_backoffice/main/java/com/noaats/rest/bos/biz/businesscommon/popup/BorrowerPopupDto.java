package com.noaats.rest.bos.biz.businesscommon.popup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class BorrowerPopupDto extends BaseDto {
    private String cptyRolTc;
    private String istCd;
    private Long cptyNo;
    private String cptyStsTc;
    private String cptyTc;
    private String hfcNtnCd;
    private String cptyNm;
    private String cptyEnlNm;
    private String cptyAbvNm;
    private String cptyEnlAbvNm;
    private String adr;
    private Integer vrs;
    private String lctpNtnCd;
    private String trBnkTc;
    private String tpn;
    private String faxn;
    private String rmk;
    private String delYn;
    private String fstEnrUsid;
    private String fstEnrTrid;
    private String fstEnrIp;
    private String lstChgUsid;
    private String lstChgTrid;
    private String lstChgIp;

    @JsonIgnore
    public Class getBusinessClass() {
        return BorrowerPopup.class;
    }
}
