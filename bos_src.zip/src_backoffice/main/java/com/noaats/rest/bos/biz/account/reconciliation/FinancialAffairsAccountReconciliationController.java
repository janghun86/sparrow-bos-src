package com.noaats.rest.bos.biz.account.reconciliation;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/account/reconciliation")
public class FinancialAffairsAccountReconciliationController extends BaseController {

    private final IFinancialAffairsAccountReconciliationService<FinancialAffairsAccountReconciliation> financialAffairsAccountReconciliationService;

    @GetMapping
    public ResponseEntity<FinancialAffairsAccountReconciliationOut> service(@RequestBody BaseRequest<FinancialAffairsAccountReconciliationIn> request) throws CustomException {
        FinancialAffairsAccountReconciliationIn in = request.getData();
        FinancialAffairsAccountReconciliationOut out = new FinancialAffairsAccountReconciliationOut();
        // convert
        FinancialAffairsAccountReconciliation financialAffairsAccountReconciliation = convert(in.getFinancialAffairsAccountReconciliation());

        List<FinancialAffairsAccountReconciliation> resultList = financialAffairsAccountReconciliationService.list(financialAffairsAccountReconciliation);
        out.setFinancialAffairsAccountReconciliationList(resultList);
//        systemMessageService.setReadMsgCd(out.getFinancialAffairsAccountReconciliationList(), requestHeader);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/detail")
    public ResponseEntity<FinancialAffairsAccountReconciliationOut> inquiry(@RequestBody BaseRequest<FinancialAffairsAccountReconciliationIn> request) throws CustomException {
        FinancialAffairsAccountReconciliationIn in = request.getData();
        FinancialAffairsAccountReconciliationOut out = new FinancialAffairsAccountReconciliationOut();
        // convert
        FinancialAffairsAccountReconciliation financialAffairsAccountReconciliation = convert(in.getFinancialAffairsAccountReconciliation());

        List<FinancialAffairsAccountReconciliation> resultList = financialAffairsAccountReconciliationService.listDetail(financialAffairsAccountReconciliation);
        out.setFinancialAffairsAccountReconciliationList(resultList);
//        systemMessageService.setReadMsgCd(out.getFinancialAffairsAccountReconciliationList(), requestHeader);
        return ResponseEntity.ok(out);
    }
}
