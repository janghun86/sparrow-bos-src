package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeTotalizationProcessDto extends BaseDto {
    private String chkYn;
    private String delYn;
    private Double vca;
    private Double pca;
    private String trTlzColId;
    private String dfrCurCd;
    private Double dfrCttAmt;
    private String recvCurCd;
    private Double recvCttAmt;
    private String evlCurCd;
    private String ptCurCd;
    private Double untNbr;
    private Double parAmt;
    private Long sno;
    private String trTlzTrTpId;
    private String prdTpId;
    private String ptTlzId;
    private String ptTlzGrpId;
    private String pofId;
    private String acMngGrpId;
    private String evlAreaId;
    private String prdNo;
    private String bseDt;
    private String istCd;
    private String ptPcsTpId;
    private String ptTrno;
    private String asjTblCd;
    private String pcsStsTc;
    private String lnkTrPtTrno;
    private String lnkDpdPtTrno;
    private String trTlzColNm;
    private String trTlzTrTpNm;
    private String prdTpNm;
    private String ptTlzGrpNm;
    private String pofNm;
    private String acMngGrpNm;
    private String prdNm;
    private String evlGrpId;
    private String hbrdTc;
    private String endBseDt;
    private String sttBseDt;
    private String evlAreaNm;
    private String coCva;
    private String coCvaNm;
    private String evlGrpIdList;
//    private Integer inqSqn;
    private String prdClsId;
    private String acEvlTpId;
    private String acEvlTpNm;

    @JsonIgnore
    public Class getBusinessClass() {
        return TradeTotalizationProcess.class;
    }
}
