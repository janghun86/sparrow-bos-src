package com.noaats.rest.bos.biz.businesscommon.evaluation;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.EvaluationGroupCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EvaluationGroupIn extends BaseMessage {
    private EvaluationGroupCatalogueDto evaluationGroupCatalogue = new EvaluationGroupCatalogueDto();
}
