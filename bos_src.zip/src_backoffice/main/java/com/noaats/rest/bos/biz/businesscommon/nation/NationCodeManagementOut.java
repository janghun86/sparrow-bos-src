package com.noaats.rest.bos.biz.businesscommon.nation;

import com.noaats.rest.bos.biz.co.NationCodeCatalogue;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class NationCodeManagementOut {
    private List<NationCodeCatalogue> nationCodeCatalogueList;
}
