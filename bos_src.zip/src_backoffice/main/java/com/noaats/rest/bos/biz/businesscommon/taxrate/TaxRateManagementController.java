package com.noaats.rest.bos.biz.businesscommon.taxrate;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/taxrate")
public class TaxRateManagementController extends BaseController {

    private final ITaxRateManagementService<TaxRateManagement> taxRateManagementService;

    @GetMapping
    public ResponseEntity<TaxRateManagementOut> inquiry(@RequestBody BaseRequest<TaxRateManagementIn> request) throws CustomException {
        TaxRateManagementIn in = request.getData();
        TaxRateManagementOut out = new TaxRateManagementOut();
        TaxRateManagement taxRateManagement = new TaxRateManagement();
        // convert
        TaxRate taxRate = convert(in.getTaxRate());

        taxRateManagement.setTaxRate(taxRate);
        taxRateManagement = taxRateManagementService.inquiry(taxRateManagement);
        out.setTaxRateList(taxRateManagement.getTaxRateList());
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TaxRateManagementOut> registration(@RequestBody BaseRequest<TaxRateManagementIn> request) throws CustomException {
        TaxRateManagementIn in = request.getData();
        TaxRateManagementOut out = new TaxRateManagementOut();
        TaxRateManagement taxRateManagement = new TaxRateManagement();
        // convert
        List<TaxRate> taxRateList = convertList(in.getTaxRateList());

        taxRateManagement.setTaxRateList(taxRateList);
        taxRateManagementService.registration(taxRateManagement);
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<TaxRateManagementOut> modify(@RequestBody BaseRequest<TaxRateManagementIn> request) throws CustomException {
        TaxRateManagementIn in = request.getData();
        TaxRateManagementOut out = new TaxRateManagementOut();
        TaxRateManagement taxRateManagement = new TaxRateManagement();
        // convert
        List<TaxRate> taxRateList = convertList(in.getTaxRateList());

        taxRateManagement.setTaxRateList(taxRateList);
        taxRateManagementService.modify(taxRateManagement);
        return ResponseEntity.ok(out);
    }
}
