package com.noaats.rest.bos.biz.co.positiontotalizationgroupassistance;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.co.PositionTotalizationGroupChargePersonChangeHistoryDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationGroupChargePersonChangeDto extends PositionTotalizationGroupChargePersonChangeHistoryDto {
    private String hdqNm;
    private String dpmNm;
    private String dvmUsnm;
    private String mainCrgUsnm;
    private String subCrgUsnm;
    private String apvUsnm;
    private String enrUsnm;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionTotalizationGroupChargePersonChange.class;
    }
}
