package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecuritiesReductionSpecificsDto extends BaseDto {
    private String pcsDt;
    private String prdNo;
    private String ptTlzId;
    private String rdtPcsTc;
    private Integer vrs;
    private String pcsStsTc;
    private Double xcr;
    private Double rdtLssAmt;
    private Double rdtLssVca;
    private Double rdtLssTinAmt;
    private Double rdtLssTinVca;
    private Double evlPnlRpyAmt;
    private Double evlPnlRpyVca;
    private String ptTrno;

    @JsonIgnore
    public Class getBusinessClass() {
        return SecuritiesReductionSpecifics.class;
    }
}
