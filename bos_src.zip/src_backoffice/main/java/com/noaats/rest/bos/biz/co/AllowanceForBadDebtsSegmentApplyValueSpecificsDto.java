package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllowanceForBadDebtsSegmentApplyValueSpecificsDto extends BaseDto {
    private String segId;
    private String segTc;
    private Integer acmTrmMmNbr;
    private String aplySttDt;
    private String aplyEndDt;
    private Integer vrs;
    private Double aplyValu;

    @JsonIgnore
    public Class getBusinessClass() {
        return AllowanceForBadDebtsSegmentApplyValueSpecifics.class;
    }
}
