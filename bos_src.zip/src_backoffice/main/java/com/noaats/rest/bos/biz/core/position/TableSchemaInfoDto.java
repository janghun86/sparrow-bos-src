package com.noaats.rest.bos.biz.core.position;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.utilities.TableSchemaDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TableSchemaInfoDto extends TableSchemaDto {
    private String varColId;
    private String dataset;

    @JsonIgnore
    public Class getBusinessClass() {
        return TableSchemaInfo.class;
    }
}
