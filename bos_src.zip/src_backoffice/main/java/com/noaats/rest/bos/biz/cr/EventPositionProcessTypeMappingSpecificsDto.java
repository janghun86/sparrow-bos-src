package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EventPositionProcessTypeMappingSpecificsDto extends BaseDto {
    private String prdGrpTc;
    private String evtTpId;
    private String funOfifTc;
    private String ptPcsTpId;

    @JsonIgnore
    public Class getBusinessClass() {
        return EventPositionProcessTypeMappingSpecifics.class;
    }
}
