package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.cr.AccountProcessIdentifierCatalogue;
import com.noaats.rest.bos.biz.cr.IAccountProcessIdentifierCatalogueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/core/position/account-process-identifier-catalogue")
public class AccountProcessIdentifierCatalogueController extends BaseController {

    private final IAccountProcessIdentifierCatalogueService accountProcessIdentifierCatalogueService;

    @GetMapping
    public ResponseEntity<AccountProcessIdentifierCatalogueOut> service(@RequestBody BaseRequest<AccountProcessIdentifierCatalogueIn> request) throws CustomException {
        AccountProcessIdentifierCatalogueIn in = request.getData();
        AccountProcessIdentifierCatalogueOut out = new AccountProcessIdentifierCatalogueOut();
        // convert
        AccountProcessIdentifierCatalogue accountProcessIdentifierCatalogue = convert(in.getAccountProcessIdentifierCatalogue());

        List<AccountProcessIdentifierCatalogue> accountProcessIdentifierCatalogueList = accountProcessIdentifierCatalogueService.getAccountProcessIdentifierCatalogue(accountProcessIdentifierCatalogue);
        out.setAccountProcessIdentifierCatalogueList(accountProcessIdentifierCatalogueList);
        return ResponseEntity.ok(out);
    }
}
