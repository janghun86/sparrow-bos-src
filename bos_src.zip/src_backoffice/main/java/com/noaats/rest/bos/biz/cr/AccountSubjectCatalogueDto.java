package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountSubjectCatalogueDto extends BaseDto {
    private String asjTblCd;
    private String asjCd;
    private String drCdsTc;
    private String asjNm;
    private String asjAbvNm;
    private String asjTc;
    private String stmAtsTc;

    @JsonIgnore
    public Class getBusinessClass() {
        return AccountSubjectCatalogue.class;
    }
}
