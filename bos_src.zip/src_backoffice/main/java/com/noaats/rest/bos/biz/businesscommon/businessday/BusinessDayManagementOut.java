package com.noaats.rest.bos.biz.businesscommon.businessday;

import com.noaats.rest.bos.biz.co.businessday.BusinessDay;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class BusinessDayManagementOut {
    private BusinessDay businessDay;
    private List<BusinessDay> businessDayList;
}
