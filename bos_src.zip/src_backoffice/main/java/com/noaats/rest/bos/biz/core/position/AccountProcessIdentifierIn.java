package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.AccountProcessIdentifierCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountProcessIdentifierIn extends BaseMessage {
    private AccountProcessIdentifierCatalogueDto accountProcessIdentifierCatalogue = new AccountProcessIdentifierCatalogueDto();
}
