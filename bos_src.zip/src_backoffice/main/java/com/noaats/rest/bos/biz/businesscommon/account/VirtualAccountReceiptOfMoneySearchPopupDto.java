package com.noaats.rest.bos.biz.businesscommon.account;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.co.VirtualAccountReceiptOfMoneySpecificsDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VirtualAccountReceiptOfMoneySearchPopupDto extends VirtualAccountReceiptOfMoneySpecificsDto {
    private String chcYn;
    private Integer row;
    private String bseDt;

    @JsonIgnore
    public Class getBusinessClass() {
        return VirtualAccountReceiptOfMoneySearchPopup.class;
    }
}
