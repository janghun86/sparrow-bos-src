package com.noaats.rest.bos.biz.cr.cashflow.condition;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.pr.CashFlowConditionSpecificsDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CashFlowConditionDto extends CashFlowConditionSpecificsDto {

    @JsonIgnore
    public Class getBusinessClass() {
        return CashFlowCondition.class;
    }
}
