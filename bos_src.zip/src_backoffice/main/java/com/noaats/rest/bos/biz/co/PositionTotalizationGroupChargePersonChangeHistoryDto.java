package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionTotalizationGroupChargePersonChangeHistoryDto extends BaseDto {
    private String ptTlzGrpId;
    private String aplyDt;
    private String hdqCd;
    private String dpmCd;
    private String dvmUsid;
    private String mainCrgUsid;
    private String subCrgUsid;
    private String apvUsid;
    private String enrUsid;

    @JsonIgnore
    public Class getBusinessClass() {
        return PositionTotalizationGroupChargePersonChangeHistory.class;
    }
}
