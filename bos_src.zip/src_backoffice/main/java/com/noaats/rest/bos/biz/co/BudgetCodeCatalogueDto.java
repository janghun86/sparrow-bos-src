package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BudgetCodeCatalogueDto extends BaseDto {
    private String bizBgClsTc;
    private String bizBgId;
    private String bizBgDtlTc;
    private Integer vrs;
    private String bizBgIdTc;
    private String bgTgtYn;
    private String cls1Cd;
    private String cls1Nm;
    private String cls2Cd;
    private String cls2Nm;
    private String cls3Cd;
    private String cls3Nm;
    private String cls4Cd;
    private String cls4Nm;
    private String cls5Cd;
    private String cls5Nm;
    private String bgDpmCd;

    @JsonIgnore
    public Class getBusinessClass() {
        return BudgetCodeCatalogue.class;
    }
}
