package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.EvaluationTypeCatalogueDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HoldingPurposeIn extends BaseMessage {
    private HoldingPurposeDto holdingPurpose = new HoldingPurposeDto();
    private EvaluationTypeCatalogueDto evaluationTypeCatalogue = new EvaluationTypeCatalogueDto();
}
