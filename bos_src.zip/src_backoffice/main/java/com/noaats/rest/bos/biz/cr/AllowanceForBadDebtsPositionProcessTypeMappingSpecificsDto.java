package com.noaats.rest.bos.biz.cr;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllowanceForBadDebtsPositionProcessTypeMappingSpecificsDto extends BaseDto {
    private String ptEvlPcdrId;
    private String abdaEvlTc;
    private String occPtPcsTpId;
    private String occRsuPtPcsTpId;
    private String tinPtPcsTpId;
    private String tinRsuPtPcsTpId;
    private String cpadPftOccPtPcsTpId;
    private String cpadPftOccRsuPtPcsTpId;
    private String cpadPftTinPtPcsTpId;
    private String cpadPftTinRsuPtPcsTpId;
    private String cpadLssOccPtPcsTpId;
    private String cpadLssOccRsuPtPcsTpId;
    private String cpadLssTinPtPcsTpId;
    private String cpadLssTinRsuPtPcsTpId;
    private String cpadLssAdjtPtPcsTpId;
    private String cpadLssAdjtRsuPtPcsTpId;
    private String uwePnbPtPcsTpId;
    private String uwePnbRsuPtPcsTpId;
    private String uweNnbPtPcsTpId;
    private String uweNnbRsuPtPcsTpId;
    private String fccPftPtPcsTpId;
    private String fccPftRsuPtPcsTpId;
    private String fccLssPtPcsTpId;
    private String fccLssRsuPtPcsTpId;

    @JsonIgnore
    public Class getBusinessClass() {
        return AllowanceForBadDebtsPositionProcessTypeMappingSpecifics.class;
    }
}
