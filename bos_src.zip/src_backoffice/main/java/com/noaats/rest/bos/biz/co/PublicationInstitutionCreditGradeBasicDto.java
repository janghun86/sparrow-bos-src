package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PublicationInstitutionCreditGradeBasicDto extends BaseDto {
    private Long pubIstCptyNo;
    private String bseDt;
    private String crdGrClsTc;
    private Integer vrs;
    private String crdGrCd;
    private String rmk;

    @JsonIgnore
    public Class getBusinessClass() {
        return PublicationInstitutionCreditGradeBasic.class;
    }
}
