package com.noaats.rest.bos.biz.abc.taskmanagement;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class TaskProcessSpecificsPopupOut {
    private List<TaskProcessSpecificsPopUp> taskProcessSpecificsPopUpList;
}
