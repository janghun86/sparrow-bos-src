package com.noaats.rest.bos.biz.businesscommon.holiday;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import com.noaats.rest.bos.biz.co.HolidayCodeCatalogue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/holiday")
public class HolidayCodeManagementController extends BaseController {

    private final IHolidayCodeManagementService<HolidayCodeManagement> holidayCodeManagementService;

    @GetMapping
    public ResponseEntity<HolidayCodeManagementOut> inquiry(@RequestBody BaseRequest<HolidayCodeManagementIn> request) throws CustomException {
        HolidayCodeManagementIn in = request.getData();
        HolidayCodeManagementOut out = new HolidayCodeManagementOut();
        HolidayCodeManagement holidayCodeManagement = new HolidayCodeManagement();
        // convert
        HolidayCodeCatalogue holidayCodeCatalogue = convert(in.getHolidayCodeCatalogue());

        holidayCodeManagement.setHolidayCodeCatalogue(holidayCodeCatalogue);
        holidayCodeManagement = holidayCodeManagementService.inquiry(holidayCodeManagement);
        out.setHolidayCodeCatalogue(holidayCodeManagement.getHolidayCodeCatalogue());
        out.setHolidayDateInformationList(holidayCodeManagement.getHolidayDateInformationList());
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<HolidayCodeManagementOut> registration(@RequestBody BaseRequest<HolidayCodeManagementIn> request) throws CustomException {
        HolidayCodeManagementIn in = request.getData();
        HolidayCodeManagementOut out = new HolidayCodeManagementOut();
        HolidayCodeManagement holidayCodeManagement = new HolidayCodeManagement();
        // convert
        HolidayCodeCatalogue holidayCodeCatalogue = convert(in.getHolidayCodeCatalogue());
        List<HolidayDate> holidayDateInformationList = convertList(in.getHolidayDateInformationList());

        holidayCodeManagement.setHolidayCodeCatalogue(holidayCodeCatalogue);
        holidayCodeManagement.setHolidayDateInformationList(holidayDateInformationList);
        holidayCodeManagementService.registration(holidayCodeManagement);
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<HolidayCodeManagementOut> modify(@RequestBody BaseRequest<HolidayCodeManagementIn> request) throws CustomException {
        HolidayCodeManagementIn in = request.getData();
        HolidayCodeManagementOut out = new HolidayCodeManagementOut();
        HolidayCodeManagement holidayCodeManagement = new HolidayCodeManagement();
        // convert
        HolidayCodeCatalogue holidayCodeCatalogue = convert(in.getHolidayCodeCatalogue());

        holidayCodeManagement.setHolidayCodeCatalogue(holidayCodeCatalogue);
        holidayCodeManagementService.modify(holidayCodeManagement);
        return ResponseEntity.ok(out);
    }

    @PutMapping("/regeneration")
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<HolidayCodeManagementOut> holidayReGeneration(@RequestBody BaseRequest<HolidayCodeManagementIn> request) throws CustomException {
        HolidayCodeManagementIn in = request.getData();
        HolidayCodeManagementOut out = new HolidayCodeManagementOut();
        holidayCodeManagementService.holidayReGeneration();
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<HolidayCodeManagementOut> cancel(@RequestBody BaseRequest<HolidayCodeManagementIn> request) throws CustomException {
        HolidayCodeManagementIn in = request.getData();
        HolidayCodeManagementOut out = new HolidayCodeManagementOut();
        HolidayCodeManagement holidayCodeManagement = new HolidayCodeManagement();
        // convert
        HolidayCodeCatalogue holidayCodeCatalogue = convert(in.getHolidayCodeCatalogue());

        holidayCodeManagement.setHolidayCodeCatalogue(holidayCodeCatalogue);
        holidayCodeManagementService.cancel(holidayCodeManagement);
        return ResponseEntity.ok(out);
    }
}
