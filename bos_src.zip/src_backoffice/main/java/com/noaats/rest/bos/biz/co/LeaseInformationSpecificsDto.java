package com.noaats.rest.bos.biz.co;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.lib.frk.mci.BaseDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LeaseInformationSpecificsDto extends BaseDto {
    private Long lseImdIstNo;
    private String lseTrTc;
    private Integer vrs;
    private String feeRecvDd;
    private String feeCalCleMm;

    @JsonIgnore
    public Class getBusinessClass() {
        return LeaseInformationSpecifics.class;
    }
}
