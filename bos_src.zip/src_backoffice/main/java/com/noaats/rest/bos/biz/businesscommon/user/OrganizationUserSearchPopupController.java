package com.noaats.rest.bos.biz.businesscommon.user;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/user")
public class OrganizationUserSearchPopupController extends BaseController {

    private final IOrganizationUserSearchPopupService<OrganizationUserSearchPopup> organizationUserSearchPopupService;

    @GetMapping
    public ResponseEntity<OrganizationUserSearchPopupOut> inquiryUser(@RequestBody BaseRequest<OrganizationUserSearchPopupIn> request) throws CustomException {
        OrganizationUserSearchPopupIn in = request.getData();
        OrganizationUserSearchPopupOut out = new OrganizationUserSearchPopupOut();
        // convert
        OrganizationUserSearchPopup organizationUserSearchPopup = convert(in.getOrganizationUserSearchPopup());

        out.setOrganizationUserSearchPopup(organizationUserSearchPopupService.inquiryUser(organizationUserSearchPopup));
        return ResponseEntity.ok(out);
    }

    @GetMapping("/organization")
    public ResponseEntity<OrganizationUserSearchPopupOut> inquiryOrganizationUser(@RequestBody BaseRequest<OrganizationUserSearchPopupIn> request) throws CustomException {
        OrganizationUserSearchPopupIn in = request.getData();
        OrganizationUserSearchPopupOut out = new OrganizationUserSearchPopupOut();
        // convert
        OrganizationUserSearchPopup organizationUserSearchPopup = convert(in.getOrganizationUserSearchPopup());

        out.setOrganizationUserSearchPopup(organizationUserSearchPopupService.inquiryOrganizationUser(organizationUserSearchPopup));
        return ResponseEntity.ok(out);
    }
}
