package com.noaats.rest.bos.biz.businesscommon.cashflow;

import com.noaats.lib.frk.exception.CustomException;
import com.noaats.lib.frk.mci.BaseController;
import com.noaats.lib.frk.mci.BaseRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/businesscommon/cash-flow")
public class CashFlowRegenerationController extends BaseController {

    private final ICashFlowRegenerationService<CashFlowRegeneration> cashFlowRegenerationService;

    @GetMapping
    public ResponseEntity<CashFlowRegenerationOut> inquiry(@RequestBody BaseRequest<CashFlowRegenerationIn> request) throws CustomException {
        CashFlowRegenerationIn in = request.getData();
        CashFlowRegenerationOut out = new CashFlowRegenerationOut();
        // convert
        CashFlowRegeneration cashFlowRegeneration = convert(in.getCashFlowRegeneration());

        out.setCashFlowRegenerationList(cashFlowRegenerationService.inquiry(cashFlowRegeneration));
        return ResponseEntity.ok(out);
    }

    @GetMapping("/flexible")
    public ResponseEntity<CashFlowRegenerationOut> inquiryFlexibleInterestRate(@RequestBody BaseRequest<CashFlowRegenerationIn> request) throws CustomException {
        CashFlowRegenerationIn in = request.getData();
        CashFlowRegenerationOut out = new CashFlowRegenerationOut();
        // convert
        CashFlowRegeneration cashFlowRegeneration = convert(in.getCashFlowRegeneration());

        out.setFlexibleInterestRateList(cashFlowRegenerationService.inquiryFlexibleInterestRate(cashFlowRegeneration));
        return ResponseEntity.ok(out);
    }

    @GetMapping("/simulation")
    public ResponseEntity<CashFlowRegenerationOut> simulation(@RequestBody BaseRequest<CashFlowRegenerationIn> request) throws CustomException {
        CashFlowRegenerationIn in = request.getData();
        CashFlowRegenerationOut out = new CashFlowRegenerationOut();
        // convert
        CashFlowRegeneration cashFlowRegeneration = convert(in.getCashFlowRegeneration());

        out.setCashFlowList(cashFlowRegenerationService.simulation(cashFlowRegeneration));
        return ResponseEntity.ok(out);
    }

    @PostMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CashFlowRegenerationOut> registration(@RequestBody BaseRequest<CashFlowRegenerationIn> request) throws CustomException {
        CashFlowRegenerationIn in = request.getData();
        CashFlowRegenerationOut out = new CashFlowRegenerationOut();
        // convert
        List<FlexibleInterestRate> flexibleInterestRateList = convertList(in.getFlexibleInterestRateList());

        cashFlowRegenerationService.registration(flexibleInterestRateList);
        out.setFlexibleInterestRateList(flexibleInterestRateList);
        return ResponseEntity.ok(out);
    }

    @PutMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CashFlowRegenerationOut> regenerateCashFlow(@RequestBody BaseRequest<CashFlowRegenerationIn> request) throws CustomException {
        CashFlowRegenerationIn in = request.getData();
        CashFlowRegenerationOut out = new CashFlowRegenerationOut();
        // convert
        List<CashFlowRegeneration> cashFlowRegenerationList = convertList(in.getCashFlowRegenerationList());

        cashFlowRegenerationService.regenerateCashFlow(cashFlowRegenerationList);
        out.setCashFlowRegenerationList(cashFlowRegenerationList);
        return ResponseEntity.ok(out);
    }

    @DeleteMapping
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
    public ResponseEntity<CashFlowRegenerationOut> delete(@RequestBody BaseRequest<CashFlowRegenerationIn> request) throws CustomException {
        CashFlowRegenerationIn in = request.getData();
        CashFlowRegenerationOut out = new CashFlowRegenerationOut();
        // convert
        List<FlexibleInterestRate> flexibleInterestRateList = convertList(in.getFlexibleInterestRateList());

        cashFlowRegenerationService.delete(flexibleInterestRateList);
        out.setFlexibleInterestRateList(flexibleInterestRateList);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/calculate")
    public ResponseEntity<CashFlowRegenerationOut> calculate(@RequestBody BaseRequest<CashFlowRegenerationIn> request) throws CustomException {
        CashFlowRegenerationIn in = request.getData();
        CashFlowRegenerationOut out = new CashFlowRegenerationOut();
        out.setFlexibleInterestRate(cashFlowRegenerationService.calculateInterestRate(convert(in.getFlexibleInterestRate())));
        return ResponseEntity.ok(out);
    }
}
