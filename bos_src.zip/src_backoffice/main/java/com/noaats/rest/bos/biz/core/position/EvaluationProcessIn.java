package com.noaats.rest.bos.biz.core.position;

import com.noaats.lib.frk.mci.BaseMessage;
import com.noaats.rest.bos.biz.cr.evaluation.EffectivenessInterestRateMethodAmortizeDto;
import com.noaats.rest.bos.biz.cr.evaluation.EffectivenessInterestRateMethodAmortizeCalculationDto;
import com.noaats.rest.bos.biz.position.EvaluationProcessDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class EvaluationProcessIn extends BaseMessage {
    private EvaluationProcessDto evaluationProcess = new EvaluationProcessDto();
    private List<EvaluationProcessDto> evaluationProcessList = new ArrayList<>();
    private List<EffectivenessInterestRateMethodAmortizeDto> effectivenessInterestRateMethodAmortizeList = new ArrayList<>();
    private List<EffectivenessInterestRateMethodAmortizeCalculationDto> effectivenessInterestRateMethodAmortizeCalculationList = new ArrayList<>();
}
