package com.noaats.rest.bos.biz.cr.account.journalize;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.noaats.rest.bos.biz.cr.account.AccountDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JournalizeDto extends AccountDto {
    private String jrnStsTc;
    private String ptBseDt;
    private String ptTrno;
    private String slpRulId;
    private String atsSymCd;
    private String asjCd;
    private String drCdsTc;
    private Long evtSno;
    private String ptTlzId;
    private String ptTlzGrpId;
    private String prdNo;
    private String prdTpId;
    private Long ptMngBseNo;
    private Long sno;
    private String slpNo;
    private String jrnBseDt;
    private String acSlpNo;
    private String evlCurCd;
    private String brn;
    private String thcoRomAno;
    private String thcoRomBnkCd;
    private String cptyRomAno;
    private String cptyRomBnkCd;
    private String thcoDrwAno;
    private String thcoDrwBnkCd;
    private String acPcsIdfrId;
    private Long cptyNo;
    private String acEvlTpId;
    private String pofId;
    private String fwdStsTc;
    private String dcdStsTc;
    private Double acVca;
    private String sdDpmCd;
    private String mgmtDpmCd;
    private String prjId;
    private String trPcsTpId;
    private String prdGrpTc;
    private String bseDt;
    private String errMsg;
    private String evlGrpId;
    private String acMngGrpId;
    private String lnkDpdPtTrno;
    private String ptPcsTpId;
    private String evlAreaId;
    private Double vca;
    private Double pca;
    private String pcsStsTc;
    private String lnkTrPtTrno;
    private String lnkDpdOrTrOrgPtTrno;
    private String ustAtsYn;
    private String cshCrnYn;
    private String asjTblCd;
    private boolean isUseActAsjCd;
    private String orgDrCdsTc;
    private Double acPca;
    private Double bseXcr;
    private String ptCurCd;
    private String sttDt;
    private String endDt;
    private String stmDt;
    private String lnkDpdOrTrOrgPtBseDt;
    private String prdClsId;

    @JsonIgnore
    public Class getBusinessClass() {
        return Journalize.class;
    }
}
